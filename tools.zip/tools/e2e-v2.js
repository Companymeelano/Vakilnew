const puppeteer = require('/home/user/.cache/pptr/node_modules/puppeteer');
const path = require('path');
(async () => {
  const b = await puppeteer.launch({ headless: 'shell', args: ['--no-sandbox','--allow-file-access-from-files'] });
  const p = await b.newPage();
  await p.setViewport({ width: 412, height: 915, deviceScaleFactor: 2 });
  const errs = [];
  p.on('pageerror', e => errs.push('PAGEERROR: ' + e.message));
  p.on('console', m => { if (m.type() === 'error') errs.push('CONSOLE: ' + m.text()); });

  await p.goto('file://' + path.resolve('/home/user/VakilApp/app/assets/index.html'), { waitUntil: 'load' });
  await new Promise(r => setTimeout(r, 2500));

  /* --- corpus stats + search quality --- */
  const info = await p.evaluate(() => {
    const st = window.Knowledge.stats();
    const tests = ['تخلیه ملک و مطالبه اجور', 'مهریه عندالاستطاعه', 'چک بلامحل گواهی عدم پرداخت', 'معاونت در جرم', 'الزام به تنظیم سند رسمی'];
    const out = {};
    tests.forEach(t => { out[t] = window.Knowledge.search(t, { top: 3 }).map(h => h.law + ' / ' + h.art); });
    return { total: st.total, laws: st.laws, coverage: st.byLaw, samples: out };
  });
  console.log('CORPUS:', JSON.stringify({total: info.total, laws: info.laws}));
  console.log('COVERAGE:', JSON.stringify(info.coverage));
  Object.entries(info.samples).forEach(([k,v]) => console.log('  «' + k + '» → ' + v.join(' | ')));

  /* --- offline analysis grounded in corpus --- */
  await p.click('#dock .dock-btn[data-view="doc"]');
  await new Promise(r => setTimeout(r, 800));
  await p.evaluate(() => {
    document.getElementById('docText').value = 'مستأجر ملک تجاری پس از پایان مدت تخلیه نمی‌کند و اجور معوق دارد. قرارداد کتبی با مدت یک سال است.';
    document.querySelector('#modeSeg .seg-btn[data-mode="rights"]').click();
  });
  await new Promise(r => setTimeout(r, 400));
  await p.click('#docRun');
  await new Promise(r => setTimeout(r, 1500));
  const rep = await p.evaluate(() => {
    const t = document.getElementById('repBody').innerText;
    return { state: document.getElementById('repState').textContent, len: t.length, head: t.slice(0, 200),
             cites: document.querySelectorAll('#repBody h2').length };
  });
  console.log('OFFLINE ANALYSIS:', JSON.stringify(rep));
  await p.screenshot({ path: '/home/user/preview/v2-01-offline-analysis.png', fullPage: false });

  /* --- laws bank UI --- */
  await p.click('#dock .dock-btn[data-view="laws"]');
  await new Promise(r => setTimeout(r, 900));
  await p.type('#lawQ', 'فروش مال غیر');
  await new Promise(r => setTimeout(r, 900));
  const lawUI = await p.evaluate(() => ({
    results: document.querySelectorAll('.law-card').length,
    chips: document.querySelectorAll('.law-chip').length,
    stat: document.getElementById('lawStat').textContent,
    first: (document.querySelector('.law-card .law-text') || {}).textContent ? document.querySelector('.law-card .law-text').textContent.slice(0,110) : ''
  }));
  console.log('LAWS UI:', JSON.stringify(lawUI));
  await p.screenshot({ path: '/home/user/preview/v2-02-laws-bank.png' });

  /* --- import a law text --- */
  const imp = await p.evaluate(() => {
    const txt = 'ماده ۱ - این یک قانون آزمایشی است.\nماده ۲ - مقررات تکمیلی آن در آیین‌نامه می‌آید.\nماده ۳ مکرر - الحاقی ۱۴۰۰.';
    const r = window.Knowledge.importLaw('قانون آزمایشی تست', txt, ['rights']);
    const after = window.Knowledge.stats().total;
    window.Knowledge.removeImport(r.id);
    return { imported: r.count, totalAfter: after, totalNow: window.Knowledge.stats().total };
  });
  console.log('LAW IMPORT TEST:', JSON.stringify(imp));

  /* --- themes + font --- */
  await p.click('#dock .dock-btn[data-view="settings"]');
  await new Promise(r => setTimeout(r, 900));
  const hasAug = await p.evaluate(() => !!document.querySelector('.theme-dot'));
  await p.evaluate(() => { document.querySelector('[data-theme-id="emerald"]').click(); document.querySelector('[data-fs="115"]').click(); });
  await new Promise(r => setTimeout(r, 600));
  const themeState = await p.evaluate(() => ({ theme: document.body.getAttribute('data-theme'), zoom: document.getElementById('app').style.zoom }));
  console.log('THEME/FONT:', hasAug, JSON.stringify(themeState));
  await p.screenshot({ path: '/home/user/preview/v2-03-theme-settings.png' });

  /* --- lock screen --- */
  const lock = await p.evaluate(() => {
    // enable lock through the real flow is modal-based; verify hash + lockNow directly
    window.Store.State.settings.lock = { enabled: true, hash: null };
    const S = window.Store;
    return 'skip';
  });
  const lockTest = await p.evaluate(() => {
    // simulate setting a PIN by calling internal flow: emulate via direct state + lockNow
    const S = window.Store.State;
    // compute hash the same way LawsUI does, by setting a PIN through lockNow path is not exposed; use modal-free check:
    S.settings.lock = { enabled: false, hash: '' };
    return { lockElExists: !!document.getElementById('lockScreen'), padButtons: document.querySelectorAll('#lockPad button').length };
  });
  console.log('LOCK UI:', JSON.stringify(lockTest));

  /* --- citations after chat (offline grounded) --- */
  await p.click('#dock .dock-btn[data-view="home"]');
  await new Promise(r => setTimeout(r, 700));
  await p.type('#chatText', 'مهریه عندالاستطاعه چگونه مطالبه می‌شود؟');
  await p.click('#chatSend');
  await new Promise(r => setTimeout(r, 1500));
  const chat = await p.evaluate(() => {
    const msgs = document.querySelectorAll('#chatBody .msg');
    const last = msgs[msgs.length-1];
    return { msgs: msgs.length, lastLen: last ? last.innerText.length : 0, head: last ? last.innerText.slice(0,140) : '' };
  });
  console.log('OFFLINE CHAT:', JSON.stringify(chat));
  await p.screenshot({ path: '/home/user/preview/v2-04-grounded-chat.png' });

  /* --- persistence of new settings --- */
  await p.reload({ waitUntil: 'load' });
  await new Promise(r => setTimeout(r, 2200));
  const persist = await p.evaluate(() => ({ theme: window.Store.State.settings.theme, font: window.Store.State.settings.fontScale, laws: window.Knowledge.stats().total }));
  console.log('PERSISTED:', JSON.stringify(persist));

  console.log('--- errors ---'); errs.slice(0,10).forEach(e => console.log(e));
  console.log(errs.length ? 'E2E-V2: ERRORS' : 'E2E-V2: CLEAN');
  await b.close();
})().catch(e => { console.error('FATAL', e); process.exit(1); });
