#!/bin/bash
set -e
BASE="$HOME/.cache"
mkdir -p "$BASE"
cd /tmp

echo "### sudo check"
sudo -n true 2>/dev/null && echo "sudo-yes" || echo "sudo-no"

# --- standalone JDK 17 (no root needed) ---
if [ ! -d "$BASE/jdk17" ]; then
  echo "### downloading Temurin JDK 17"
  curl -sL -o jdk17.tar.gz "https://api.adoptium.net/v3/binary/latest/17/ga/linux/x64/jdk/hotspot/normal/eclipse"
  ls -la jdk17.tar.gz
  mkdir -p "$BASE/jdk17"
  tar -xzf jdk17.tar.gz -C "$BASE/jdk17" --strip-components=1
fi
export JAVA_HOME="$BASE/jdk17"
export PATH="$JAVA_HOME/bin:$PATH"
echo "### java: $("$JAVA_HOME/bin/java" -version 2>&1 | head -1)"

# --- Android cmdline tools ---
if [ ! -x "$BASE/android-sdk/cmdline-tools/latest/bin/sdkmanager" ]; then
  echo "### downloading cmdline-tools"
  curl -sL -o cmdtools.zip https://dl.google.com/android/repository/commandlinetools-linux-11076708_latest.zip
  ls -la cmdtools.zip
  mkdir -p "$BASE/android-sdk/cmdline-tools"
  unzip -q -o cmdtools.zip -d "$BASE/android-sdk/cmdline-tools"
  rm -rf "$BASE/android-sdk/cmdline-tools/latest"
  mv "$BASE/android-sdk/cmdline-tools/cmdline-tools" "$BASE/android-sdk/cmdline-tools/latest"
fi

SDKM="$BASE/android-sdk/cmdline-tools/latest/bin/sdkmanager"
chmod +x "$SDKM"
yes | "$SDKM" --sdk_root="$BASE/android-sdk" --licenses >/dev/null 2>&1 || true
echo "### installing platform + build-tools"
"$SDKM" --sdk_root="$BASE/android-sdk" "platforms;android-34" "build-tools;34.0.0" 2>&1 | tail -3

echo "=== SDK-READY ==="
ls "$BASE/android-sdk/build-tools/34.0.0/" | grep -E "^(aapt2|d8|apksigner|zipalign)$"
ls -la "$BASE/android-sdk/platforms/android-34/android.jar"
