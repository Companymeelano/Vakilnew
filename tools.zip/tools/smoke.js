/* Headless smoke test: load the app exactly like the WebView does (file://) */
const puppeteer = require('/home/user/.cache/pptr/node_modules/puppeteer');
const path = require('path');
const fs = require('fs');

(async () => {
  const outDir = '/home/user/preview';
  fs.mkdirSync(outDir, { recursive: true });
  const browser = await puppeteer.launch({
    headless: 'shell',
    args: ['--no-sandbox', '--disable-setuid-sandbox', '--allow-file-access-from-files', '--font-render-hinting=none']
  });
  const page = await browser.newPage();
  await page.setViewport({ width: 412, height: 915, deviceScaleFactor: 2 });
  const logs = [], errors = [];
  page.on('console', m => logs.push(m.type() + ': ' + m.text()));
  page.on('pageerror', e => errors.push('PAGEERROR: ' + e.message));

  const url = 'file://' + path.resolve('/home/user/VakilApp/app/assets/index.html');
  await page.goto(url, { waitUntil: 'load', timeout: 60000 });
  await new Promise(r => setTimeout(r, 3500));
  await page.screenshot({ path: outDir + '/01-home.png' });

  const info = await page.evaluate(() => ({
    title: document.title,
    hasStore: !!window.Store, hasAI: !!window.AI, hasChar: !!window.Character, hasPages: !!window.Pages,
    spriteIcons: document.querySelectorAll('#sprite symbol').length,
    charNodes: document.querySelectorAll('#charSvg *').length,
    model: window.AI.modelLabel(),
    agents: window.Legal.AGENTS.length,
    draftTypes: window.Legal.DRAFT_TYPES.length,
    providers: Object.keys(window.AI.PROVIDERS).length,
    charText: (document.getElementById('charText') || {}).textContent
  }));
  console.log('INFO ' + JSON.stringify(info, null, 1));

  /* interaction: cases → new case form */
  await page.click('#dock .dock-btn[data-view="cases"]');
  await new Promise(r => setTimeout(r, 700));
  await page.screenshot({ path: outDir + '/02-cases.png' });
  await page.click('#btnNewCase');
  await new Promise(r => setTimeout(r, 600));
  await page.screenshot({ path: outDir + '/03-newcase.png' });
  await page.evaluate(() => {
    document.getElementById('fTitle').value = 'مطالبه وجه چک — آقای رضایی';
    document.getElementById('fNo').value = '۱۴۰۴۱۲۳۴۵۶۷۸۹';
    document.getElementById('fType').value = 'حقوقی';
    document.getElementById('fOpp').value = 'آقای رضایی';
    document.getElementById('fSubject').value = 'چک بلامحل به مبلغ ۲۵۰ میلیون ریال، سرسید گذشته و عدم پرداخت.';
    document.getElementById('fSave').click();
  });
  await new Promise(r => setTimeout(r, 900));
  await page.screenshot({ path: outDir + '/04-caselist.png' });

  /* analyze page */
  await page.click('#dock .dock-btn[data-view="doc"]');
  await new Promise(r => setTimeout(r, 600));
  await page.evaluate(() => {
    document.getElementById('docText').value = 'چک بلامحل دارم و صادرکننده مدعی است چک را گم کرده است.';
  });
  await page.click('#docRun');
  await new Promise(r => setTimeout(r, 1200));
  await page.screenshot({ path: outDir + '/05-analyze-offline.png' });

  /* draft */
  await page.click('#dock .dock-btn[data-view="draft"]');
  await new Promise(r => setTimeout(r, 700));
  await page.screenshot({ path: outDir + '/06-draft.png' });

  /* settings */
  await page.click('#dock .dock-btn[data-view="settings"]');
  await new Promise(r => setTimeout(r, 700));
  await page.screenshot({ path: outDir + '/07-settings.png', fullPage: false });

  const st = await page.evaluate(() => ({
    cases: window.Store.State.cases.length,
    apiRows: document.querySelectorAll('.api-row').length,
    modelOptions: document.querySelectorAll('#setDefaultModel option').length,
    savedSize: JSON.stringify(window.Store.State).length
  }));
  console.log('STATE ' + JSON.stringify(st));

  console.log('--- console logs ---'); logs.slice(0, 25).forEach(l => console.log(l));
  console.log('--- page errors ---'); errors.forEach(e => console.log(e));
  console.log(errors.length ? 'SMOKE: ERRORS' : 'SMOKE: CLEAN');
  await browser.close();
})().catch(e => { console.error('FATAL', e); process.exit(1); });
