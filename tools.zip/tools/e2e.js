/* End-to-end test: stub OpenAI-compatible server + full analysis pipeline */
const puppeteer = require('/home/user/.cache/pptr/node_modules/puppeteer');
const http = require('http');
const path = require('path');
const fs = require('fs');

const REPORT = `## ۱. خلاصهٔ پرونده و طرفین
خواهان مالک چک بلامحل به مبلغ ۲۵۰ میلیون ریال است و خوانده صادرکنندهٔ چک.\n
## ۲. ارزیابی ادله و مدارک
| مدرک | اعتبار | نکته |
|---|---|---|
| اصل چک | بالا | مطابق ماده ۳۱۰ قانون تجارت |
| گواهی عدم پرداخت | بالا | شرط لازم برای مطالبه |
## ۳. تحلیل حقوقی و مواد قانونی مرتبط
به استناد **ماده ۳۱۰ قانون تجارت** و **ماده ۳ قانون صدور چک** (اصلاحی ۱۳۹۷)، دارندهٔ چک می‌تواند علیه صادرکننده اقامه دعوا کند. بر اساس ماده ۲ همان قانون، ادعای سرقت یا گم شدن، مسئولیت صادرکننده را منتفی نمی‌کند مگر با تودیع وجه.
## ۴. دفاعیات احتمالی طرف مقابل و پاسخ آنها
ادعای گم شدن چک مطابق ماده ۲۴ قانون صدور چک مانع مطالبه نیست.
## ۵. راهکارهای اصولی و گام‌به‌گام
۱- مطالبهٔ وجه از طریق اجرای ثبت (ماده ۵ قانون صدور چک)
۲- شکایت کیفری مطابق ماده ۳ (چک بلامحل)
۳- درخواست تأمین خواسته و توقیف اموال (مواد ۱۰۸ تا ۱۲۲ ق.آ.د.م)
## ۶. ریسک‌ها، مهلت‌ها و هشدارهای مهم
مهلت تعقیب کیفری چک از تاریخ گواهی عدم پرداخت؛ احتیاط در انتقال چک.
## ۷. پرسش‌های تکمیلی
آیا چک را از شخص ثالث دریافت کرده‌اید؟ صادرکننده اموال شناخته‌شده دارد؟
---
**اقدامات فوری (۲۴–۷۲ ساعت):** اخذ گواهی عدم پرداخت به‌روز و تنظیم اظهارنامه رسمی.`;

const server = http.createServer((req, res) => {
  let body = '';
  req.on('data', c => body += c);
  req.on('end', () => {
    res.writeHead(200, {
      'Content-Type': 'application/json',
      'Access-Control-Allow-Origin': '*',
      'Access-Control-Allow-Headers': '*',
      'Access-Control-Allow-Methods': 'POST, OPTIONS'
    });
    if (req.method === 'OPTIONS') return res.end('{}');
    const model = (JSON.parse(body || '{}').model) || 'stub';
    res.end(JSON.stringify({
      id: 'stub', object: 'chat.completion', model: model,
      choices: [{ index: 0, message: { role: 'assistant', content: REPORT }, finish_reason: 'stop' }]
    }));
  });
});

(async () => {
  await new Promise(r => server.listen(8899, '127.0.0.1', r));

  const browser = await puppeteer.launch({ headless: 'shell', args: ['--no-sandbox', '--allow-file-access-from-files'] });
  const page = await browser.newPage();
  await page.setViewport({ width: 412, height: 915, deviceScaleFactor: 2 });
  const errs = [];
  page.on('pageerror', e => errs.push('PAGEERROR: ' + e.message));

  await page.goto(
'file://' + path.resolve('/home/user/VakilApp/app/assets/index.html'), { waitUntil: 'load' });
  await new Promise(r => setTimeout(r, 2500));

  /* seed a fake OpenAI-compatible provider through the store itself */
  await page.evaluate(() => {
    var st = window.Store.State;
    st.settings.providers.custom = { key: 'test-key', base: 'http://127.0.0.1:8899/v1/chat/completions', model: 'vakil-test-model' };
    st.settings.defaultModel = 'custom:vakil-test-model';
    st.settings.multi = true;
    window.Store.save(true);
    window.Pages.updateTitle('home', {});
  });
  const label = await page.evaluate(() => document.getElementById('tbModel').textContent);
  console.log('MODEL LABEL:', label);

  /* create case */
  await page.click('#dock .dock-btn[data-view="cases"]');
  await new Promise(r => setTimeout(r, 500));
  await page.click('#btnNewCase');
  await new Promise(r => setTimeout(r, 400));
  await page.evaluate(() => {
    document.getElementById('fTitle').value = 'مطالبه وجه چک — آقای رضایی';
    document.getElementById('fNo').value = '۱۴۰۴۱۲۳۴۵۶۷۸۹';
    document.getElementById('fSave').click();
  });
  await new Promise(r => setTimeout(r, 600));
  await page.evaluate(() => { document.getElementById('btnBack').click(); });
  await new Promise(r => setTimeout(r, 400));

  /* test each provider row (custom) */
  await page.click('#dock .dock-btn[data-view="settings"]');
  await new Promise(r => setTimeout(r, 600));
  await page.evaluate(() => { document.querySelector('[data-test="custom"]').click(); });
  await new Promise(r => setTimeout(r, 2500));
  const state = await page.evaluate(() => document.getElementById('s_custom').textContent);
  console.log('CUSTOM PROVIDER TEST:', state);
  await page.screenshot({ path: '/home/user/preview/08-provider-test.png' });

  /* chat with the agent */
  await page.click('#dock .dock-btn[data-view="home"]');
  await new Promise(r => setTimeout(r, 800));
  await page.type('#chatText', 'چک بلامحل دارم و صادرکننده می‌گوید چک را گم کرده است. چه کنم؟');
  await page.click('#chatSend');
  await new Promise(r => setTimeout(r, 4000));
  await page.screenshot({ path: '/home/user/preview/09-chat-ai.png' });

  /* full multi-agent analysis */
  await page.click('#dock .dock-btn[data-view="doc"]');
  await new Promise(r => setTimeout(r, 700));
  await page.evaluate(() => { document.getElementById('docText').value = 'چک بلامحل به مبلغ ۲۵۰ میلیون ریال؛ صادرکننده ادعای گم شدن دارد. مدارک: اصل چک و گواهی عدم پرداخت.'; });
  await page.click('#docRun');
  await new Promise(r => setTimeout(r, 9000));
  await page.screenshot({ path: '/home/user/preview/10-analysis-report.png' });
  const rep = await page.evaluate(() => ({
    state: document.getElementById('repState') ? document.getElementById('repState').textContent : '',
    words: (document.getElementById('repBody') || {}).innerText ? document.getElementById('repBody').innerText.slice(0, 140) : '',
    hasSaveBtn: !!document.getElementById('rSave'),
    h2count: (document.getElementById('repBody') || {querySelectorAll:()=>[]}).querySelectorAll('h2').length
  }));
  console.log('REPORT:', JSON.stringify(rep));

  /* save to case */
  await page.evaluate(() => document.getElementById('rSave').click());
  await new Promise(r => setTimeout(r, 900));
  const saved = await page.evaluate(() => JSON.stringify({
    analyses: window.Store.State.cases[0].analysis.length,
    timeline: window.Store.State.cases[0].timeline.length,
    msgs: window.Store.getSession(window.Store.State.activeCaseId).messages.length
  }));
  console.log('SAVED:', saved);

  /* draft generation */
  await page.click('#dock .dock-btn[data-view="draft"]');
  await new Promise(r => setTimeout(r, 700));
  await page.evaluate(() => {
    const inputs = document.querySelectorAll('#draftForm [data-k]');
    inputs.forEach(i => { if (i.getAttribute('data-k') === 'core') i.value = 'مطالبه وجه چک بلامحل'; });
  });
  await page.click('#draftRun');
  await new Promise(r => setTimeout(r, 5000));
  await page.screenshot({ path: '/home/user/preview/11-draft-ai.png' });
  const dr = await page.evaluate(() => ({ paper: document.getElementById('draftOut').innerText.slice(0, 90), saveBtn: !document.getElementById('draftSaveCase').hidden }));
  console.log('DRAFT:', JSON.stringify(dr));

  /* case detail tabs */
  await page.click('#dock .dock-btn[data-view="cases"]');
  await new Promise(r => setTimeout(r, 500));
  await page.evaluate(() => document.querySelector('.case-card').click());
  await new Promise(r => setTimeout(r, 700));
  await page.screenshot({ path: '/home/user/preview/12-case-detail.png' });
  await page.evaluate(() => { document.querySelectorAll('#caseTabs .tab')[1].click(); });
  await new Promise(r => setTimeout(r, 500));
  await page.screenshot({ path: '/home/user/preview/13-case-docs.png' });

  /* reload → persistence check */
  await page.reload({ waitUntil: 'load' });
  await new Promise(r => setTimeout(r, 2200));
  const persisted = await page.evaluate(() => JSON.stringify({
    cases: window.Store.State.cases.length,
    analyses: window.Store.State.cases[0] ? window.Store.State.cases[0].analysis.length : 0,
    model: window.Store.State.settings.defaultModel
  }));
  console.log('PERSISTED AFTER RELOAD:', persisted);

  console.log('--- page errors ---'); errs.forEach(e => console.log(e));
  console.log(errs.length ? 'E2E: ERRORS' : 'E2E: CLEAN');
  await browser.close();
  server.close();
})().catch(e => { console.error('FATAL', e); process.exit(1); });
