#!/bin/bash
# Build a signed, installable APK for Vakil AI (no gradle, pure SDK tools)
set -e
BASE="$HOME/.cache"
export JAVA_HOME="$BASE/jdk17"
export PATH="$JAVA_HOME/bin:$PATH"

SDK="$BASE/android-sdk"
BT="$SDK/build-tools/34.0.0"
PLATFORM="$SDK/platforms/android-34/android.jar"
SRC="/home/user/VakilApp"
OUT="/tmp/apkbuild"
APK_OUT="/home/user/VakilAI-luxury-lawyer.apk"
KS="$SRC/keystore.jks"
KSPASS="vakil2016"

rm -rf "$OUT"
mkdir -p "$OUT/flat" "$OUT/gen" "$OUT/compiled" "$OUT/dex"

echo "==> [1/7] aapt2 compile resources"
"$BT/aapt2" compile --dir "$SRC/app/res" -o "$OUT/res.zip"

echo "==> [2/7] aapt2 link (manifest + resources + assets)"
"$BT/aapt2" link \
  -o "$OUT/base.apk" \
  -I "$PLATFORM" \
  --manifest "$SRC/app/AndroidManifest.xml" \
  -R "$OUT/res.zip" \
  -A "$SRC/app/assets" \
  --java "$OUT/gen" \
  --min-sdk-version 24 \
  --target-sdk-version 34 \
  --no-version-vectors \
  --auto-add-overlay

echo "==> [3/7] javac"
find "$SRC/app/java" "$OUT/gen" -name "*.java" > "$OUT/sources.txt"
javac -encoding UTF-8 -source 8 -target 8 -nowarn \
  -bootclasspath "$PLATFORM" -classpath "$PLATFORM" \
  -d "$OUT/compiled" @"$OUT/sources.txt" 2>&1 | grep -v "^warning:" || true

echo "==> [4/7] d8 (dex)"
CLASSES=$(find "$OUT/compiled" -name "*.class")
"$BT/d8" --release --min-api 24 --lib "$PLATFORM" --output "$OUT/dex" $CLASSES

echo "==> [5/7] package dex into apk"
cp "$OUT/base.apk" "$OUT/unsigned.apk"
( cd "$OUT/dex" && zip -q "$OUT/unsigned.apk" classes*.dex )

echo "==> [6/7] zipalign"
"$BT/zipalign" -f -p 4 "$OUT/unsigned.apk" "$OUT/aligned.apk"

echo "==> [7/7] signing"
if [ ! -f "$KS" ]; then
  keytool -genkeypair -v -keystore "$KS" -alias vakil -keyalg RSA -keysize 2048 \
    -validity 10950 -storepass "$KSPASS" -keypass "$KSPASS" \
    -dname "CN=Vakil AI Legal Assistant, OU=Legal Tech, O=VakilApp, L=Tehran, C=IR" >/dev/null 2>&1
  echo "    keystore created"
fi
"$BT/apksigner" sign --ks "$KS" --ks-pass "pass:$KSPASS" --key-pass "pass:$KSPASS" \
  --v1-signing-enabled true --v2-signing-enabled true \
  --out "$APK_OUT" "$OUT/aligned.apk"

"$BT/apksigner" verify --print-certs "$APK_OUT" | head -4
ls -la "$APK_OUT"
echo "=== APK-BUILD-SUCCESS ==="
