#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""بازسازی کامل کاراکتر «خانم وکیل» — نسخهٔ ۳ (چهرهٔ جذاب‌تر، موی بلوند لایه‌ای،
عینک طبی با فریم طلایی، لباس رسمی، دست و انگشت‌های واقع‌گرا، خودکار کاملاً واقعی).

جایگزین بلوک <svg id="charSvg"> … </svg> در index.html می‌شود و همهٔ id/class‌هایی که
موتور انیمیشن (character.js) به آن‌ها وابسته است را حفظ می‌کند.
"""
import io, re, sys

HTML = '/home/user/VakilApp/app/assets/index.html'

EYE_UNIT = r'''<g>
                    <path d="M122.6 128.4 C126.8 115.2 137.4 107.4 148.8 107.4 C160 107.4 169 114.4 172.4 125.6 C160.8 118 135.6 117.8 122.6 128.4 Z" fill="#d1936f" opacity=".32" filter="url(#cSoft)"/>
                    <path d="M166 140.5 C162.4 131 155.6 124.6 146.6 124.6 C137.2 124.6 129.8 129.4 126 135.4 C128.2 145 136.2 152 146.8 152 C155.8 152 162.8 147.8 166 140.5 Z" fill="url(#cSclera)"/>
                    <clipPath id="{CLIP}">
                      <path d="M166 140.5 C162.4 131 155.6 124.6 146.6 124.6 C137.2 124.6 129.8 129.4 126 135.4 C128.2 145 136.2 152 146.8 152 C155.8 152 162.8 147.8 166 140.5 Z"/>
                    </clipPath>
                    <g clip-path="url(#{CLIP})">
                      <path d="M120 128 C136 118 160 118 172 128 L172 120 L120 120 Z" fill="#b18f80" opacity=".45"/>
                      <path d="M126 135.4 C130.4 129 137.8 124.8 146.6 124.8 C155 124.8 162.6 129 166 135.6 C156.6 130.4 133.6 130 126 135.4 Z" fill="#7a5346" opacity=".32"/>
                      <circle class="iris" cx="147.2" cy="138.4" r="10" fill="url(#cIris)"/>
                      <circle cx="147.2" cy="138.4" r="10" fill="none" stroke="#0f2c3d" stroke-width="1.2" opacity=".9"/>
                      <path d="M138.4 143.8 C140.4 149.6 144 152.8 148.4 152.8 C152.8 152.8 156.2 149.6 158 144 C154.4 147 150.6 148.2 147.2 148 C143.8 147.8 140.6 146.4 138.4 143.8 Z" fill="#9adbf0" opacity=".45"/>
                      <circle class="pupil" cx="147.2" cy="138.6" r="4.35" fill="#07151e"/>
                      <ellipse class="shine" cx="143.6" cy="134" rx="3.4" ry="2.6" fill="#fff" opacity=".95"/>
                      <circle class="shine2" cx="152.2" cy="142.6" r="1.4" fill="#fff" opacity=".62"/>
                      <path d="M126 135.4 C130.4 129 137.8 124.8 146.6 124.8 C155 124.8 162.6 129 166 135.6 C163 128.4 155.6 124.2 146.8 124.2 C137.8 124.2 129.8 128.6 126 135.4 Z" fill="#5d4136" opacity=".45"/>
                    </g>
                    <path d="M125.6 135.2 C129.8 128.2 137.4 123.8 146.8 123.8 C156.4 123.8 163.4 128.4 167 136.4" stroke="#33231a" stroke-width="2.5" fill="none" stroke-linecap="round"/>
                    <path d="M125.8 135 C123.2 132.6 120.6 131.6 118 131.2" stroke="#33231a" stroke-width="1.6" fill="none" stroke-linecap="round" opacity=".9"/>
                    <g stroke="#48301f" stroke-linecap="round" opacity=".82" fill="none">
                      <path d="M123 129.6 C120.4 126.6 119 124.2 118.4 121.6" stroke-width="1.1"/>
                      <path d="M129 126.4 C127 123.2 126.2 120.8 126 118.2" stroke-width="1"/>
                      <path d="M135.6 124.4 C134.6 121.2 134.4 119 134.8 116.6" stroke-width=".9"/>
                    </g>
                    <path d="M126.6 137.2 C132 145.8 139 149.8 146.8 149.8 C154.4 149.8 161.4 145.6 165.4 138.4" stroke="#a9755c" stroke-width="1.05" fill="none" opacity=".5"/>
                    <path d="M124.6 126.2 C130.4 116.6 139.6 111.8 149 112 C157.4 112.2 164.6 116.4 168.8 123.2" stroke="#d7a184" stroke-width="1.5" fill="none" opacity=".42"/>
                    <ellipse cx="142.6" cy="146.4" rx="5" ry="1.7" fill="#fff" opacity=".13"/>
                    <path d="M127 141.8 C133 148.4 140.4 152 147.6 152 C155.6 152 162.2 148.4 166 141" fill="none" stroke="#8a6a58" stroke-width="1.15" opacity=".55"/>
                    <path d="M129.4 153 C136.4 158.4 142.6 160.8 147.8 160.6 C154 160.4 160.4 157 165.4 151.4" fill="none" stroke="#d69678" stroke-width="2.2" opacity=".3" filter="url(#cSoft)"/>
                    <path d="M166.2 139.8 C168 138.4 169.2 136.4 169.6 134.2" stroke="#c98a68" stroke-width=".9" fill="none" opacity=".5"/>
                  </g>'''

SVG_HEAD = r'''<svg id="charSvg" viewBox="0 0 360 470" aria-label="خانم وکیل مشاور">
        <defs>
          <linearGradient id="cSkin" x1=".15" y1="0" x2=".5" y2="1">
            <stop offset="0" stop-color="#ffe9d8"/><stop offset=".4" stop-color="#f8d3b4"/><stop offset=".74" stop-color="#eebb99"/><stop offset="1" stop-color="#dda17f"/>
          </linearGradient>
          <linearGradient id="cSkinArm" x1=".1" y1="0" x2=".6" y2="1">
            <stop offset="0" stop-color="#fbd9c0"/><stop offset=".62" stop-color="#eec0a0"/><stop offset="1" stop-color="#d89c7e"/>
          </linearGradient>
          <linearGradient id="cSkinArm2" x1=".1" y1="0" x2=".6" y2="1">
            <stop offset="0" stop-color="#f6d0b4"/><stop offset=".6" stop-color="#e6b494"/><stop offset="1" stop-color="#cf9070"/>
          </linearGradient>
          <radialGradient id="cBlush" cx=".5" cy=".5" r=".5">
            <stop offset="0" stop-color="#ee8770" stop-opacity=".45"/><stop offset=".62" stop-color="#f09079" stop-opacity=".18"/><stop offset="1" stop-color="#f09079" stop-opacity="0"/>
          </radialGradient>
          <radialGradient id="cAuraGlow" cx=".5" cy=".42" r=".58">
            <stop offset="0" stop-color="#ffd98a" stop-opacity=".48"/><stop offset=".5" stop-color="#ffc766" stop-opacity=".14"/><stop offset="1" stop-color="#ffc766" stop-opacity="0"/>
          </radialGradient>
          <linearGradient id="cHair" x1=".12" y1="0" x2=".55" y2="1">
            <stop offset="0" stop-color="#fbeaba"/><stop offset=".32" stop-color="#eecd8a"/><stop offset=".66" stop-color="#d3a55e"/><stop offset="1" stop-color="#b3843f"/>
          </linearGradient>
          <linearGradient id="cHairDark" x1="0" y1="0" x2=".4" y2="1">
            <stop offset="0" stop-color="#c69a55"/><stop offset="1" stop-color="#8f652c"/>
          </linearGradient>
          <linearGradient id="cHairHi" x1="0" y1="0" x2="1" y2="1">
            <stop offset="0" stop-color="#fffbe8"/><stop offset="1" stop-color="#f8e7b2"/>
          </linearGradient>
          <linearGradient id="cBlazer" x1=".1" y1="0" x2=".65" y2="1">
            <stop offset="0" stop-color="#354b76"/><stop offset=".42" stop-color="#1f2d4c"/><stop offset="1" stop-color="#121a2e"/>
          </linearGradient>
          <linearGradient id="cBlazerLapel" x1="0" y1="0" x2="1" y2="1">
            <stop offset="0" stop-color="#5a74a4"/><stop offset=".45" stop-color="#33456c"/><stop offset="1" stop-color="#1c2841"/>
          </linearGradient>
          <linearGradient id="cBlouse" x1=".2" y1="0" x2=".75" y2="1">
            <stop offset="0" stop-color="#fffdf7"/><stop offset=".55" stop-color="#f4ecdd"/><stop offset="1" stop-color="#dccfb8"/>
          </linearGradient>
          <linearGradient id="cPaper" x1="0" y1="0" x2=".25" y2="1">
            <stop offset="0" stop-color="#fffef8"/><stop offset="1" stop-color="#e3d8c2"/>
          </linearGradient>
          <linearGradient id="cDeskTop" x1=".2" y1="0" x2=".5" y2="1">
            <stop offset="0" stop-color="#2b3a63"/><stop offset=".55" stop-color="#1e2a48"/><stop offset="1" stop-color="#16203a"/>
          </linearGradient>
          <linearGradient id="cDeskFront" x1="0" y1="0" x2="0" y2="1">
            <stop offset="0" stop-color="#16203a"/><stop offset="1" stop-color="#080d18"/>
          </linearGradient>
          <linearGradient id="cTrim" x1="0" y1="0" x2="1" y2="1">
            <stop offset="0" stop-color="#fdf0c0"/><stop offset=".35" stop-color="#e6c66e"/><stop offset=".7" stop-color="#b78e2c"/><stop offset="1" stop-color="#8a661c"/>
          </linearGradient>
          <linearGradient id="cFrame" x1=".1" y1="0" x2=".85" y2="1">
            <stop offset="0" stop-color="#fdf2c8"/><stop offset=".35" stop-color="#e8c877"/><stop offset=".72" stop-color="#b68c2d"/><stop offset="1" stop-color="#8d691c"/>
          </linearGradient>
          <linearGradient id="cLens" x1=".15" y1="0" x2=".6" y2="1">
            <stop offset="0" stop-color="#eaf5ff" stop-opacity=".3"/><stop offset=".5" stop-color="#c3dcf4" stop-opacity=".1"/><stop offset="1" stop-color="#ffffff" stop-opacity=".2"/>
          </linearGradient>
          <linearGradient id="cWood" x1="0" y1="0" x2=".4" y2="1">
            <stop offset="0" stop-color="#8a5330"/><stop offset=".5" stop-color="#67391d"/><stop offset="1" stop-color="#3f2110"/>
          </linearGradient>
          <linearGradient id="cPorcelain" x1=".1" y1="0" x2=".9" y2="1">
            <stop offset="0" stop-color="#ffffff"/><stop offset=".45" stop-color="#eef2f8"/><stop offset="1" stop-color="#c9d2df"/>
          </linearGradient>
          <radialGradient id="cIris" cx=".42" cy=".34" r=".74">
            <stop offset="0" stop-color="#b0ebf8"/><stop offset=".3" stop-color="#59a8c6"/><stop offset=".68" stop-color="#2a7192"/><stop offset="1" stop-color="#11384d"/>
          </radialGradient>
          <radialGradient id="cSclera" cx=".5" cy=".42" r=".66">
            <stop offset="0" stop-color="#fffefc"/><stop offset=".74" stop-color="#f8f2ed"/><stop offset="1" stop-color="#ded0c8"/>
          </radialGradient>
          <linearGradient id="cLip" x1=".15" y1="0" x2=".7" y2="1">
            <stop offset="0" stop-color="#dc7c88"/><stop offset=".5" stop-color="#c65f72"/><stop offset="1" stop-color="#9d3c54"/>
          </linearGradient>
          <linearGradient id="cLipLow" x1=".2" y1="0" x2=".7" y2="1">
            <stop offset="0" stop-color="#d97487"/><stop offset=".55" stop-color="#bd5268"/><stop offset="1" stop-color="#93354d"/>
          </linearGradient>
          <linearGradient id="cBrow" x1="0" y1="0" x2="1" y2="0">
            <stop offset="0" stop-color="#c19465"/><stop offset=".4" stop-color="#9d7044"/><stop offset="1" stop-color="#78512b"/>
          </linearGradient>
          <linearGradient id="cPenBody" x1="0" y1="0" x2="1" y2="0">
            <stop offset="0" stop-color="#0f1829"/><stop offset=".18" stop-color="#4a5f8d"/><stop offset=".4" stop-color="#26365a"/><stop offset=".76" stop-color="#0d1526"/><stop offset="1" stop-color="#33456c"/>
          </linearGradient>
          <linearGradient id="cNib" x1="0" y1="0" x2="1" y2="1">
            <stop offset="0" stop-color="#fff4d2"/><stop offset=".42" stop-color="#e2c273"/><stop offset="1" stop-color="#96721f"/>
          </linearGradient>
          <filter id="cSoft" x="-50%" y="-50%" width="200%" height="200%"><feGaussianBlur stdDeviation="2.2"/></filter>
          <filter id="cSoft2" x="-70%" y="-70%" width="240%" height="240%"><feGaussianBlur stdDeviation="5"/></filter>
          <filter id="cGlowF" x="-80%" y="-80%" width="260%" height="260%"><feGaussianBlur stdDeviation="9"/></filter>
        </defs>
        <g id="charRoot">
          <ellipse id="auraGlow" cx="180" cy="176" rx="156" ry="172" fill="url(#cAuraGlow)"/>
          <g id="auraRing">
            <ellipse cx="180" cy="176" rx="112" ry="126" fill="none" stroke="rgba(244,220,154,.32)" stroke-width="1.1" stroke-dasharray="3 9"/>
            <ellipse cx="180" cy="176" rx="139" ry="158" fill="none" stroke="rgba(244,220,154,.14)" stroke-width="1" stroke-dasharray="2 15"/>
          </g>
          <g id="sparks">
            <circle class="spk s1" cx="44" cy="142" r="2.3" fill="#ffe6a8" opacity=".5"/>
            <circle class="spk s2" cx="318" cy="118" r="1.7" fill="#ffdf95" opacity=".45"/>
            <circle class="spk s3" cx="62" cy="284" r="1.9" fill="#fff0c2" opacity=".4"/>
            <circle class="spk s4" cx="298" cy="280" r="2.5" fill="#ffe6a8" opacity=".42"/>
            <circle class="spk s5" cx="124" cy="66" r="1.5" fill="#fff3cf" opacity=".5"/>
            <circle class="spk s6" cx="248" cy="48" r="2.1" fill="#ffe9b0" opacity=".38"/>
          </g>
          <g id="desk">
            <path d="M4 394 L356 394 L378 426 L-18 426 Z" fill="url(#cDeskTop)"/>
            <rect x="0" y="425" width="360" height="45" fill="url(#cDeskFront)"/>
            <path d="M4 394 L356 394 L357 396 L3 396 Z" fill="#5b74ab" opacity=".8"/>
            <path d="M-18 426 L378 426 L378 428 L-18 428 Z" fill="#f0d489" opacity=".28"/>
            <ellipse cx="180" cy="412" rx="150" ry="7" fill="#04070e" opacity=".4" filter="url(#cSoft2)"/>
            <path d="M112 400 L300 400 L312 422 L100 422 Z" fill="#101a30"/>
            <path d="M112 400 L300 400 L301 402 L111 402 Z" fill="#8fa6d8" opacity=".22"/>
            <g id="doc">
              <path d="M146 402.5 L268 402.5 L278 420 L136 420 Z" fill="url(#cPaper)"/>
              <path d="M146 402.5 L268 402.5 L269 403.6 L145 403.6 Z" fill="#fff" opacity=".85"/>
              <g stroke="#2b3a56" stroke-width=".7" opacity=".38">
                <path d="M152 407.6 L262 407.2"/><path d="M151 410.6 L254 410.2"/><path d="M150 413.6 L246 413.2"/><path d="M149 416.6 L212 416.2"/>
              </g>
              <circle cx="266" cy="416" r="2.8" fill="url(#cTrim)" opacity=".9"/>
              <circle cx="266" cy="416" r="1.2" fill="#8a3a2a" opacity=".8"/>
            </g>
            <g id="cup">
              <ellipse cx="70" cy="412" rx="24" ry="6.4" fill="#04070e" opacity=".45"/>
              <ellipse cx="70" cy="410.4" rx="21" ry="6" fill="url(#cPorcelain)"/>
              <ellipse cx="70" cy="409.8" rx="21" ry="6" fill="none" stroke="#dfe5ee" stroke-width=".9"/>
              <path d="M54 391.6 C54 400 60 408.6 70 408.6 C80 408.6 86 400 86 391.6 Z" fill="#eef2f8"/>
              <path d="M56 392.6 C57 400.4 62 406.6 70 406.6 C74.6 406.6 78.4 404.6 81 400.4 C75.6 402.6 64.6 402.2 59 398.6 Z" fill="#a8b6cc" opacity=".55"/>
              <path d="M86.4 395 C91.6 394 94.8 397.6 93 401.4 C91.4 404.6 87.4 406 85 405.2" fill="none" stroke="#e8edf5" stroke-width="3.2" stroke-linecap="round"/>
              <ellipse cx="70" cy="391.6" rx="16" ry="5" fill="#eef1f7"/>
              <ellipse cx="70" cy="391.8" rx="13.6" ry="4.1" fill="#42230f"/>
              <ellipse cx="70" cy="391.8" rx="13.6" ry="4.1" fill="none" stroke="#c08a4e" stroke-width="1" opacity=".8"/>
              <ellipse cx="66.4" cy="390.9" rx="5.6" ry="1.5" fill="#7d4d28" opacity=".7"/>
              <ellipse cx="74.6" cy="392.9" rx="3.8" ry="1.1" fill="#2b1708" opacity=".5"/>
              <ellipse cx="70" cy="391.6" rx="16" ry="5" fill="none" stroke="#ffffff" stroke-width="2" opacity=".9"/><ellipse cx="70" cy="391.6" rx="13.6" ry="4.1" fill="none" stroke="#8a5a2e" stroke-width=".8" opacity=".6"/>
              <path d="M57 388 L57 400" stroke="#fff" stroke-width="1.5" opacity=".45"/>
              <g fill="none" stroke="#dfe9ff" stroke-linecap="round">
                <path class="steam" d="M63 383 C58.6 376 65 370 60.6 362 C57 356 63 350 60.6 343" stroke-width="1.5" opacity=".22"/>
                <path class="steam s2" d="M78 382 C82.4 375 76 369 80.4 361 C84 355 78 349 80.4 342" stroke-width="1.3" opacity=".18"/>
              </g>
            </g>
            <g id="scaleProp">
              <ellipse cx="34" cy="412" rx="16" ry="3.4" fill="#04070e" opacity=".5"/>
              <path d="M19 411 L49 411 L44.6 405.6 L23.4 405.6 Z" fill="url(#cTrim)"/>
              <rect x="32.4" y="358" width="3.2" height="48" rx="1.6" fill="url(#cTrim)"/>
              <rect x="30.4" y="354" width="7.2" height="5" rx="2.4" fill="url(#cTrim)"/>
              <path d="M11 360.6 C20 356.4 48 356.4 57 360.6" stroke="url(#cTrim)" stroke-width="2.3" fill="none"/>
              <circle cx="34" cy="358.6" r="2.6" fill="#f9ecbe"/>
              <g stroke="#c9a44e" stroke-width=".7" opacity=".9">
                <path d="M13 361.6 L7.6 374"/><path d="M13 361.6 L18.4 374"/><path d="M55 361.6 L49.6 374"/><path d="M55 361.6 L60.4 374"/>
              </g>
              <path d="M5 374.6 A9.4 9.4 0 0 0 21.4 374.6 Z" fill="url(#cTrim)"/>
              <path d="M46.6 374.6 A9.4 9.4 0 0 0 63 374.6 Z" fill="url(#cTrim)"/>
              <path d="M6.6 375.4 A8.2 8.2 0 0 0 19.8 375.4" fill="none" stroke="#fff6d8" stroke-width=".8" opacity=".7"/>
              <path d="M48.2 375.4 A8.2 8.2 0 0 0 61.4 375.4" fill="none" stroke="#fff6d8" stroke-width=".8" opacity=".7"/>
            </g>
            <g id="books">
              <ellipse cx="332" cy="412" rx="28" ry="4" fill="#04070e" opacity=".45"/>
              <path d="M306 402 L352 402 L354 412 L304 412 Z" fill="#6d2438"/>
              <path d="M306 402 L352 402 L352.4 404 L305.6 404 Z" fill="#a13a52" opacity=".8"/>
              <path d="M304 393 L350 393 L352 402.6 L302 402.6 Z" fill="#1d4034"/>
              <path d="M304 393 L350 393 L350.4 395 L303.6 395 Z" fill="#2f6a54" opacity=".85"/>
              <path d="M308 384 L352 384 L354 393.6 L306 393.6 Z" fill="#243a63"/>
              <path d="M308 384 L352 384 L352.4 386 L307.6 386 Z" fill="#3d5c94" opacity=".85"/>
              <g fill="none" stroke="#f0d489" stroke-width=".8" opacity=".7">
                <path d="M312 408 L348 408"/><path d="M310 399.4 L346 399.4"/><path d="M314 390.4 L348 390.4"/>
              </g>
            </g>
            <g id="gavelProp" transform="translate(288 406) rotate(-6)">
              <ellipse cx="24" cy="6" rx="34" ry="3" fill="#04070e" opacity=".45"/>
              <rect x="-6" y="-6.4" width="13.6" height="12.8" rx="3" fill="url(#cWood)"/>
              <rect x="-6" y="-6.4" width="13.6" height="3" rx="1.5" fill="#a8703f" opacity=".55"/>
              <circle cx="0.8" cy="0" r=".9" fill="#f0d489" opacity=".6"/>
              <path d="M6.6 -2.2 C30 -2.2 52 -3.4 74 -4.6 C76 -4.7 76 2.4 74 2.3 C52 1.1 30 0 6.6 0 Z" fill="url(#cWood)"/>
              <path d="M8 -1.8 C30 -1.8 52 -3 72 -4.2" fill="none" stroke="#b8825a" stroke-width="1.1" opacity=".55"/>
            </g>
          </g>
          <g id="body">
            <g id="hairBack" class="sway">
              <path d="M180 14 C144 14 114 30 104 68 C95 102 88 146 80 194 C74 234 70 286 68 328 C67 354 66 378 68 390 C72 406 88 408 98 398 C110 386 118 360 122 328 C126 294 130 260 134 230 C138 198 142 168 146 138 L214 138 C218 168 222 198 226 230 C230 260 234 294 238 328 C242 360 250 386 262 398 C272 408 288 406 292 390 C294 378 293 354 292 328 C290 286 286 234 280 194 C272 146 264 102 256 68 C246 30 216 14 180 14 Z" fill="url(#cHair)"/>
              <path d="M180 14 C144 14 114 30 104 68 C95 102 88 146 80 194 C74 234 70 286 68 328 C67 354 66 378 68 390 C72 406 88 408 98 398 C110 386 118 360 122 328 C126 294 130 260 134 230 C138 198 142 168 146 138 L128 138 C124 168 120 198 116 230 C112 266 106 302 100 328 C94 352 86 372 78 380 C70 388 66 380 66 372 C68 336 72 292 78 250 C86 198 94 146 104 104 C113 66 144 14 180 14 Z" fill="url(#cHairDark)" opacity=".45"/>
              <path d="M180 14 C216 14 246 30 256 68 C264 102 272 146 280 194 C286 234 290 286 292 328 C293 354 294 378 292 390 C288 406 272 408 262 398 C250 386 242 360 238 328 C234 294 230 260 226 230 C222 198 218 168 214 138 L232 138 C236 168 240 198 244 230 C248 266 254 302 260 328 C266 352 274 372 282 380 C290 388 294 380 294 372 C292 336 288 292 282 250 C274 198 266 146 256 104 C247 66 216 14 180 14 Z" fill="url(#cHairDark)" opacity=".2"/>
              <g stroke="url(#cHairHi)" fill="none" stroke-linecap="round" opacity=".42">
                <path d="M106 66 C97 112 90 168 84 222" stroke-width="3.4"/>
                <path d="M122 84 C113 130 106 186 101 238" stroke-width="2.1"/>
                <path d="M92 296 C88 334 84 366 82 386" stroke-width="2.6"/>
                <path d="M254 66 C263 112 270 168 276 222" stroke-width="3.4"/>
                <path d="M238 84 C247 130 254 186 259 238" stroke-width="2.1"/>
                <path d="M268 296 C272 334 276 366 278 386" stroke-width="2.6"/>
              </g>
            </g>
            <g id="neck">
              <path d="M158 196 L158 244 C158 260 164 272 174 280 L186 280 C196 272 202 260 202 244 L202 196 Z" fill="url(#cSkinArm)"/>
              <ellipse cx="180" cy="222" rx="27" ry="12" fill="#c2865f" opacity=".3" filter="url(#cSoft)"/>
              <path d="M160 206 C166 214 172 218 180 218 C188 218 194 214 200 206" fill="none" stroke="#c98a68" stroke-width="1.1" opacity=".28"/>
            </g>
            <g id="torso">
              <path d="M180 254 C146 254 116 268 98 286 C84 300 79 318 78 342 L76 404 L284 404 L282 342 C281 318 276 300 262 286 C244 268 214 254 180 254 Z" fill="url(#cBlazer)"/>
              <path d="M152 250 C160 262 170 276 176 294 L180 330 L184 294 C190 276 200 262 208 250 C198 244 162 244 152 250 Z" fill="url(#cBlouse)"/>
              <path d="M176 294 L180 330 L180 258 Z" fill="#d3c5ad" opacity=".5"/>
              <path d="M206 252 C198 240 162 240 154 252" fill="none" stroke="#e8dfcd" stroke-width="3" opacity=".8"/>
              <path d="M153 253 C162 266 172 280 177 296" stroke="url(#cBlazerLapel)" stroke-width="13" fill="none" stroke-linecap="round"/>
              <path d="M207 253 C198 266 188 280 183 296" stroke="url(#cBlazerLapel)" stroke-width="13" fill="none" stroke-linecap="round"/>
              <path d="M154.5 255 C163 268 172.5 282 178 298" stroke="url(#cTrim)" stroke-width="1.2" fill="none" opacity=".75"/>
              <path d="M205.5 255 C197 268 187.5 282 182 298" stroke="url(#cTrim)" stroke-width="1.2" fill="none" opacity=".75"/>
              <path d="M156 248 C166 258 194 258 204 248" stroke="#22304f" stroke-width="6.5" fill="none" stroke-linecap="round"/>
              <path d="M164 252 C172 262 180 274 184 288" stroke="#0e1729" stroke-width="1.4" fill="none" opacity=".5"/>
              <path d="M196 252 C188 262 180 274 176 288" stroke="#0e1729" stroke-width="1.4" fill="none" opacity=".5"/>
              <g fill="url(#cTrim)"><circle cx="196" cy="352" r="3.6"/><circle cx="197" cy="382" r="3.6"/></g>
              <g fill="#fff6d5" opacity=".75"><circle cx="194.8" cy="350.8" r="1.15"/><circle cx="195.8" cy="380.8" r="1.15"/></g>
              <path d="M100 282 C116 268 142 258 168 254" stroke="#89a4d6" stroke-width="2.6" fill="none" opacity=".3" filter="url(#cSoft)"/>
              <path d="M260 282 C244 268 218 258 192 254" stroke="#5c74a3" stroke-width="1.8" fill="none" opacity=".18" filter="url(#cSoft)"/>
              <path d="M104 288 C112 312 116 344 114 372" stroke="#0e1729" stroke-width="1.6" fill="none" opacity=".45"/>
              <path d="M256 288 C248 312 244 344 246 372" stroke="#0e1729" stroke-width="1.6" fill="none" opacity=".45"/>
              <g id="lapelPin" transform="translate(220 280) scale(.72)" color="#f4dc9a"><use href="#i-scale" width="24" height="24"/></g>
            </g>
            <g id="armL">
              <path d="M104 280 C90 300 82 328 84 354 C85 371 93 382 108 388 L130 394 C139 396 141 386 133 381 C116 372 107 357 104 336 C101 318 101 296 104 280 Z" fill="url(#cBlazer)"/>
              <path d="M106 284 C95 302 88 328 90 352" stroke="#7d97c9" stroke-width="2" fill="none" opacity=".28" filter="url(#cSoft)"/>
              <path d="M120 382 L142 391 L138 400 L116 392 Z" fill="#2b3c62"/>
              <path d="M121 383 L141 392" stroke="url(#cTrim)" stroke-width="1" fill="none" opacity=".75"/>
              <circle cx="134" cy="389" r="1.6" fill="url(#cTrim)"/>
              <path d="M134 388 C142 390 150 394 156 398 C159 400 157 405 153 404 C145 401 136 397 131 395 C127 393 129 386 134 388 Z" fill="url(#cSkinArm)"/>
            </g>
            <g id="armR">
              <path d="M256 280 C270 300 278 328 276 354 C275 371 267 382 252 388 L230 394 C221 396 219 386 227 381 C244 372 253 357 256 336 C259 318 259 296 256 280 Z" fill="url(#cBlazer)"/>
              <path d="M254 284 C265 302 272 328 270 352" stroke="#5c74a3" stroke-width="1.8" fill="none" opacity=".22" filter="url(#cSoft)"/>
              <path d="M240 382 L218 391 L222 400 L244 392 Z" fill="#2b3c62"/>
              <path d="M239 383 L219 392" stroke="url(#cTrim)" stroke-width="1" fill="none" opacity=".7"/>
              <circle cx="226" cy="389" r="1.6" fill="url(#cTrim)"/>
              <path d="M227 386 C219 388 211 392 206 396 C203 398 205 403 209 402 C217 399 226 395 231 393 C235 391 232 384 227 386 Z" fill="url(#cSkinArm)"/>
            </g>
            <g id="handL">
              <ellipse cx="160" cy="404" rx="38" ry="5.4" fill="#04070e" opacity=".32" filter="url(#cSoft)"/>
              <g transform="translate(150 391) rotate(-6)">
                <!-- کف/پشت دست -->
                <path d="M-23 -8.6 C-16 -11.6 -4 -12.6 6 -12 C12 -11.6 16.4 -9.4 18.6 -6 C21 -2.2 21 3.6 18.6 7.4 C16 11.4 10.6 13.6 3.4 13.8 C-6 14 -17 12 -21.4 8 C-24.6 5 -25.6 -1 -23 -8.6 Z" fill="url(#cSkinArm)" stroke="#bf7c5d" stroke-width=".55" stroke-opacity=".3"/>
                <path d="M-18 -6 C-10 -9.4 2 -10.2 10 -8.6 C14 -7.8 16.6 -6 18 -3.6 C11 -7.4 2 -8.6 -6 -7.4 C-11 -6.6 -15.4 -4.8 -18.4 -2.4 C-19.6 -3.8 -19.4 -5.2 -18 -6 Z" fill="#fff" opacity=".16"/>
                <path d="M-12 8.6 C-4 11 6 11.2 14 9" fill="none" stroke="#c98a68" stroke-width="1.6" opacity=".2" filter="url(#cSoft)"/>
                <!-- انگشتان افقی روی میز -->
                <g fill="url(#cSkinArm2)" stroke="#bf7c5d" stroke-width=".55" stroke-opacity=".45" stroke-linejoin="round">
                  <path d="M10 -12.4 C17 -13.6 25.6 -13.2 30.6 -11.4 C33.6 -10.3 34 -7.6 31.6 -7.1 C26 -6 17.6 -6.4 11 -7.6 C8.6 -8.1 8.2 -11.6 10 -12.4 Z"/>
                  <path d="M10 -6.4 C17.6 -7.6 26.4 -7.2 31.6 -5.4 C34.6 -4.3 35 -1.6 32.6 -1.1 C27 0 18.2 -0.4 11.6 -1.6 C9.2 -2.1 8.4 -5.6 10 -6.4 Z"/>
                  <path d="M10 -0.2 C17.6 -1.4 26.4 -1 31.6 0.8 C34.6 1.9 35 4.6 32.6 5.1 C27 6.2 18.2 5.8 11.6 4.6 C9.2 4.1 8.4 0.6 10 -0.2 Z"/>
                  <path d="M10.4 5.6 C17 4.6 24.4 5 28.8 6.6 C31.6 7.6 32 10.2 29.8 10.7 C24.8 11.8 17.6 11.4 12 10.4 C9.8 9.9 9 6.4 10.4 5.6 Z"/>
                </g>
                <!-- ناخن‌ها در نوک انگشتان -->
                <g fill="#fef1e7" opacity=".95">
                  <path d="M28.6 -12 C31.6 -11.6 33.4 -10.6 34 -9.4 C32 -8.6 29.6 -8.6 27.6 -9.2 Z"/>
                  <path d="M29.6 -6 C32.6 -5.6 34.4 -4.6 35 -3.4 C33 -2.6 30.6 -2.6 28.6 -3.2 Z"/>
                  <path d="M29.6 0.2 C32.6 0.6 34.4 1.6 35 2.8 C33 3.6 30.6 3.6 28.6 3 Z"/>
                  <path d="M27.4 5.6 C30.2 6.2 31.8 7.2 32.4 8.4 C30.6 9.2 28.4 9 26.6 8.2 Z"/>
                </g>
                <!-- بند انگشتان -->
                <g fill="none" stroke="#c98a68" stroke-width=".9" opacity=".5">
                  <path d="M18.6 -12.6 C18.8 -9 18.8 -6.4 18.6 -5.2"/>
                  <path d="M18.6 -6.6 C18.8 -3 18.8 -0.4 18.6 0.8"/>
                  <path d="M18.6 -0.4 C18.8 3.2 18.8 5.8 18.6 7"/>
                  <path d="M18.8 5.2 C19 8.4 19 10.4 18.8 11.4"/>
                </g>
                <!-- شست -->
                <path d="M-20 3 C-13 4.6 -5 7.4 0.6 11 C2.8 12.4 1.4 15.8 -0.8 15 C-6.6 12.8 -13.6 10.4 -19.6 8.8 C-23 8 -23.4 2 -20 3 Z" fill="url(#cSkinArm2)" stroke="#bf7c5d" stroke-width=".55" stroke-opacity=".4"/>
                <path d="M-12 5.6 C-6 7.4 -1.6 9.6 1.4 11.8" fill="none" stroke="#c98a68" stroke-width=".85" opacity=".5"/>
                <path d="M-4.6 12.6 C-2.8 12.6 -1.6 13.4 -1.4 14.6 C-2.8 15 -4.4 14.6 -5.6 13.8 Z" fill="#fef1e7" opacity=".9"/>
              </g>
            </g>
            <g id="handR">
              <ellipse cx="252" cy="404" rx="28" ry="5.2" fill="#04070e" opacity=".3" filter="url(#cSoft)"/>
              <g transform="translate(253 383) rotate(34)">
                <!-- پشت دست -->
                <path d="M2 -17 C8 -19.4 14 -18 17.6 -13 C20.6 -8.6 21.6 -2 20.6 4 C19.6 10 16 15 10 17 C4 18.8 -1.6 17 -4.6 12.6 C-7.6 8.2 -8 1.4 -6.4 -5 C-4.4 -11.6 -2 -15 2 -17 Z" fill="url(#cSkinArm)" stroke="#bf7c5d" stroke-width=".55" stroke-opacity=".3"/>
                <path d="M4 -15.4 C9 -17.6 14 -16.4 17 -12.2 C19.4 -8.6 20.4 -3 19.8 2 C15.6 -3.6 9.6 -6.6 3 -6.2 C-0.6 -6 -3.6 -5 -6 -3.2 C-5.2 -8 -3.6 -12.4 4 -15.4 Z" fill="#fff" opacity=".13"/>
                <!-- برجستگی مفاصل -->
                <g fill="none" stroke="#c98a68" stroke-width=".95" opacity=".45">
                  <path d="M-2 -10.6 C2 -12.6 7 -12.8 11 -11.4"/>
                  <path d="M0 -5.6 C4 -7.8 9 -8.2 13.4 -7"/>
                  <path d="M1.4 -0.6 C5.4 -2.6 10.4 -2.8 14.6 -1.4"/>
                  <path d="M-3.4 -4 C-2 -8.4 0.4 -12.6 3.6 -15.6" stroke-width=".7" opacity=".35"/>
                  <path d="M-1 -3.4 C1.4 -0.4 4.4 2 8 3.4" stroke-width=".7" opacity=".3"/>
                </g>
                <!-- حلقه/کوچک جمع‌شده -->
                <g fill="url(#cSkinArm2)" stroke="#bf7c5d" stroke-width=".55" stroke-opacity=".45" stroke-linejoin="round">
                  <path d="M12.6 4.6 C15.6 3 18.6 3.4 20.2 5.6 C21.4 7.4 20.4 9.6 18 10.2 C16 10.7 13.8 10.2 12.8 9 C12 8 12 5.8 12.6 4.6 Z"/>
                  <path d="M10.4 9.6 C13 9 15.6 9.6 16.8 11.4 C17.8 13 16.8 14.8 14.6 15.2 C12.8 15.5 11 15 10.2 13.8 C9.6 12.8 9.8 10.6 10.4 9.6 Z"/>
                </g>
                <!-- انگشت میانی/حلقه روی خودکار: بندها با نوک مشخص -->
                <g fill="url(#cSkinArm2)" stroke="#bf7c5d" stroke-width=".55" stroke-opacity=".5" stroke-linejoin="round">
                  <path d="M0.6 1.4 C-2.4 -1 -5.6 -3 -8.4 -4 C-9.6 -4.4 -9.8 -6 -8.6 -6.6 C-5.6 -8 0.4 -6.6 4.4 -3.6 C7.4 -1.4 9.8 1.2 11.2 4.4 C11.6 5.4 9 6.2 8.2 5 C6.4 2.8 3.6 1.6 0.6 1.4 Z"/>
                  <path d="M2.6 6.6 C-0.6 4.4 -3.6 2.8 -6.2 2.2 C-7.4 2 -7.6 0.4 -6.4 -0.2 C-3.4 -1.4 2.2 -0.2 5.8 2.6 C8.6 4.8 10.6 7.4 11.8 10.2 C12.2 11.2 9.6 11.8 8.8 10.6 C7.2 8.6 4.6 7.6 2.6 6.6 Z"/>
                </g>
                <g fill="none" stroke="#c98a68" stroke-width=".85" opacity=".5">
                  <path d="M-7.2 -4.6 C-4.2 -3.8 -1 -2.2 1.6 -0.2"/>
                  <path d="M-5.2 2 C-2.4 2.6 0.4 3.8 2.6 5.4"/>
                </g>
                <!-- خودکار -->
                <g id="penRig">
                  <g id="penGold">
                    <rect x="-2.6" y="-31" width="5.2" height="46" rx="2.6" fill="url(#cPenBody)"/>
                    <rect x="-1.8" y="-30" width=".9" height="42.6" rx=".45" fill="#d3e2ff" opacity=".3"/>
                    <rect x="1.05" y="-29" width=".75" height="39.6" rx=".37" fill="#080e18" opacity=".55"/>
                    <rect x="-2.7" y="-29.2" width="5.4" height="2.4" rx="1" fill="url(#cTrim)"/>
                    <path d="M2.4 -29.4 C4.9 -28.2 5.6 -23.4 4.9 -19.2" stroke="url(#cTrim)" stroke-width="1.7" fill="none" stroke-linecap="round"/>
                    <rect x="-2.7" y="12.4" width="5.4" height="1.5" rx=".75" fill="url(#cTrim)"/>
                    <rect x="-2.4" y="13.8" width="4.8" height="7" fill="#0c1424" opacity=".92"/>
                    <g stroke="#33456c" stroke-width=".45" opacity=".55">
                      <path d="M-2.3 14.9 L2.3 14.9"/><path d="M-2.3 16.4 L2.3 16.4"/><path d="M-2.3 17.9 L2.3 17.9"/>
                    </g>
                    <path d="M-2.2 20.8 L2.2 20.8 L1.1 26.8 C0.9 28 0.55 28.8 0 29.6 C-0.55 28.8 -0.9 28 -1.1 26.8 Z" fill="url(#cNib)"/>
                    <path d="M0 22.2 L0 28.2" stroke="#3a2a08" stroke-width=".45" opacity=".85"/>
                    <circle cx="0" cy="22.4" r=".55" fill="#2a1e05"/>
                    <path d="M-1.15 21.2 L-1.15 26" stroke="#fff8de" stroke-width=".45" opacity=".75"/>
                    <path d="M1.15 21.2 L1.15 25.6" stroke="#8a661c" stroke-width=".35" opacity=".6"/>
                    <circle cx="0" cy="30" r=".65" fill="#12305a"/>
                  </g>
                </g>
                <!-- اشاره از بالا روی بدنهٔ خودکار -->
                <path d="M6.4 -13.4 C2.4 -15.4 -1.6 -14.6 -4.4 -11.6 C-6.4 -9.6 -6.6 -6.6 -4.8 -5.4 C-2.4 -3.8 1.4 -4.4 4.2 -6.6 C6.4 -8.4 8.6 -10.6 10.4 -12.4 C11.6 -13.6 8.4 -12.4 6.4 -13.4 Z" fill="url(#cSkinArm2)" stroke="#bf7c5d" stroke-width=".55" stroke-opacity=".45"/>
                <path d="M6 -14.2 C2.4 -15.8 -1 -15.2 -3.6 -12.8" fill="none" stroke="#fff" stroke-width="1.1" opacity=".22"/>
                <path d="M-5.2 -8.8 C-6.6 -8 -6.8 -6.2 -5.6 -5.4 C-4.6 -4.8 -3.4 -5.2 -2.8 -6.2" fill="none" stroke="#bf7c5d" stroke-width=".55" opacity=".4"/>
                <!-- شست از پایین، نوک روی گریپ -->
                <path d="M1.6 16.6 C-1.6 13 -5 10.4 -8.4 8.8 C-10 8.2 -10.6 6 -9 5.2 C-4.8 2.6 0 4.6 3.6 7.8 C6.6 10.4 9 13.6 10.4 16.8 C11.4 19.2 9 20.2 6.8 19 Z" fill="url(#cSkinArm2)" stroke="#bf7c5d" stroke-width=".55" stroke-opacity=".45"/>
                <path d="M-6 7.6 C-3.2 9.4 0.4 11.8 3 14.4" fill="none" stroke="#fff" stroke-width="1.1" opacity=".2"/>
                <path d="M-9 7.8 C-10.6 7.6 -11.4 6.4 -10.8 5.4 C-10 4.2 -8.4 4.4 -7.6 5.4 Z" fill="#fef1e7" opacity=".9"/>
              </g>
            </g>
            <g id="head">
              <g id="headTilt">
                <path d="M112 136 C104 134 99 141 101 151 C103 162 110 168 116 166 C120 164 120 154 118 146 C116 140 115 137 112 136 Z" fill="url(#cSkinArm)"/>
                <g id="earringL"><circle cx="112" cy="166" r="3.1" fill="url(#cTrim)"/><circle cx="111" cy="165" r="1" fill="#fff8dc" opacity=".85"/><path d="M112 169 C112 171.4 112 172.6 112 173.6" stroke="url(#cTrim)" stroke-width="1" opacity=".8"/><circle cx="112" cy="175" r="1.7" fill="#f7e7b2"/></g>
                <path d="M248 136 C256 134 261 141 259 151 C257 162 250 168 244 166 C240 164 240 154 242 146 C244 140 245 137 248 136 Z" fill="url(#cSkinArm)"/>
                <g id="earringR"><circle cx="248" cy="166" r="3.1" fill="url(#cTrim)"/><circle cx="247" cy="165" r="1" fill="#fff8dc" opacity=".85"/><path d="M248 169 C248 171.4 248 172.6 248 173.6" stroke="url(#cTrim)" stroke-width="1" opacity=".8"/><circle cx="248" cy="175" r="1.7" fill="#f7e7b2"/></g>
                <path d="M180 56 C222 56 253 86 253 128 C253 156 245 182 231 201 C218 218 199 228 180 228 C161 228 142 218 129 201 C115 182 107 156 107 128 C107 86 138 56 180 56 Z" fill="url(#cSkin)"/>
                <path d="M180 228 C161 228 142 218 129 201 C140 210 158 216 180 216 C202 216 220 210 231 201 C218 218 199 228 180 228 Z" fill="#d89a78" opacity=".22" filter="url(#cSoft)"/>
                <ellipse cx="180" cy="84" rx="46" ry="14" fill="#fff" opacity=".16" filter="url(#cSoft)"/>
                <ellipse cx="120" cy="162" rx="20" ry="16" fill="#d18f6e" opacity=".17" filter="url(#cSoft)"/>
                <ellipse cx="240" cy="162" rx="20" ry="16" fill="#d18f6e" opacity=".17" filter="url(#cSoft)"/>
                <ellipse cx="126" cy="172" rx="19" ry="11" fill="url(#cBlush)"/>
                <ellipse cx="234" cy="172" rx="19" ry="11" fill="url(#cBlush)"/>
                <ellipse cx="128" cy="150" rx="9" ry="5" fill="#fff" opacity=".22" filter="url(#cSoft)"/>
                <ellipse cx="232" cy="150" rx="9" ry="5" fill="#fff" opacity=".22" filter="url(#cSoft)"/>
                <ellipse cx="180" cy="214" rx="10" ry="4.6" fill="#fff" opacity=".16" filter="url(#cSoft)"/>
                <ellipse cx="180" cy="116" rx="54" ry="9" fill="#c98a68" opacity=".14" filter="url(#cSoft)"/>
                <path d="M108 130 C110 154 118 180 130 196" fill="none" stroke="#f7cdae" stroke-width="2.6" opacity=".5" filter="url(#cSoft)"/>
                <path d="M234 140 C240 160 240 180 232 198" fill="none" stroke="#cf8d6c" stroke-width="3.4" opacity=".22" filter="url(#cSoft)"/>
                <path d="M133 200 C146 216 164 224 180 224 C196 224 214 216 227 200" fill="none" stroke="#cf8d6c" stroke-width="3" opacity=".2" filter="url(#cSoft)"/>
                <ellipse cx="180" cy="220" rx="18" ry="5" fill="#fff" opacity=".13" filter="url(#cSoft)"/>
                <path d="M166.5 212.5 C172 215 188 215 193.5 212.5" fill="none" stroke="#c98a6a" stroke-width="1.6" opacity=".18" filter="url(#cSoft)"/>
                <g id="lensFill">
                  <rect x="122" y="118" width="48" height="44" rx="19" fill="url(#cLens)"/>
                  <rect x="190" y="118" width="48" height="44" rx="19" fill="url(#cLens)"/>
                </g>
                <g id="eyes">
                  <g id="eyeL">{EYE_L}</g>
                  <g id="eyeR"><g data-flip="1" transform="translate(360 0) scale(-1 1)">{EYE_R}</g></g>
                </g>
                <g id="brows">
                  <g class="bNeutral" style="opacity:1">
                    <path d="M174 103.4 C165.4 97.6 152.6 96.4 143.4 99.6 C138.2 101.4 134.8 105 133 109.6 C132.3 111.6 134 113.6 135.8 112.6 C140.2 109.8 145.6 107 152.4 106 C159.2 105 166 105.6 171 107.8 C172.8 108.6 174.6 104.8 174 103.4 Z" fill="url(#cBrow)"/>
                    <g transform="translate(360 0) scale(-1 1)">
                      <path d="M172 106.6 C164.4 101.4 153 100 144.4 102.6 C139.6 104 136 107 134 110.8 C133.2 112.6 134.6 114.2 136.2 113.2 C140.2 111 145.2 108.4 151.6 107.4 C158.2 106.2 165.4 106.4 170.6 108.4 C172.2 109 172.9 107.5 172 106.6 Z" fill="url(#cBrow)"/>
                    </g>
                  </g>
                  <g class="bRaise" style="opacity:0">
                    <path d="M174 99.6 C164.6 93 151 91.4 141.4 95 C136.8 96.8 133.8 100.4 131.8 104.8 C131 106.8 132.6 108.6 134.2 107.6 C138.8 104.8 143.6 101.4 151.4 100.2 C158.6 99 166 99.6 171 101.8 C172.8 102.6 174.6 101 174 99.6 Z" fill="url(#cBrow)"/>
                    <g transform="translate(360 0) scale(-1 1)">
                      <path d="M172 103.2 C163.6 97 151.4 95.6 142.6 99 C138.4 100.8 135.6 104 133.8 108 C133 109.8 134.4 111.4 135.8 110.4 C139.8 108 144.4 105 151.6 104 C158.4 102.8 165.6 103.2 170.6 105.2 C172.2 105.8 172.9 104.2 172 103.2 Z" fill="url(#cBrow)"/>
                    </g>
                  </g>
                  <g class="bFrown" style="opacity:0">
                    <path d="M175 112.2 C166.6 106.2 153.6 105.8 145.4 109.6 C141 111.6 137.8 115 135.6 118.8 C134.6 120.6 136.2 122.6 138 121.6 C142.2 119.2 145.6 116.4 151.6 114.8 C157.8 113 165 113 170.8 114.2 C172.8 114.6 175.8 113.6 175 112.2 Z" fill="url(#cBrow)"/>
                    <g transform="translate(360 0) scale(-1 1)">
                      <path d="M173 113.6 C165.4 109.4 153.8 109.6 146.4 112.8 C142.2 114.6 139.2 117.8 137.2 121.2 C136.2 122.8 137.6 124.4 139.2 123.4 C142.6 121.4 145.6 119 151 117.4 C157 115.6 164 115.4 170.6 116.4 C172.6 116.8 173.8 114.4 173 113.6 Z" fill="url(#cBrow)"/>
                    </g>
                  </g>
                </g>
                <path d="M179.4 150 C177.8 159 176.6 168 176.8 175" fill="none" stroke="#d18f6e" stroke-width="2.4" opacity=".42" filter="url(#cSoft)"/>
                <path d="M180.6 150 C182.2 159 183.4 168 183.2 175" fill="none" stroke="#ffe4d2" stroke-width="2.6" opacity=".45" filter="url(#cSoft)"/>
                <path d="M170.8 179.4 C170.8 172.8 174.4 169.2 180 169.2 C185.6 169.2 189.2 172.8 189.2 179.4 C189.2 184.4 185.6 188.8 180 188.8 C174.4 188.8 170.8 184.4 170.8 179.4 Z" fill="#f8c9a9"/>
                <path d="M170.8 179.4 C170.8 172.8 174.4 169.2 180 169.2 C185.6 169.2 189.2 172.8 189.2 179.4 C189.2 182.6 187.6 185.4 185 187.1 C186.3 182.6 180.6 179.2 176 180.3 C173.3 181 171.7 183.2 171.5 186.1 C171.1 183.9 170.8 181.6 170.8 179.4 Z" fill="#e3a686" opacity=".55"/>
                <path d="M170.4 181.2 C169.6 184.2 170.4 186.6 172.4 187.4" fill="none" stroke="#bd7c5e" stroke-width="1.6" opacity=".85" stroke-linecap="round"/>
                <path d="M189.6 181.2 C190.4 184.2 189.6 186.6 187.6 187.4" fill="none" stroke="#bd7c5e" stroke-width="1.6" opacity=".85" stroke-linecap="round"/>
                <ellipse cx="180" cy="173.6" rx="3" ry="5" fill="#fff" opacity=".28" filter="url(#cSoft)"/>
                <ellipse cx="180.6" cy="185" rx="2.8" ry="1.9" fill="#fff" opacity=".42"/>
                <path d="M180 189.6 C180 191.4 180 192.6 180 193.6" fill="none" stroke="#c98a6a" stroke-width="1" opacity=".25"/>
                <ellipse cx="180" cy="192.4" rx="7" ry="3" fill="#c98a6a" opacity=".13" filter="url(#cSoft)"/>
                <g id="mouth">
                  <g id="mLine" style="opacity:1">
                    <path d="M161.4 197.2 C167.4 192.8 173.4 191.6 180 194.4 C186.6 191.6 192.6 192.8 198.6 197.2 C193.4 199.8 187.6 201 180 201 C172.4 201 166.6 199.8 161.4 197.2 Z" fill="url(#cLip)"/>
                    <path d="M163.4 199.8 C166.6 208.4 172 212.8 180 212.8 C188 212.8 193.4 208.4 196.6 199.8 C191.2 203 168.8 203 163.4 199.8 Z" fill="url(#cLipLow)"/>
                    <path d="M161.6 198.4 C167.8 195.8 192.2 195.8 198.4 198.4" fill="none" stroke="#8a3548" stroke-width="1.1" opacity=".7"/>
                    <path d="M174 200.4 C176.4 201.4 183.6 201.4 186 200.4" fill="none" stroke="#fff" stroke-width=".9" opacity=".18"/>
                    <ellipse cx="181.4" cy="206.8" rx="4.6" ry="1.9" fill="#fff" opacity=".26"/>
                    <path d="M160.4 196 C159.8 197.6 160 199.4 161 200.6" fill="none" stroke="#8a3548" stroke-width=".9" opacity=".5"/>
                    <path d="M199.6 196 C200.2 197.6 200 199.4 199 200.6" fill="none" stroke="#8a3548" stroke-width=".9" opacity=".5"/>
                  </g>
                  <g id="mSmile" style="opacity:0">
                    <path d="M157.6 196.6 C164.6 191.8 172.6 190.6 180 193.6 C187.4 190.6 195.4 191.8 202.4 196.6 C196 200.2 188.6 201.8 180 201.8 C171.4 201.8 164 200.2 157.6 196.6 Z" fill="url(#cLip)"/>
                    <path d="M159.8 199.4 C163.4 209.6 170.4 215 180 215 C189.6 215 196.6 209.6 200.2 199.4 C193.4 203.4 166.6 203.4 159.8 199.4 Z" fill="url(#cLipLow)"/>
                    <path d="M157.8 198 C165.6 195 194.4 195 202.2 198" fill="none" stroke="#8a3548" stroke-width="1.1" opacity=".7"/>
                    <ellipse cx="181.4" cy="208.6" rx="5" ry="2" fill="#fff" opacity=".28"/>
                    <path d="M156.6 195.4 C155.8 197.2 156 199.2 157 200.4" fill="none" stroke="#8a3548" stroke-width="1" opacity=".45"/>
                    <path d="M203.4 195.4 C204.2 197.2 204 199.2 203 200.4" fill="none" stroke="#8a3548" stroke-width="1" opacity=".45"/>
                  </g>
                  <g id="mOpen" style="opacity:0">
                    <path d="M161.6 196.8 C167.6 192.8 173.4 191.8 180 194.2 C186.6 191.8 192.4 192.8 198.4 196.8 C193.2 199.2 187.4 200.4 180 200.4 C172.6 200.4 166.8 199.2 161.6 196.8 Z" fill="url(#cLip)"/>
                    <ellipse cx="180" cy="205.6" rx="9.6" ry="7.2" fill="#5d2230"/>
                    <ellipse cx="180" cy="209.2" rx="6" ry="3.2" fill="#a8455c" opacity=".85"/>
                    <path d="M171.6 202.4 C174.8 201.5 185.2 201.5 188.4 202.4 C185.6 203.6 174.4 203.6 171.6 202.4 Z" fill="#fffaf4" opacity=".92"/>
                    <path d="M163.2 199.8 C167 207.2 172 211.2 180 211.2 C188 211.2 193 207.2 196.8 199.8 C191.4 202.8 168.6 202.8 163.2 199.8 Z" fill="url(#cLipLow)"/>
                    <path d="M161.6 198.4 C167.8 196.2 192.2 196.2 198.4 198.4" fill="none" stroke="#8a3548" stroke-width="1" opacity=".65"/>
                  </g>
                  <g id="mO" style="opacity:0">
                    <ellipse cx="180" cy="204" rx="5.6" ry="6.2" fill="#5d2230"/>
                    <ellipse cx="180" cy="206.6" rx="3.1" ry="2.7" fill="#a8455c" opacity=".7"/>
                    <ellipse cx="180" cy="204" rx="5.6" ry="6.2" fill="none" stroke="url(#cLip)" stroke-width="2.6"/>
                    <ellipse cx="177.8" cy="201.6" rx="1.6" ry="1.1" fill="#fff" opacity=".4"/>
                  </g>
                </g>
                <g id="glasses">
                  <path d="M124 132 C116 132.6 110.6 136.4 107.6 142.4" fill="none" stroke="url(#cFrame)" stroke-width="2.5" stroke-linecap="round"/>
                  <path d="M236 132 C244 132.6 249.4 136.4 252.4 142.4" fill="none" stroke="url(#cFrame)" stroke-width="2.5" stroke-linecap="round"/>
                  <rect x="122" y="118" width="48" height="44" rx="19" fill="none" stroke="url(#cFrame)" stroke-width="3.1"/>
                  <rect x="190" y="118" width="48" height="44" rx="19" fill="none" stroke="url(#cFrame)" stroke-width="3.1"/>
                  <path d="M168.4 130.4 C170.6 126.2 172.6 126.2 174.6 130.4 C176.6 134.4 178.4 134.4 180.4 130.4 C182.4 126.2 184.4 126.2 186.6 130.4" fill="none" stroke="url(#cFrame)" stroke-width="2.8" stroke-linecap="round"/>
                  <path d="M122 132.6 C126 125.6 133.6 121.6 141 121.4" fill="none" stroke="#fff8dc" stroke-width="1.4" opacity=".72"/>
                  <path d="M190 132.6 C194 125.6 201.6 121.6 209 121.4" fill="none" stroke="#fff8dc" stroke-width="1.4" opacity=".72"/>
                  <path d="M124 158 C128 161.6 134 163.4 140 163.4" fill="none" stroke="#fff8dc" stroke-width=".9" opacity=".3"/>
                  <path d="M192 158 C196 161.6 202 163.4 208 163.4" fill="none" stroke="#fff8dc" stroke-width=".9" opacity=".3"/>
                  <clipPath id="cLensClip">
                    <rect x="122" y="118" width="48" height="44" rx="19"/>
                    <rect x="190" y="118" width="48" height="44" rx="19"/>
                  </clipPath>
                  <g clip-path="url(#cLensClip)">
                    <g transform="rotate(22 180 140)">
                      <rect id="lensGlint" x="112" y="96" width="12" height="92" fill="#fff" opacity=".07"/>
                      <rect x="128" y="96" width="4.5" height="92" fill="#fff" opacity=".05"/>
                    </g>
                  </g>
                </g>
                <g id="hairFront" class="sway2">
                  <path d="M180 14 C144 14 114 30 106 68 C98 102 94 140 94 178 C94 214 98 250 106 284 C110 304 116 320 124 330 C132 340 146 334 144 320 C137 296 132 268 131 238 C130 212 131 186 133 162 C134 144 136 128 140 118 C148 100 162 92 180 92 C198 92 212 100 220 118 C224 128 226 144 227 162 C229 186 230 212 229 238 C228 268 225 296 220 320 C218 334 232 340 240 330 C248 320 252 304 254 284 C262 250 266 214 266 178 C266 140 262 102 254 68 C246 30 216 14 180 14 Z" fill="url(#cHair)"/>
                  <path d="M180 14 C144 14 114 30 106 68 C98 102 94 140 94 178 C94 214 98 250 106 284 C110 302 116 316 122 326 C130 338 144 334 142 320 C136 296 132 268 131 238 C130 212 131 186 133 162 C134 146 136 132 140 122 C130 138 126 160 125 186 C124 214 126 244 130 272 C132 288 128 298 122 296 C114 292 108 278 104 260 C97 228 94 200 94 176 C94 138 102 96 112 72 C122 42 146 16 180 14 Z" fill="url(#cHairDark)" opacity=".4"/>
                  <path d="M180 14 C216 14 246 30 254 68 C262 102 266 140 266 178 C266 214 262 250 254 284 C250 302 244 316 238 326 C230 338 216 334 218 320 C224 296 228 268 229 238 C230 212 229 186 227 162 C226 144 224 128 220 118 C212 100 198 92 180 92 C162 92 148 100 140 118 C136 128 134 144 133 162 C131 186 130 212 131 238 C132 268 136 296 142 320 C144 334 130 338 122 326 C116 316 110 302 106 284 C98 250 94 214 94 178 C94 140 98 102 106 68 C114 30 144 14 180 14 Z" fill="url(#cHairDark)" opacity=".14"/>
                  <path d="M180 20 C142 20 118 42 112 78 C106 112 104 150 106 186 C108 218 112 248 118 274 C114 246 112 214 112 182 C112 146 116 112 124 90 C134 64 154 52 180 52 C206 52 226 64 236 90 C244 112 248 146 248 182 C248 214 246 246 242 274 C248 248 252 218 254 186 C256 150 254 112 248 78 C242 42 218 20 180 20 Z" fill="url(#cHairHi)" opacity=".26"/>
                  <path d="M180 16 C140 16 112 36 104 74 C96 110 94 148 94 184 C94 196 94 208 95 218 C98 168 104 118 116 88 C128 58 150 44 180 44 C210 44 232 58 244 88 C256 118 262 168 265 218 C266 208 266 196 266 184 C266 148 264 110 256 74 C248 36 220 16 180 16 Z" fill="#fff6d8" opacity=".3"/>
                  <!-- فرق کناری و لایه‌های فرق -->
                  <path d="M169 24 C166 44 161 68 154 90" fill="none" stroke="#a8762f" stroke-width="2" opacity=".28" stroke-linecap="round"/>
                  <path d="M173 26 C178 46 188 68 199 88" fill="none" stroke="#a8762f" stroke-width="1.8" opacity=".22" stroke-linecap="round"/>
                  <path d="M160 28 C150 50 138 74 128 96" fill="none" stroke="#c08f45" stroke-width="1.8" opacity=".3" stroke-linecap="round"/>
                  <path d="M204 30 C214 52 224 76 232 98" fill="none" stroke="#c08f45" stroke-width="1.8" opacity=".26" stroke-linecap="round"/>
                  <path d="M167 24 C160 46 153 72 149 94" fill="none" stroke="#fff8e0" stroke-width="1.3" opacity=".38" stroke-linecap="round"/>
                  <path d="M175 26 C185 48 193 74 199 96" fill="none" stroke="#fff8e0" stroke-width="1.3" opacity=".34" stroke-linecap="round"/>
                  <!-- خط رویش نرم (بدون بریدگی) -->
                  <path d="M136 92 C130 98 126 108 124 118 C131 108 139 98 148 90 Z" fill="url(#cHair)" opacity=".55"/>
                  <path d="M216 90 C224 98 232 108 238 118 C236 106 228 96 222 88 Z" fill="url(#cHair)" opacity=".45"/>
                  <!-- سایهٔ زیر مو روی پیشانی -->
                  <path d="M132 112 C146 96 162 88 180 88 C198 88 214 96 226 112" fill="none" stroke="#c98a68" stroke-width="5" opacity=".2" filter="url(#cSoft)"/>
                  <!-- موج و شکست در لبهٔ بیرونی مو -->
                  <path d="M104 176 C100 200 100 226 104 250" fill="none" stroke="#b98a42" stroke-width="3" opacity=".22" stroke-linecap="round"/>
                  <path d="M256 176 C260 200 260 226 256 250" fill="none" stroke="#b98a42" stroke-width="3" opacity=".22" stroke-linecap="round"/>
                  <path d="M100 240 C98 262 100 284 106 302" fill="none" stroke="#fff3cf" stroke-width="2" opacity=".3" stroke-linecap="round"/>
                  <path d="M260 240 C262 262 260 284 254 302" fill="none" stroke="#fff3cf" stroke-width="2" opacity=".3" stroke-linecap="round"/>
                  <g fill="none" stroke="url(#cHairHi)" stroke-linecap="round" opacity=".32">
                    <path d="M144 34 C126 52 114 84 110 122" stroke-width="2.3"/>
                    <path d="M162 24 C142 36 128 64 122 100" stroke-width="1.7"/>
                    <path d="M216 34 C234 52 246 84 250 122" stroke-width="2.3"/>
                    <path d="M198 24 C218 36 232 64 238 100" stroke-width="1.7"/>
                  </g>
                  <g fill="none" stroke="#b98a42" opacity=".3" stroke-linecap="round">
                    <path d="M138 116 C132 142 129 172 129 204" stroke-width="1.6"/>
                    <path d="M222 116 C228 142 231 172 231 204" stroke-width="1.6"/>
                  </g>
                  <path d="M180 14 C144 14 114 30 106 68 C98 102 94 140 94 178 C94 214 98 250 106 284 C110 302 116 316 122 326 C126 332 132 334 136 330 C128 316 122 298 118 278 C110 240 106 200 108 162 C110 120 118 76 130 54 C142 32 158 20 180 14 Z" fill="#fff8e2" opacity=".22"/>
                  <path d="M118 108 C138 90 162 80 184 82" fill="none" stroke="#d0a45c" stroke-width="4" opacity=".25" filter="url(#cSoft)"/>
                  <path d="M112 250 C110 276 112 300 120 318" fill="none" stroke="#fff3cf" stroke-width="1.6" opacity=".35"/>
                  <path d="M248 250 C250 276 248 300 240 318" fill="none" stroke="#fff3cf" stroke-width="1.6" opacity=".35"/>
                  <path d="M126 300 C124 314 126 326 132 332" fill="none" stroke="#c69a55" stroke-width="2.4" opacity=".3"/>
                  <path d="M234 300 C236 314 234 326 228 332" fill="none" stroke="#c69a55" stroke-width="2.4" opacity=".3"/>
                </g>
              </g>
            </g>
          </g>
        </g>
      </svg>'''
EYE_L = EYE_UNIT.replace('{CLIP}', 'clipEyeL')
EYE_R = EYE_UNIT.replace('{CLIP}', 'clipEyeR')
SVG = SVG_HEAD.replace('{EYE_L}', EYE_L).replace('{EYE_R}', EYE_R)

def main():
    s = io.open(HTML, encoding='utf-8').read()
    start = s.index('<svg id="charSvg"')
    anchor = s.index('id="desk"')
    end = s.index('</svg>', anchor) + len('</svg>')
    old = s[start:end]
    s = s[:start] + SVG + s[end:]
    # گاردِ تایپوی رنگ
    io.open(HTML, 'w', encoding='utf-8').write(s)
    print('replaced bytes:', len(old), '->', len(SVG))
    print('charSvg present:', 'id="charSvg"' in s, s.count('id="charSvg"'))
    print('eye irises:', s.count('class="iris"'), '| pupils:', s.count('class="pupil"'),
          '| shines:', s.count('class="shine"'), s.count('class="shine2"'))
    print('flip groups:', s.count('data-flip'))
    need = ['charRoot', 'auraGlow', 'auraRing', 'sparks', 'hairBack', 'torso', 'lapelPin', 'armL', 'armR',
            'handL', 'handR', 'penRig', 'penGold', 'neck', 'head', 'headTilt', 'eyes', 'eyeL', 'eyeR',
            'mLine', 'mOpen', 'mSmile', 'mO', 'glasses', 'lensGlint', 'hairFront', 'desk', 'cup',
            'scaleProp', 'gavelProp', 'bNeutral', 'bRaise', 'bFrown']
    missing = [n for n in need if ('id="%s"' % n) not in s and ('class="%s"' % n) not in s]
    print('missing ids/classes:', missing if missing else 'none')
    print('mOpen has ellipse:', '</ellipse>' in s.split('id="mOpen"')[1].split('</g>')[0])

if __name__ == '__main__':
    main()
