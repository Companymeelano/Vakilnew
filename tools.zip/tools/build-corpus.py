#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""Fetch full Iranian law texts from Wikisource -> structured offline corpus."""
import json, re, time, urllib.request, urllib.parse

UA = {'User-Agent': 'VakilApp/1.0 (offline legal corpus builder)'}
API = 'https://fa.wikisource.org/w/api.php'
FA = str.maketrans('۰۱۲۳۴۵۶۷۸۹', '0123456789')

def api(params, tries=6):
    params = dict(params); params['format'] = 'json'
    url = API + '?' + urllib.parse.urlencode(params)
    for i in range(tries):
        try:
            return json.load(urllib.request.urlopen(urllib.request.Request(url, headers=UA), timeout=70))
        except Exception:
            time.sleep(4 + i * 4)
    return {}

def extract(title):
    r = api({'action': 'query', 'prop': 'extracts', 'explaintext': 1, 'titles': title, 'redirects': 1})
    for _, v in r.get('query', {}).get('pages', {}).items():
        return v.get('extract') or ''
    return ''

def subpages(prefix, limit=200):
    r = api({'action': 'query', 'list': 'allpages', 'apprefix': prefix, 'aplimit': limit, 'apnamespace': 0})
    return [p['title'] for p in r.get('query', {}).get('allpages', [])]

def clean(t):
    t = t.replace('\u200c', ' ').replace('\u200f', '').replace('\u200e', '').replace('\ufeff', '')
    t = re.sub(r'\[[0-9۰-۹]+\]', '', t)
    t = re.sub(r'\{\{[^}]*\}\}', ' ', t)
    t = re.sub(r'[ \t]+', ' ', t)
    return re.sub(r'\n{3,}', '\n\n', t).strip()

# روایت‌های نگارشی: "ماده ۱ -" ، "== ماده ۱ ==" ، "مادهٔ ۱" ، "ماده ۱ مکرر"
ART_RE = re.compile(
    r'(?:^|\n)\s*[=]{0,4}\s*ماده\s*[\u0654\u0670]?\s*[\u200c ]?\s*([0-9۰-۹]{1,4})\s*(مکرر|تکراری)?\s*[=]{0,4}\s*[-–—:.]?\s*',
    re.M)
ASL_RE = re.compile(r'(?:^|\n)\s*[=]{0,4}\s*اصل\s*[\u0654\u0670]?\s*[\u200c ]?\s*([0-9۰-۹]{1,4})\s*[=]{0,4}\s*[-–—:.]?\s*', re.M)

def split_articles(text, rx=ART_RE, min_len=18, max_len=3500):
    text = clean(text)
    marks = list(rx.finditer(text))
    out = []
    for i, m in enumerate(marks):
        num = m.group(1).translate(FA) + (' مکرر' if (m.lastindex or 0) >= 2 and m.group(2) else '')
        start, end = m.end(), (marks[i + 1].start() if i + 1 < len(marks) else len(text))
        body = re.sub(r'\s*\n\s*', ' ', clean(text[start:end]))
        body = re.sub(r'^[=\-\s]+', '', body).strip()
        if len(body) < min_len:
            continue
        out.append({'art': num, 'text': body[:max_len]})
    seen, res = set(), []
    for a in out:
        k = a['art'] + '|' + a['text'][:50]
        if k in seen: continue
        seen.add(k); res.append(a)
    return res

def art_key(a):
    n = re.sub(r'\D', '', a['art']) or '0'
    return (0 if a['art'].strip().isdigit() else 1, int(n))

JOBS = [
    # (نام در برنامه, سال, حوزه, [عناوین صفحات], الگو)
    ('قانون مدنی', '۱۳۰۷–۱۳۷۰', ['rights', 'family'], ['__subpages__:قانون مدنی ۱۳۷۶'], 'art'),
    ('قانون آیین دادرسی مدنی', '۱۳۷۹', ['rights'], ['__subpages__:قانون آیین دادرسی دادگاه‌های عمومی و انقلاب (در امور مدنی)'], 'art'),
    ('قانون تجارت', '۱۳۱۱', ['rights', 'contract'], ['قانون تجارت'], 'art'),
    ('قانون ثبت اسناد و املاک', '۱۳۱۰', ['rights'], ['قانون ثبت اسناد و املاک'], 'art'),
    ('قانون صدور چک', '۱۳۵۵ (اصلاحی ۱۳۹۷)', ['rights', 'criminal'], ['قانون صدور چک'], 'art'),
    ('قانون اجرای احکام مدنی', '۱۳۵۶', ['rights'], ['قانون اجرای احکام مدنی'], 'art'),
    ('قانون تأمین اجتماعی', '۱۳۵۴', ['rights'], ['قانون تامین اجتماعی'], 'art'),
    ('قانون بیمه بیکاری', '۱۳۶۹', ['rights'], ['قانون بیمه بیکاری'], 'art'),
    ('قانون اساسی', '۱۳۶۸', ['general'], ['قانون اساسی جمهوری اسلامی ایران (مصوب ۱۳۶۸)'], 'asl'),
]

def main():
    laws, report = [], []
    for name, year, domains, pages, kind in JOBS:
        collected = []
        for p in pages:
            titles = []
            if p.startswith('__subpages__:'):
                pre = p.split(':', 1)[1]
                subs = subpages(pre)
                subs = [s for s in subs if not re.search(r'(مقدمه|فهرست|استفساریه)', s)]
                titles += subs
                titles.append(pre)                      # خود صفحهٔ اصلی هم ممکن است متن داشته باشد
            else:
                titles.append(p)
            for t in titles:
                txt = extract(t)
                if not txt: time.sleep(2.0); continue
                rx = ASL_RE if kind == 'asl' else ART_RE
                got = split_articles(txt, rx)
                collected += got
                time.sleep(2.0)
        # dedupe: برای هر شماره ماده، کامل‌ترین متن
        best = {}
        for a in collected:
            k = a['art']
            if k not in best or len(a['text']) > len(best[k]['text']):
                best[k] = a
        ordered = sorted(best.values(), key=art_key)
        for a in ordered:
            a['law'] = name
        laws.append({'name': name, 'year': year, 'domains': domains, 'count': len(ordered),
                     'source': 'wikisource', 'articles': ordered})
        report.append((name, len(ordered)))
        print('.. fetched', name, len(ordered), flush=True)

    corpus = {'version': 1, 'generatedAt': time.strftime('%Y-%m-%d'),
              'attribution': 'متون رسمی قوانین از ویکینبشته فارسی (CC BY-SA 4.0) — wikisource.org',
              'laws': laws}
    with open('/home/user/.cache/laws_corpus.json', 'w', encoding='utf-8') as f:
        json.dump(corpus, f, ensure_ascii=False)
    total = sum(l['count'] for l in laws)
    size = len(json.dumps(corpus, ensure_ascii=False))
    print('=== DONE ===')
    for n, c in report: print(f'  {n:<36} {c:>5} ماده')
    print('TOTAL articles:', total, '| JSON chars:', size)

if __name__ == '__main__':
    main()
