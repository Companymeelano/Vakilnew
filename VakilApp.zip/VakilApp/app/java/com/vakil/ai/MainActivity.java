package com.vakil.ai;

import android.app.Activity;
import android.content.ContentValues;
import android.content.Intent;
import android.net.Uri;
import android.os.Environment;
import android.provider.MediaStore;
import android.speech.tts.TextToSpeech;
import android.os.Build;
import android.os.Bundle;
import android.view.View;
import android.view.WindowManager;
import android.webkit.JavascriptInterface;
import android.webkit.ValueCallback;
import android.webkit.WebChromeClient;
import android.webkit.WebResourceRequest;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.widget.Toast;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.OutputStreamWriter;
import java.nio.charset.StandardCharsets;
import java.util.Locale;
import java.util.Scanner;

public class MainActivity extends Activity {

    private WebView web;
    private ValueCallback<Uri[]> filePathCallback;
    private static final int FILE_REQ = 1001;
    private TextToSpeech tts;
    private boolean ttsReady = false;
    private float ttsRate = 0.9f;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        getWindow().setStatusBarColor(0xFF070B16);
        getWindow().setNavigationBarColor(0xFF070B16);
        getWindow().setSoftInputMode(WindowManager.LayoutParams.SOFT_INPUT_ADJUST_RESIZE);

        web = new WebView(this);
        WebSettings s = web.getSettings();
        s.setJavaScriptEnabled(true);
        s.setDomStorageEnabled(true);
        s.setDatabaseEnabled(true);
        s.setAllowFileAccess(true);
        s.setAllowContentAccess(true);
        s.setLoadsImagesAutomatically(true);
        s.setMediaPlaybackRequiresUserGesture(false);
        s.setTextZoom(100);
        if (Build.VERSION.SDK_INT >= 21) {
            s.setMixedContentMode(WebSettings.MIXED_CONTENT_ALWAYS_ALLOW);
        }
        web.setBackgroundColor(0xFF070B16);
        web.setOverScrollMode(View.OVER_SCROLL_NEVER);
        web.setLayerType(View.LAYER_TYPE_HARDWARE, null);
        web.setWebChromeClient(new ChromeClient());
        web.setWebViewClient(new ViewClient());
        web.addJavascriptInterface(new Bridge(), "VakilNative");

        setContentView(web);
        web.loadUrl("file:///android_asset/index.html");

        tts = new TextToSpeech(this, new TextToSpeech.OnInitListener() {
            @Override
            public void onInit(int status) {
                if (status == TextToSpeech.SUCCESS) {
                    try {
                        int r = tts.setLanguage(new Locale("fa", "IR"));
                        if (r == TextToSpeech.LANG_MISSING_DATA || r == TextToSpeech.LANG_NOT_SUPPORTED) {
                            tts.setLanguage(Locale.getDefault());
                        }
                        tts.setSpeechRate(ttsRate);
                        tts.setPitch(1.05f);
                        ttsReady = true;
                    } catch (Exception e) { ttsReady = false; }
                }
            }
        });
    }

    /* ---------------- Chrome client : file chooser (documents / images) ---------------- */
    private class ChromeClient extends WebChromeClient {
        @Override
        public boolean onShowFileChooser(WebView v, ValueCallback<Uri[]> cb, FileChooserParams params) {
            if (filePathCallback != null) {
                filePathCallback.onReceiveValue(null);
            }
            filePathCallback = cb;
            Intent intent = new Intent(Intent.ACTION_GET_CONTENT);
            intent.addCategory(Intent.CATEGORY_OPENABLE);
            intent.setType("*/*");
            intent.putExtra(Intent.EXTRA_ALLOW_MULTIPLE, true);
            try {
                startActivityForResult(Intent.createChooser(intent, "انتخاب سند پرونده"), FILE_REQ);
                return true;
            } catch (Exception e) {
                filePathCallback = null;
                toast("امکان باز کردن انتخابگر فایل وجود ندارد");
                return false;
            }
        }
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        if (requestCode == FILE_REQ) {
            if (filePathCallback == null) return;
            Uri[] results = null;
            if (resultCode == RESULT_OK && data != null) {
                if (data.getClipData() != null) {
                    int count = data.getClipData().getItemCount();
                    results = new Uri[count];
                    for (int i = 0; i < count; i++) {
                        results[i] = data.getClipData().getItemAt(i).getUri();
                    }
                } else if (data.getData() != null) {
                    results = new Uri[]{data.getData()};
                }
            }
            filePathCallback.onReceiveValue(results);
            filePathCallback = null;
            return;
        }
        super.onActivityResult(requestCode, resultCode, data);
    }

    /* ---------------- WebView client : keep local app in-app, open web links in browser ------------ */
    private class ViewClient extends WebViewClient {
        private boolean handle(Uri uri) {
            if (uri == null) return false;
            String sc = uri.getScheme();
            if ("file".equals(sc) || "data".equals(sc)) return false;
            try {
                Intent i = new Intent(Intent.ACTION_VIEW, uri);
                startActivity(i);
            } catch (Exception e) {
                toast("لینک قابل باز کردن نیست: " + uri);
            }
            return true;
        }

        @Override
        public boolean shouldOverrideUrlLoading(WebView v, WebResourceRequest r) {
            return handle(r.getUrl());
        }

        @SuppressWarnings("deprecation")
        @Override
        public boolean shouldOverrideUrlLoading(WebView v, String url) {
            return handle(Uri.parse(url));
        }
    }

    /* ---------------- JS bridge : persistent storage in app private files ---------------- */
    private class Bridge {
        @JavascriptInterface
        public String load() {
            try {
                File f = new File(getFilesDir(), "vakil_state.json");
                if (!f.exists()) return "";
                FileInputStream in = new FileInputStream(f);
                Scanner sc = new Scanner(in, "UTF-8").useDelimiter("\\A");
                String out = sc.hasNext() ? sc.next() : "";
                sc.close();
                in.close();
                return out;
            } catch (Exception e) {
                return "";
            }
        }

        @JavascriptInterface
        public boolean save(String json) {
            try {
                File f = new File(getFilesDir(), "vakil_state.json");
                File tmp = new File(getFilesDir(), "vakil_state.tmp");
                FileOutputStream fos = new FileOutputStream(tmp);
                OutputStreamWriter w = new OutputStreamWriter(fos, StandardCharsets.UTF_8);
                w.write(json);
                w.flush();
                w.close();
                fos.close();
                if (f.exists()) f.delete();
                return tmp.renameTo(f);
            } catch (Exception e) {
                return false;
            }
        }

        @JavascriptInterface
        public boolean nativeStore() {
            return true;
        }

        @JavascriptInterface
        public void toastMsg(String msg) {
            toast(msg);
        }

        /* ---------- text to speech (صدای خانم وکیل) ---------- */
        @JavascriptInterface
        public boolean ttsAvailable() {
            return tts != null && ttsReady;
        }

        @JavascriptInterface
        public void ttsSpeak(final String text) {
            if (tts == null || !ttsReady || text == null) return;
            runOnUiThread(new Runnable() {
                public void run() {
                    try {
                        tts.stop();
                        tts.setSpeechRate(ttsRate);
                        java.util.HashMap<String, String> p = new java.util.HashMap<String, String>();
                        p.put(TextToSpeech.Engine.KEY_PARAM_UTTERANCE_ID, "vakil");
                        tts.setOnUtteranceProgressListener(new android.speech.tts.UtteranceProgressListener() {
                            @Override public void onStart(String id) {}
                            @Override public void onDone(String id) {
                                if (web != null) web.post(new Runnable() { public void run() {
                                    web.evaluateJavascript("window.vakilTTSDone && window.vakilTTSDone()", null); } });
                            }
                            @Override public void onError(String id) {}
                        });
                        tts.speak(text, TextToSpeech.QUEUE_FLUSH, p);
                    } catch (Exception e) { }
                }
            });
        }

        @JavascriptInterface
        public void ttsStop() {
            try { if (tts != null) tts.stop(); } catch (Exception e) {}
        }

        @JavascriptInterface
        public void ttsRate(float rate) {
            try { ttsRate = Math.max(0.4f, Math.min(1.8f, rate)); if (tts != null) tts.setSpeechRate(ttsRate); } catch (Exception e) {}
        }

        /* ---------- save file to Downloads ---------- */
        @JavascriptInterface
        public String saveToDownloads(String name, String content) {
            try {
                String safe = (name == null || name.length() == 0) ? ("vakil-" + System.currentTimeMillis() + ".txt")
                        : name.replaceAll("[^\\p{L}\\p{N}._-]", "_");
                byte[] bytes = content.getBytes("UTF-8");
                if (Build.VERSION.SDK_INT >= 29) {
                    ContentValues cv = new ContentValues();
                    cv.put(MediaStore.Downloads.DISPLAY_NAME, safe);
                    cv.put(MediaStore.Downloads.MIME_TYPE, safe.endsWith(".json") ? "application/json" : "text/plain");
                    cv.put(MediaStore.Downloads.IS_PENDING, 1);
                    Uri uri = getContentResolver().insert(MediaStore.Downloads.EXTERNAL_CONTENT_URI, cv);
                    if (uri == null) return "ERR: cannot create file";
                    java.io.OutputStream os = getContentResolver().openOutputStream(uri);
                    os.write(bytes);
                    os.flush();
                    os.close();
                    ContentValues done = new ContentValues();
                    done.put(MediaStore.Downloads.IS_PENDING, 0);
                    getContentResolver().update(uri, done, null, null);
                    return "OK:" + safe;
                } else {
                    File dir = getExternalFilesDir(Environment.DIRECTORY_DOWNLOADS);
                    if (dir == null) dir = getFilesDir();
                    File f = new File(dir, safe);
                    FileOutputStream fos = new FileOutputStream(f);
                    fos.write(bytes);
                    fos.flush();
                    fos.close();
                    return "OK:" + f.getAbsolutePath();
                }
            } catch (Exception e) {
                return "ERR: " + e.getMessage();
            }
        }

        /* HTTP proxy so calls run natively (no CORS / origin restrictions) */
        @JavascriptInterface
        public String http(String method, String url, String headersJson, String body) {
            java.net.HttpURLConnection c = null;
            org.json.JSONObject out = new org.json.JSONObject();
            try {
                c = (java.net.HttpURLConnection) new java.net.URL(url).openConnection();
                c.setRequestMethod(method == null ? "POST" : method);
                c.setConnectTimeout(25000);
                c.setReadTimeout(180000);
                c.setInstanceFollowRedirects(true);
                if (headersJson != null && headersJson.length() > 2) {
                    org.json.JSONObject h = new org.json.JSONObject(headersJson);
                    java.util.Iterator<String> it = h.keys();
                    while (it.hasNext()) {
                        String k = it.next();
                        c.setRequestProperty(k, h.getString(k));
                    }
                }
                if (body != null && body.length() > 0) {
                    c.setDoOutput(true);
                    byte[] bytes = body.getBytes("UTF-8");
                    c.setFixedLengthStreamingMode(bytes.length);
                    java.io.OutputStream os = c.getOutputStream();
                    os.write(bytes);
                    os.flush();
                    os.close();
                }
                int code = c.getResponseCode();
                java.io.InputStream is = (code >= 400) ? c.getErrorStream() : c.getInputStream();
                StringBuilder sb = new StringBuilder();
                if (is != null) {
                    java.io.BufferedReader br = new java.io.BufferedReader(new java.io.InputStreamReader(is, "UTF-8"));
                    char[] buf = new char[8192];
                    int n;
                    while ((n = br.read(buf)) > 0) sb.append(buf, 0, n);
                    br.close();
                }
                out.put("status", code);
                out.put("body", sb.toString());
            } catch (Exception e) {
                try {
                    out.put("status", 0);
                    out.put("body", String.valueOf(e.getMessage() == null ? e : e.getMessage()));
                } catch (Exception ignored) {}
            } finally {
                if (c != null) c.disconnect();
            }
            return out.toString();
        }
    }

    private void toast(final String msg) {
        runOnUiThread(new Runnable() {
            public void run() {
                Toast.makeText(MainActivity.this, msg, Toast.LENGTH_SHORT).show();
            }
        });
    }

    @Override
    public void onBackPressed() {
        if (web == null) {
            super.onBackPressed();
            return;
        }
        web.evaluateJavascript("(window.vakilBack && window.vakilBack()) ? '1' : '0'",
                new ValueCallback<String>() {
                    @Override
                    public void onReceiveValue(String value) {
                        if (value == null || value.contains("0")) {
                            finish();
                        }
                    }
                });
    }

    @Override
    protected void onPause() {
        super.onPause();
        if (web != null) web.onPause();
        try { if (tts != null) tts.stop(); } catch (Exception e) {}
    }

    @Override
    protected void onDestroy() {
        try { if (tts != null) { tts.stop(); tts.shutdown(); } } catch (Exception e) {}
        super.onDestroy();
    }

    @Override
    protected void onResume() {
        super.onResume();
        if (web != null) web.onResume();
    }
}
