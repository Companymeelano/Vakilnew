/* ============ Vakil AI — Living Lawyer Character (SVG animator) ============
   کاراکتر کاملاً زنده: تنفس، پلک‌زدن، حرکت چشم، پلک‌زدن، حالت‌های چهره،
   لب‌خوانی هنگام صحبت، اشاره‌های دست (خودکار) و واکنش به لمس کاربر. */
(function () {
  'use strict';

  var D = null;                 // DOM refs
  var ready = false;
  var enabled = true;

  var brain = {
    mood: 'greet',
    moodUntil: 0,
    speaking: false,
    thinking: false,
    gaze: { x: 0, y: 0, tx: 0, ty: 0 },
    look: { x: 0, y: 0, tx: 0, ty: 0 },     // سر/tن
    blinkAt: Date.now() + 1800,
    blinkT: -1,
    nextSaccade: 0,
    mouthPhase: 0,
    gestureT: 0,
    gesture: null,
    nodT: 0,
    t0: performance.now(),
    lastTs: performance.now()
  };

  var q = function (id) { return document.getElementById(id); };

  function collect() {
    D = {
      svg: q('charSvg'), root: q('charRoot'), head: q('head'), headTilt: q('headTilt'),
      torso: q('torso'), armL: q('armL'), armR: q('armR'), handR: q('handR'), pen: q('penGold'),
      eyeL: q('eyeL'), eyeR: q('eyeR'),
      irises: Array.prototype.slice.call(document.querySelectorAll('#charSvg .iris')),
      pupils: Array.prototype.slice.call(document.querySelectorAll('#charSvg .pupil')),
      shines: Array.prototype.slice.call(document.querySelectorAll('#charSvg .shine')),
      shines2: Array.prototype.slice.call(document.querySelectorAll('#charSvg .shine2')),
      mouth: {
        line: q('mLine'), open: q('mOpen'), smile: q('mSmile'), o: q('mO')
      },
      brows: {
        neutral: document.querySelector('.bNeutral'),
        raise: document.querySelector('.bRaise'),
        frown: document.querySelector('.bFrown')
      },
      bubble: q('charBubble'), text: q('charText'), typing: q('charTyping'),
      aura: q('auraGlow'), glint: q('lensGlint'), glasses: q('glasses')
    };
    /* آینه‌کردن: عناصر داخل گروه‌های [data-flip] محور x معکوس دارند */
    window.__vakilFlip = function (el) { return !!(el && el.closest && el.closest('[data-flip]')); };
    if (D.glint) { D.glint.style.transformBox = 'fill-box'; D.glint.style.transformOrigin = 'center'; }
    [D.eyeL, D.eyeR].forEach(function (e) {
      if (e) { e.style.transformBox = 'fill-box'; e.style.transformOrigin = 'center'; e.style.transition = 'transform .09s ease'; }
    });
    Object.keys(D.brows).forEach(function (k) {
      var el = D.brows[k];
      if (el) el.style.transition = 'opacity .3s ease';
    });
    Object.keys(D.mouth).forEach(function (k) {
      var el = D.mouth[k];
      if (el) el.style.transition = 'opacity .13s ease';
    });
    if (D.root) D.root.style.transformBox = 'fill-box';
    if (D.head) { D.head.style.transformBox = 'fill-box'; D.head.style.transformOrigin = '50% 78%'; }
  }

  /* ---------------- expression ---------------- */
  function show(el, on) { if (el) el.style.opacity = on ? '1' : '0'; }

  function applyMood() {
    var m = brain.mood;
    var b = { n: true, r: false, f: false };
    var mo = { line: true, open: false, smile: false, o: false };
    var eyeScale = 1, eyeDrop = 0;

    switch (m) {
      case 'happy':    b = { n: false, r: true, f: false };  mo = { line: false, open: false, smile: true, o: false }; eyeScale = .62; break;
      case 'smile':    b = { n: false, r: true, f: false };  mo = { line: false, open: false, smile: true, o: false }; break;
      case 'surprise': b = { n: false, r: true, f: false };  mo = { line: false, open: false, smile: false, o: true }; eyeScale = 1.14; break;
      case 'think':    b = { n: false, r: false, f: true };  mo = { line: true, open: false, smile: false, o: false }; eyeDrop = 1; break;
      case 'serious':  b = { n: false, r: false, f: true };  mo = { line: true, open: false, smile: false, o: false }; break;
      case 'concerned':b = { n: false, r: false, f: true };  mo = { line: true, open: false, smile: false, o: false }; eyeDrop = 2; break;
      case 'listen':   b = { n: true, r: true, f: false };   mo = { line: true, open: false, smile: false, o: false }; eyeScale = .92; break;
      default: break;
    }
    if (brain.speaking) { mo = { line: false, open: true, smile: false, o: false }; }

    show(D.brows.neutral, b.n); show(D.brows.raise, b.r); show(D.brows.frown, b.f);
    show(D.mouth.line, mo.line); show(D.mouth.open, mo.open); show(D.mouth.smile, mo.smile); show(D.mouth.o, mo.o);

    if (!brain.speaking) {
      [D.eyeL, D.eyeR].forEach(function (e) { if (e) e.style.transform = eyeScale === 1 ? '' : 'scaleY(' + eyeScale + ')'; });
    }
    brain.eyeDrop = eyeDrop;
  }

  function setMood(m, holdMs) {
    if (!m) return;
    if (brain.mood === 'talk' && m === 'think') { /* allow override */ }
    brain.mood = m;
    brain.moodUntil = holdMs ? Date.now() + holdMs : 0;
    applyMood();
  }

  /* ---------------- idle signal loop ---------------- */
  function frame(ts) {
    if (!ready) return;
    var dt = Math.min(50, ts - brain.lastTs); brain.lastTs = ts;
    var t = (ts - brain.t0) / 1000;

    /* expire temporary moods */
    if (brain.moodUntil && Date.now() > brain.moodUntil && !brain.speaking) {
      brain.moodUntil = 0;
      setMood(brain.thinking ? 'think' : (AI.isConfigured && AI.isConfigured() ? 'smile' : 'neutral'));
    }

    /* breathing + subtle body sway */
    if (D.torso) {
      var br = 1 + Math.sin(t * 1.7) * 0.012;
      D.torso.style.transformBox = 'fill-box';
      D.torso.style.transformOrigin = '50% 100%';
      D.torso.style.transform = 'scaleY(' + br.toFixed(4) + ')';
    }
    if (D.root) {
      var ry = Math.sin(t * 0.65) * 0.8;
      var ty = Math.sin(t * 1.25) * 1.6;
      D.root.style.transform = 'rotate(' + ry.toFixed(2) + 'deg) translateY(' + ty.toFixed(2) + 'px)';
    }

    /* gaze smoothing */
    var g = brain.gaze;
    g.x += (g.tx - g.x) * 0.12; g.y += (g.ty - g.y) * 0.12;
    var drop = brain.eyeDrop || 0;
    var flip = window.__vakilFlip;
    D.irises.forEach(function (e) { var m = flip(e) ? -1 : 1; e.style.transform = 'translate(' + (m * g.x).toFixed(2) + 'px,' + (g.y + drop).toFixed(2) + 'px)'; });
    D.pupils.forEach(function (e) { var m = flip(e) ? -1 : 1; e.style.transform = 'translate(' + (m * g.x * 0.8).toFixed(2) + 'px,' + ((g.y + drop) * 0.8).toFixed(2) + 'px)'; });
    D.shines.forEach(function (e) { var m = flip(e) ? -1 : 1; e.style.transform = 'translate(' + (m * g.x * 1.15).toFixed(2) + 'px,' + ((g.y + drop) * 1.15).toFixed(2) + 'px)'; });
    D.shines2.forEach(function (e) { var m = flip(e) ? -1 : 1; e.style.transform = 'translate(' + (m * g.x * 0.7).toFixed(2) + 'px,' + ((g.y + drop) * 0.7).toFixed(2) + 'px)'; });

    /* درخشش شیشهٔ عینک: هر چند ثانیه یک بار از روی عدسی می‌گذرد */
    if (D.glint) {
      var cyc = (ts % 7200);
      if (cyc < 900) {
        var k = Math.sin(cyc / 900 * Math.PI);
        D.glint.style.opacity = (0.08 + k * 0.34).toFixed(3);
        D.glint.style.transform = 'translate(' + ((900 - cyc) / 900 * 7).toFixed(2) + 'px,' + ((900 - cyc) / 900 * 5).toFixed(2) + 'px)';
      } else {
        D.glint.style.opacity = '0.06';
        D.glint.style.transform = 'none';
      }
    }

    /* random saccades (حرکات طبیعی چشم) */
    if (ts > brain.nextSaccade && !brain.speaking) {
      brain.nextSaccade = ts + 1400 + Math.random() * 3200;
      g.tx = (Math.random() * 2 - 1) * 3.4;
      g.ty = (Math.random() * 2 - 1) * 2.2;
    }
    if (brain.speaking) {
      /* نگاه به سمت گفتگو */
      g.tx = 1.6; g.ty = 0.6;
    }

    /* head micro-motion + nod + look */
    if (D.head) {
      var hx = Math.sin(t * 0.9) * 1.1;
      var hy = Math.sin(t * 0.55 + 1) * 0.6;
      if (brain.look.tx || brain.look.ty) {
        brain.look.x += (brain.look.tx - brain.look.x) * 0.06;
        brain.look.y += (brain.look.ty - brain.look.y) * 0.06;
        hx += brain.look.x; hy += brain.look.y;
      }
      var nod = 0;
      if (brain.nodT > 0) { nod = Math.sin((brain.nodT) * 0.35) * 4; brain.nodT -= dt / 1000; if (brain.nodT < 0) brain.nodT = 0; }
      D.head.style.transform = 'rotate(' + hx.toFixed(2) + 'deg) translate(' + (hy * 0.4).toFixed(2) + 'px,' + (hy + nod).toFixed(2) + 'px)';
    }

    /* blinking */
    if (brain.blinkT >= 0) {
      brain.blinkT += dt;
      var p = brain.blinkT / 150;
      var sc0 = p < 0.5 ? 1 - p * 2 : (p - 0.5) * 2;
      var sc = Math.max(0.06, sc0);
      var winkEye = brain.wink === 'L' ? D.eyeL : (brain.wink === 'R' ? D.eyeR : null);
      var keep = brain.wink ? (brain.wink === 'L' ? D.eyeR : D.eyeL) : null;
      if (winkEye) winkEye.style.transform = 'scaleY(' + sc.toFixed(3) + ')';
      if (keep) keep.style.transform = '';
      [D.eyeL, D.eyeR].forEach(function (e) {
        if (!e || e === winkEye || e === keep) return;
        e.style.transform = 'scaleY(' + sc.toFixed(3) + ')';
      });
      if (brain.blinkT > 150) {
        brain.blinkT = -1; brain.wink = null;
        [D.eyeL, D.eyeR].forEach(function (e) { if (e) e.style.transform = ''; });
        applyMood();
      }
    } else if (ts > brain.blinkAt) {
      brain.blinkAt = ts + 1900 + Math.random() * 4200;
      brain.blinkT = 0;
      /* چشمک (پلک تک‌چشمی) در حالت‌های شاد */
      if ((brain.mood === 'happy' || brain.mood === 'smile') && Math.random() < 0.14) {
        brain.wink = Math.random() < 0.5 ? 'L' : 'R';
      }
      if (Math.random() < 0.16) setTimeout(function () { if (brain.blinkT < 0) brain.blinkT = 0; }, 260);
    }

    /* speaking lip-sync */
    if (brain.speaking) {
      if (ts - brain.mouthPhase > 92 + Math.random() * 70) {
        brain.mouthPhase = ts;
        var r = Math.random();
        if (r < 0.5) show(D.mouth.open, true), show(D.mouth.line, false);
        else if (r < 0.8) show(D.mouth.open, false), show(D.mouth.line, true);
        else show(D.mouth.open, true), show(D.mouth.line, true);
        if (D.mouth.open) {
          var el = D.mouth.open.querySelector('ellipse');
          if (el) el.setAttribute('ry', (4.4 + Math.random() * 4.6).toFixed(2));
        }
      }
    }

    /* pen / hand animation while thinking */
    if (brain.thinking && D.pen) {
      var a = Math.sin(t * 7.5) * 7;
      D.pen.style.transformBox = 'fill-box';
      D.pen.style.transform = 'rotate(' + a.toFixed(2) + 'deg)';
      if (D.handR) {
        D.handR.style.transformBox = 'fill-box';
        D.handR.style.transform = 'translate(' + (Math.sin(t * 7.5) * 0.7).toFixed(2) + 'px,' + (Math.cos(t * 7.5) * 0.6).toFixed(2) + 'px)';
      }
    } else if (D.pen) {
      D.pen.style.transform = 'rotate(' + (Math.sin(t * 0.8) * 1.5).toFixed(2) + 'deg)';
    }

    /* gesture one-shot (welcome / point) */
    if (brain.gestureT > 0) {
      brain.gestureT -= dt / 1000;
      var k = Math.sin((1 - brain.gestureT) * Math.PI);
      if (D.armR) {
        D.armR.style.transformBox = 'fill-box';
        D.armR.style.transform = 'rotate(' + (-9 * k).toFixed(2) + 'deg) translateY(' + (-6 * k).toFixed(2) + 'px)';
      }
      if (brain.gestureT <= 0 && D.armR) { D.armR.style.transform = ''; }
    }

    /* aura pulse reacts to speaking */
    if (D.aura) {
      var gi = brain.speaking ? 0.62 + Math.sin(t * 5) * 0.05 : 0.5 + Math.sin(t * 1.1) * 0.05;
      D.aura.style.opacity = gi.toFixed(3);
    }

    brain.raf = requestAnimationFrame(frame);
  }

  /* ---------------- speech ---------------- */
  var speechTimer = null, typeTimer = null;

  function stopSpeech() {
    brain.speaking = false;
    try { window.LawsUI && LawsUI.stopSpeaking && LawsUI.stopSpeaking(); } catch (e) {}
    clearTimeout(speechTimer); clearInterval(typeTimer);
    if (D.typing) D.typing.classList.remove('on');
    applyMood();
  }

  function say(text, opt) {
    opt = opt || {};
    if (!D || !D.text) return;
    if (!enabled && !opt.force) return;
    stopSpeech();
    D.text.textContent = '';
    if (D.bubble) { D.bubble.style.animation = 'none'; void D.bubble.offsetWidth; D.bubble.style.animation = ''; }

    var mood = opt.mood || moodOf(text);
    setMood(mood);
    brain.speaking = true;
    applyMood();
    gesture(1.1);

    var i = 0, txt = String(text);
    var speed = opt.speed || 26;
    /* اگر گفتار فعال باشد، سرعت تایپ با صدای واقعی هم‌زمان می‌شود */
    var ttsMs = 0;
    try {
      if (window.LawsUI && LawsUI.speakText) ttsMs = LawsUI.speakText(txt);
    } catch (e) { ttsMs = 0; }
    if (ttsMs) speed = Math.max(18, Math.min(120, ttsMs / Math.max(1, txt.length)));
    typeTimer = setInterval(function () {
      i += 1;
      D.text.textContent = txt.slice(0, i);
      if (i % 3 === 0) {
        var full = D.bubble ? D.bubble.scrollHeight : 0;
        if (D.text.scrollHeight > 96) D.text.style.maxHeight = '96px';
      }
      if (i >= txt.length) {
        clearInterval(typeTimer);
        var hold = ttsMs ? Math.max(1200, ttsMs - txt.length * speed) : Math.min(4200, 900 + txt.length * 26);
        speechTimer = setTimeout(function () {
          brain.speaking = false;
          applyMood();
          setMood(brain.thinking ? 'think' : 'smile', 4200);
        }, hold);
      }
    }, speed);
  }

  function moodOf(text) {
    var t = String(text);
    if (/تبریک|مبارک|عالی|خبر خوب|موفق/.test(t)) return 'happy';
    if (/هشدار|خطر|فوری|مهلت|توجه|مراقب|ریسک/.test(t)) return 'concerned';
    if (/\?|؟|پرسش|بگویید|بفرمایید/.test(t)) return 'smile';
    if (/تحلیل|بررسی|مطالعه|سند|پرونده/.test(t)) return 'think';
    return 'smile';
  }

  function think(on, label) {
    on = !!on;
    if (brain.thinking === on) return;
    brain.thinking = on;
    if (on) {
      setMood('think');
      if (D.typing) D.typing.classList.add('on');
      if (label && D.text && !brain.speaking) D.text.textContent = label;
    } else {
      if (D.typing) D.typing.classList.remove('on');
      if (!brain.speaking) setMood('smile', 2600);
    }
  }

  function gesture(sec) {
    brain.gestureT = sec || 1;
  }
  function nod() { brain.nodT = 0.7; }
  function lookAt(dx, dy, hold) {
    brain.look.tx = Math.max(-2.4, Math.min(2.4, dx));
    brain.look.ty = Math.max(-2.2, Math.min(3.2, dy));
    if (hold) setTimeout(function () { brain.look.tx = 0; brain.look.ty = 0; }, hold);
  }
  function lookDown() { lookAt(0, 2.4, 1600); }
  function lookUpThink() { lookAt(-1.6, -1.4, 1800); }

  /* ---------------- interaction ---------------- */
  function bindTouch() {
    if (!D.svg) return;
    D.svg.addEventListener('pointerdown', function (ev) {
      try {
        var pt = D.svg.createSVGPoint();
        pt.x = ev.clientX; pt.y = ev.clientY;
        var loc = pt.matrixTransform(D.svg.getScreenCTM().inverse());
        var dx = (loc.x - 180) / 60, dy = (loc.y - 190) / 70;
        brain.gaze.tx = Math.max(-4, Math.min(4, dx));
        brain.gaze.ty = Math.max(-3, Math.min(3, dy));
        brain.nextSaccade = performance.now() + 2200;
        brain.blinkT = 0;
        var msgs = [
          'بله؟ در خدمتم — موضوع را بفرمایید تا بررسی کنم.',
          'هر مدرکی دارید پیوست کنید؛ کنار هم می‌گذارم و تحلیل می‌کنم.',
          'نگران نباشید، قدم‌به‌قدم با هم پیش می‌رویم.',
          'اگر شماره پرونده دارید، در بخش «پرونده‌ها» ثبتش کنیم تا هر بار از اول تعریف نکنید.',
          'برای دقت بیشتر، تاریخ‌ها و مهلت‌های مهم را هم بگویید.'
        ];
        if (!brain.thinking) say(msgs[Math.floor(Math.random() * msgs.length)], { speed: 30 });
        Store.haptic(15);
      } catch (e) {}
    });
  }

  function init() {
    try { collect(); } catch (e) { console.warn('character init failed', e); return; }
    ready = true;
    brain.lastTs = performance.now();
    applyMood();
    bindTouch();
    brain.raf = requestAnimationFrame(frame);
    var s = Store.State.settings;
    enabled = s.char !== false;
  }

  function setEnabled(v) { enabled = !!v; if (!v) stopSpeech(); }

  window.Character = {
    init: init, say: say, think: think, setMood: setMood, gesture: gesture, nod: nod,
    lookAt: lookAt, lookDown: lookDown, lookUpThink: lookUpThink, setEnabled: setEnabled,
    isThinking: function () { return brain.thinking; }
  };
})();
