/* ============ Vakil AI — Multi-provider AI engine, agents & connection tests ============ */
(function () {
  'use strict';

  var NATIVE = (typeof window.VakilNative !== 'undefined') ? window.VakilNative : null;

  /* ---------------- providers ---------------- */
  var PROVIDERS = {
    openai: {
      name: 'OpenAI', icon: 'i-chip', color: 'linear-gradient(150deg,#10a37f,#0a6b53)',
      base: 'https://api.openai.com/v1/chat/completions',
      models: ['gpt-4o', 'gpt-4o-mini', 'gpt-4.1', 'gpt-4.1-mini', 'o4-mini'],
      vision: true, kind: 'openai', keyHint: 'sk-...'
    },
    anthropic: {
      name: 'Anthropic Claude', icon: 'i-brain', color: 'linear-gradient(150deg,#d9a05b,#8a5a20)',
      base: 'https://api.anthropic.com/v1/messages',
      models: ['claude-sonnet-4-5', 'claude-haiku-4-5', 'claude-3-7-sonnet-latest', 'claude-3-5-haiku-latest'],
      vision: true, kind: 'anthropic', keyHint: 'sk-ant-...'
    },
    gemini: {
      name: 'Google Gemini', icon: 'i-globe', color: 'linear-gradient(150deg,#5b8def,#2b4fae)',
      base: 'https://generativelanguage.googleapis.com/v1beta/models/{model}:generateContent',
      models: ['gemini-2.5-flash', 'gemini-2.5-pro', 'gemini-2.0-flash'],
      vision: true, kind: 'gemini', keyHint: 'AIza...'
    },
    groq: {
      name: 'Groq (سریع)', icon: 'i-bolt', color: 'linear-gradient(150deg,#f0a35e,#a3521c)',
      base: 'https://api.groq.com/openai/v1/chat/completions',
      models: ['llama-3.3-70b-versatile', 'llama-3.1-8b-instant', 'qwen/qwen3-32b'],
      vision: false, kind: 'openai', keyHint: 'gsk_...'
    },
    openrouter: {
      name: 'OpenRouter (چندمدلی)', icon: 'i-layer', color: 'linear-gradient(150deg,#8f7bff,#432ea8)',
      base: 'https://openrouter.ai/api/v1/chat/completions',
      models: ['deepseek/deepseek-chat-v3.1', 'openai/gpt-4o-mini', 'anthropic/claude-3.5-sonnet',
               'google/gemini-2.0-flash-001', 'meta-llama/llama-3.3-70b-instruct'],
      vision: true, kind: 'openai', keyHint: 'sk-or-...'
    },
    deepseek: {
      name: 'DeepSeek', icon: 'i-target', color: 'linear-gradient(150deg,#4d9df0,#1c4f8f)',
      base: 'https://api.deepseek.com/v1/chat/completions',
      models: ['deepseek-chat', 'deepseek-reasoner'],
      vision: false, kind: 'openai', keyHint: 'sk-...'
    },
    custom: {
      name: 'سرویس سفارشی (OpenAI-compatible)', icon: 'i-gear', color: 'linear-gradient(150deg,#8a93ad,#3c465e)',
      base: '', models: [], vision: true, kind: 'openai', keyHint: 'کلید اختیاری', custom: true
    }
  };

  /* ---------------- low level HTTP ---------------- */
  function nativeHttp(method, url, headers, body) {
    return new Promise(function (resolve, reject) {
      try {
        var res = NATIVE.http(method, url, JSON.stringify(headers || {}), body == null ? '' : body);
        resolve(JSON.parse(res));
      } catch (e) { reject(e); }
    });
  }

  function fetchHttp(method, url, headers, body, timeoutMs) {
    return new Promise(function (resolve, reject) {
      var ctrl = ('AbortController' in window) ? new AbortController() : null;
      var to = setTimeout(function () { if (ctrl) ctrl.abort(); }, timeoutMs || 120000);
      var opts = { method: method, headers: headers || {} };
      if (ctrl) opts.signal = ctrl.signal;
      if (body != null) opts.body = body;
      fetch(url, opts).then(function (r) {
        return r.text().then(function (t) { clearTimeout(to); resolve({ status: r.status, body: t }); });
      }).catch(function (e) { clearTimeout(to); reject(e); });
    });
  }

  function http(method, url, headers, body, timeoutMs) {
    if (NATIVE && NATIVE.http) return nativeHttp(method, url, headers, body);
    return fetchHttp(method, url, headers, body, timeoutMs);
  }

  function errFa(status, body, providerName) {
    var b = String(body || '');
    var extra = '';
    try { var j = JSON.parse(b); extra = (j.error && (j.error.message || j.error)) || j.message || ''; } catch (e) { extra = b.slice(0, 220); }
    if (status === 0) return 'خطای شبکه: اتصال اینترنت یا آدرس سرویس را بررسی کنید. (' + extra + ')';
    if (status === 401 || status === 403) return 'کلید API نامعتبر یا بدون دسترسی است (' + providerName + '). ' + extra;
    if (status === 404) return 'مدل انتخاب‌شده در این سرویس یافت نشد. مدل دیگری انتخاب کنید. ' + extra;
    if (status === 429) return 'محدودیت نرخ درخواست یا اعتبار کافی نیست (' + providerName + '). کمی بعد تلاش کنید. ' + extra;
    if (status >= 500) return 'خطای موقت سرور ' + providerName + '. دوباره تلاش کنید. ' + extra;
    return 'خطا (' + status + '): ' + extra;
  }

  function splitModel(full) {
    var i = String(full || '').indexOf(':');
    if (i < 0) return { provider: 'openai', model: '' };
    return { provider: full.slice(0, i), model: full.slice(i + 1) };
  }
  function joinModel(p, m) { return p + ':' + m; }

  function keyOf(providerId) {
    var p = window.Store.State.settings.providers[providerId];
    return p && p.key ? p.key.trim() : '';
  }

  function availableModels() {
    var out = [];
    Object.keys(PROVIDERS).forEach(function (pid) {
      var P = PROVIDERS[pid];
      var list = (pid === 'custom') ? (P.models || []) : P.models;
      if (pid === 'custom') {
        var cm = window.Store.State.settings.providers.custom.model;
        if (cm) list = [cm].concat(list || []);
      }
      (list || []).forEach(function (m) {
        out.push({ pid: pid, model: m, id: joinModel(pid, m), label: P.name + ' — ' + m, hasKey: !!keyOf(pid) });
      });
    });
    return out;
  }

  function defaultModelId() {
    var s = window.Store.State.settings;
    if (s.defaultModel && keyOf(splitModel(s.defaultModel).provider)) return s.defaultModel;
    var ms = availableModels();
    for (var i = 0; i < ms.length; i++) if (ms[i].hasKey) return ms[i].id;
    return ms.length ? ms[0].id : '';
  }

  /* ---------------- message building ---------------- */
  function buildOpenAIMessages(system, messages, images) {
    var out = [{ role: 'system', content: system }];
    (messages || []).forEach(function (m) {
      if (m.images && m.images.length) {
        var parts = [{ type: 'text', text: m.content || '' }];
        m.images.forEach(function (du) { parts.push({ type: 'image_url', image_url: { url: du } }); });
        out.push({ role: m.role, content: parts });
      } else {
        out.push({ role: m.role, content: m.content || '' });
      }
    });
    return out;
  }

  function buildAnthropicMessages(system, messages) {
    var out = [];
    (messages || []).forEach(function (m) {
      var blocks = [];
      if (m.images && m.images.length) {
        m.images.forEach(function (du) {
          var mm = /^data:(image\/[a-z+]+);base64,(.*)$/i.exec(du || '');
          if (mm) blocks.push({ type: 'image', source: { type: 'base64', media_type: mm[1], data: mm[2] } });
        });
      }
      blocks.push({ type: 'text', text: m.content || '' });
      out.push({ role: m.role, content: blocks });
    });
    return { system: system, messages: out };
  }

  function buildGeminiBody(system, messages) {
    var contents = [];
    (messages || []).forEach(function (m) {
      var parts = [];
      if (m.images && m.images.length) {
        m.images.forEach(function (du) {
          var mm = /^data:(image\/[a-z+]+);base64,(.*)$/i.exec(du || '');
          if (mm) parts.push({ inline_data: { mime_type: mm[1], data: mm[2] } });
        });
      }
      parts.push({ text: m.content || '' });
      contents.push({ role: m.role === 'assistant' ? 'model' : 'user', parts: parts });
    });
    return {
      system_instruction: { parts: [{ text: system }] },
      contents: contents,
      generationConfig: { temperature: Math.max(0, Math.min(1.6, (window.Store.State.settings.temp || 3) / 10 + 0.1)), maxOutputTokens: 4096 }
    };
  }

  /* ---------------- single call ---------------- */
  function callModel(opts) {
    var full = opts.modelId || defaultModelId();
    var sp = splitModel(full);
    var pid = opts.providerId || sp.provider;
    var model = opts.model || sp.model;
    var P = PROVIDERS[pid];
    if (!P) return Promise.reject(new Error('سرویس نامعتبر است.'));
    var key = keyOf(pid);
    if (!key && pid !== 'custom') {
      return Promise.reject(new Error('برای سرویس «' + P.name + '» کلید API ثبت نشده است. در تنظیمات، کلید را وارد و تست اتصال بگیرید. برای سرویس‌های بدون کلید (مثل سرویس محلی) از «سرویس سفارشی» استفاده کنید.'));
    }
    if (!model) return Promise.reject(new Error('مدل انتخاب نشده است. در تنظیمات، سرویس و مدل پیش‌فرض را تعیین کنید.'));

    var temp = Math.max(0, Math.min(1.5, (window.Store.State.settings.temp || 3) / 10));
    var maxTok = opts.maxTokens || 3400;
    var msgs = (opts.messages || []).filter(function (m) { return (m.content && m.content.trim()) || (m.images && m.images.length); });
    if (!msgs.length) msgs = [{ role: 'user', content: 'تحلیل کن.' }];

    var headers = { 'Content-Type': 'application/json' };
    var url = P.base, body = '';

    if (P.kind === 'anthropic') {
      headers['x-api-key'] = key;
      headers['anthropic-version'] = '2023-06-01';
      headers['anthropic-dangerous-direct-browser-access'] = 'true';
      var ab = buildAnthropicMessages(opts.system, msgs);
      body = JSON.stringify({ model: model, system: ab.system, messages: ab.messages, max_tokens: maxTok, temperature: temp });
    } else if (P.kind === 'gemini') {
      url = P.base.replace('{model}', encodeURIComponent(model)) + '?key=' + encodeURIComponent(key);
      body = JSON.stringify(buildGeminiBody(opts.system, msgs));
    } else {
      headers['Authorization'] = 'Bearer ' + key;
      if (pid === 'openrouter') { headers['HTTP-Referer'] = 'https://vakil.ai'; headers['X-Title'] = 'Vakil AI'; }
      var oa = buildOpenAIMessages(opts.system, msgs);
      body = JSON.stringify({ model: model, messages: oa, temperature: temp, max_tokens: maxTok });
      if (pid === 'custom') {
        var cbase = (window.Store.State.settings.providers.custom.base || '').trim();
        if (!cbase) return Promise.reject(new Error('آدرس سرویس سفارشی (Base URL) ثبت نشده است.'));
        url = cbase;
      }
    }

    var t0 = Date.now();
    return http('POST', url, headers, body, 180000).then(function (res) {
      var ms = Date.now() - t0;
      if (res.status < 200 || res.status >= 300) {
        var e = new Error(errFa(res.status, res.body, P.name)); e.status = res.status; throw e;
      }
      var j;
      try { j = JSON.parse(res.body); } catch (e2) { throw new Error('پاسخ سرویس قابل خواندن نبود.'); }
      var text = '';
      if (P.kind === 'anthropic') {
        (j.content || []).forEach(function (b) { if (b.type === 'text') text += b.text; });
      } else if (P.kind === 'gemini') {
        var cand = (j.candidates || [])[0];
        if (cand && cand.content && cand.content.parts) cand.content.parts.forEach(function (p) { if (p.text) text += p.text; });
        if (!text && j.promptFeedback) text = 'پاسخ توسط سرویس برگشت داده نشد (دلیل: ' + JSON.stringify(j.promptFeedback).slice(0, 200) + ')';
      } else {
        var ch = (j.choices || [])[0];
        if (ch) {
          if (ch.message && ch.message.content != null) {
            if (typeof ch.message.content === 'string') text = ch.message.content;
            else if (Array.isArray(ch.message.content)) ch.message.content.forEach(function (p) { if (p.text) text += p.text; });
          } else if (ch.text) text = ch.text;
        }
        if (!text && j.error) throw new Error(errFa(res.status, res.body, P.name));
      }
      if (!text || !text.trim()) throw new Error('پاسخ خالی از سرویس دریافت شد.');
      return { text: text.trim(), ms: ms, provider: P.name, model: model };
    });
  }

  /* ---------------- test connection ---------------- */
  function testConnection(pid, modelOverride) {
    var P = PROVIDERS[pid];
    var st = window.Store.State.settings;
    var model = modelOverride || (pid === 'custom' ? (st.providers.custom.model || '') : (P.models[0] || ''));
    if (pid === 'custom' && !String(st.providers.custom.base || '').trim()) {
      return Promise.resolve({ ok: false, msg: 'آدرس Base URL را وارد کنید (مثال: https://api.example.com/v1/chat/completions).' });
    }
    if (!keyOf(pid) && pid !== 'custom') return Promise.resolve({ ok: false, msg: 'کلید API وارد نشده است.' });
    var t0 = Date.now();
    return callModel({
      providerId: pid, model: model, system: 'تو یک تست اتصال هستی. فقط و فقط بنویس: «اتصال برقرار است».',
      messages: [{ role: 'user', content: 'تست اتصال. فقط عبارت خواسته‌شده را بنویس.' }],
      maxTokens: 24
    }).then(function (r) {
      return { ok: true, ms: Date.now() - t0, msg: 'اتصال سالم است · ' + r.model + ' · ' + Math.round((Date.now() - t0) / 100) / 10 + ' ثانیه' };
    }).catch(function (e) {
      return { ok: false, msg: e.message || 'اتصال ناموفق بود.' };
    });
  }

  /* ---------------- classification & agent routing ---------------- */
  var KW = {
    family: ['طلاق', 'مهریه', 'مهر', 'نفقه', 'حضانت', 'ملاقات فرزند', 'زوجه', 'زوج', 'عقد', 'نکاح', 'عده', 'اجرت المثل', 'اجرت‌المثل', 'تمکین', 'شیربها', 'خانواده', 'فرزند', 'همسر', 'طلاق توافقی'],
    criminal: ['کلاهبرداری', 'سرقت', 'ضرب', 'جرح', 'توهین', 'فحاشی', 'تهدید', 'جعل', 'جرم', 'متهم', 'شکایت', 'کیفرخواست', 'بازداشت', 'قرار', 'دیه', 'قصاص', 'ارش', 'خشونت', 'مزاحمت', 'خیانت در امانت', 'چک بلامحل کیفری'],
    contract: ['قرارداد', 'شرط', 'فسخ', 'شروط', 'تعهد', 'پیمان', 'شرط جزایی', 'وجه التزام', 'محرمانگی', 'توافق‌نامه', 'تفاهم‌نامه'],
    rights: ['چک', 'سفته', 'ملک', 'تخلیه', 'سند', 'الحاقیه', 'اجاره', 'مستأجر', 'موجر', 'وجه', 'خسارت', 'مطالبه', 'الزام', 'خلع ید', 'تصرف', 'بیع', 'معامله', 'وام', 'بدهی', 'وراثت', 'ارث', 'سهم', 'شرکت', 'سفته']
  };
  function classify(text) {
    var t = String(text || '');
    var score = {};
    Object.keys(KW).forEach(function (k) {
      score[k] = 0;
      KW[k].forEach(function (w) { if (t.indexOf(w) >= 0) score[k] += 2; });
    });
    var best = 'rights', bv = 0;
    Object.keys(score).forEach(function (k) { if (score[k] > bv) { bv = score[k]; best = k; } });
    return bv === 0 ? 'general' : best;
  }

  function routeAgents(mode, text, hasDocs) {
    var domain = (mode && mode !== 'auto') ? mode : classify(text);
    if (domain === 'general') domain = classify(text) === 'general' ? 'rights' : classify(text);
    var ids = ['coordinator'];
    var map = { rights: 'civil', criminal: 'criminal', family: 'family', contract: 'contractor' };
    if (map[domain]) ids.push(map[domain]);
    if (hasDocs) ids.push('evidence');
    /* حداکثر ۳ کارشناس برای کنترل هزینه و زمان */
    return ids.slice(0, 3);
  }

  /* ---------------- orchestrations ---------------- */
  function analyze(opts) {
    /* opts: { mode, text, caseObj, files, onStage, images } */
    var st = window.Store.State.settings;
    var onStage = opts.onStage || function () {};
    var ids = st.multi ? routeAgents(opts.mode, opts.text, !!(opts.files && opts.files.length)) : ['coordinator'];
    var agents = window.Legal.AGENTS.filter(function (a) { return ids.indexOf(a.id) >= 0; });
    var results = [], i = 0;

    function next() {
      if (i >= agents.length) return Promise.resolve(results);
      var ag = agents[i++];
      onStage({ phase: 'agent', agent: ag, index: i, total: agents.length });
      var prompt = window.Legal.analysisPrompt(opts.mode, opts.text, opts.caseObj, opts.files);
      var system = ag.system + '\n\n' + prompt.system +
        '\n\nتو در نقش «' + ag.name + '» (' + ag.sub + ') پاسخ می‌دهی؛ لحن تخصصی و منحصر به همین حوزه باشد.';
      var msgs = [{ role: 'user', content: prompt.user, images: opts.images || null }];
      return callModel({ system: system, messages: msgs, maxTokens: 3000 }).then(function (r) {
        results.push({ agent: ag, text: r.text, ms: r.ms });
        return next();
      }).catch(function (e) {
        results.push({ agent: ag, error: e.message });
        if (results.length === agents.length) return results;
        return next();
      });
    }

    return next().then(function (res) {
      var ok = res.filter(function (r) { return r.text; });
      if (!ok.length) {
        var firstErr = (res[0] && res[0].error) || 'تحلیل انجام نشد.';
        throw new Error(firstErr);
      }
      if (!st.multi || ok.length < 2) return { combined: ok.map(function (r) { return r.text; }).join('\n\n---\n\n'), parts: ok };

      /* جمع‌بندی نهایی توسط سرپرست پرونده */
      onStage({ phase: 'synthesis' });
      var coord = window.Legal.AGENTS[0];
      var digest = ok.map(function (r) {
        return '### تحلیل کارشناس «' + r.agent.name + '»\n' + r.text.slice(0, 5200);
      }).join('\n\n');
      var sys = coord.system + '\n\n' + window.Legal.SHARED_RULES +
        '\n\nنقش کنونی: جمع‌بندی نظرات کارشناسان در یک تحلیل واحد، بدون تکرار، با اولویت‌بندی اقدامات و رفع تناقض‌ها.' +
        '\nقالب: ## ۱ خلاصهٔ نهایی · ## ۲ تحلیل حقوقی یکپارچه (با مواد قانونی) · ## ۳ ادله و کمبود مدارک · ## ۴ اقدامات فوری (۲۴–۷۲ ساعت) · ## ۵ برنامهٔ گام‌به‌گام · ## ۶ ریسک‌ها و مهلت‌ها · ## ۷ پرسش‌های تکمیلی';
      return callModel({
        system: sys,
        messages: [{ role: 'user', content: 'نظرات کارشناسان:\n\n' + digest + '\n\nاکنون تحلیل نهایی یکپارچه و راهکار اصولی ارائه بده.' }],
        maxTokens: 3600
      }).then(function (r) {
        return { combined: r.text, parts: ok, synthesisMs: r.ms };
      }).catch(function () {
        return { combined: ok.map(function (x) { return x.text; }).join('\n\n---\n\n'), parts: ok };
      });
    });
  }

  function chat(agentId, message, opts) {
    opts = opts || {};
    var hist = (opts.history || []).slice();
    var agent = window.Legal.AGENTS.filter(function (a) { return a.id === agentId; })[0] || window.Legal.AGENTS[0];
    var dom = (agent.domains && agent.domains.length === 1) ? agent.domains[0] : null;
    var lprompt = window.Legal.chatPrompt(agentId, hist, opts.caseObj, opts.files, null, message, dom);
    var msgs = lprompt.messages.slice();
    msgs.push({ role: 'user', content: message, images: opts.images || null });
    return callModel({ system: lprompt.system, messages: msgs, maxTokens: 1600 }).then(function (r) {
      return { text: r.text, agent: lprompt.agent, ms: r.ms };
    });
  }

  function draft(typeId, values, caseObj, files) {
    var d = window.Legal.draftPrompt(typeId, values, caseObj, files);
    return callModel({ system: d.system, messages: [{ role: 'user', content: d.user }], maxTokens: 3600 })
      .then(function (r) { return { text: r.text, typeName: d.typeName }; });
  }

  function quickEvidence(files, caseObj, question) {
    var p = window.Legal.evidencePrompt(files, caseObj, question);
    return callModel({ system: p.system, messages: [{ role: 'user', content: p.user }], maxTokens: 2600 })
      .then(function (r) { return r.text; });
  }

  function isConfigured() { return !!defaultModelId() && !!keyOf(splitModel(defaultModelId()).provider); }

  /* فهرست «استنادهای» آخرین پاسخ (برای نمایش در UI) */
  var lastCitations = [];
  function cites(query, domain, top) {
    try {
      lastCitations = window.Knowledge ? window.Knowledge.search(query, { domain: domain && domain !== 'auto' ? domain : null, top: top || 6 }) : [];
    } catch (e) { lastCitations = []; }
    return lastCitations;
  }
  function getCitations() { return lastCitations; }

  /* ---------------- offline guidance (بدون API) ---------------- */
  var OFFLINE = {
    family: [
      '## راهنمای گام‌به‌گام (نسخهٔ آفلاین — بدون هوش مصنوعی)',
      '**۱) تثبیت ادله:** سند نکاحیه، شناسنامه فرزندان، مدارک مالی (فیش حقوقی، حساب بانکی)، پیام‌ها و شهادت شهود را گردآوری و به پرونده پیوست کنید.',
      '**۲) مبانی قانونی:** ماده ۱۱۰۷ قانون مدنی (نفقه)؛ ماده ۱۰۸۲ (مالکیت زوجه بر مهر به مجرد عقد)؛ ماده ۱۱۰۶ (نفقهٔ زوجه در نکاح دائم بر عهدهٔ زوج)؛ ماده ۱۰۸۵ (حق امتناع از تمکین تا دریافت مهر)؛ ماده ۱۱۳۰ (طلاق به دلیل عسروحرج).',
      '**۳) مرجع و مدرک:** در دعاوی خانواده، «گواهی عدم امکان سازش» یا درخواست طلاق توافقی با دادخواست به دادگاه خانواده تقدیم می‌شود؛ قانون حمایت خانواده (۱۳۹۱) مرجع و تشریفات را تعیین می‌کند.',
      '**۴) مهریه و اعسار:** مطالبهٔ مهریه در دادگاه خانواده مطرح و در صورت ادعای اعسار، قانون نحوهٔ اجرای محکومیت‌های مالی و ماده ۶ قانون اصلاح مهریه (۱۳۷۶) اهمیت دارد.',
      '**۵) حضانت و ملاقات:** حضانت اولویتاً با والدین است و تعیین آن مبتنی بر مصلحت طفل انجام می‌شود؛ حق ملاقات را می‌توان حتی با حکم اجرا کرد.',
      '**۶) اقدام فوری:** فهرست اموال مشترک، تنظیم صورت دارای، و درخواست توقیف اموال در صورت خطر انتقال.'
    ].join('\n\n'),
    criminal: [
      '## راهنمای گام‌به‌گام (نسخهٔ آفلاین — بدون هوش مصنوعی)',
      '**۱) مستندسازی فوری:** فیلم، عکس، گزارش پزشکی قانونی، پیام‌های تهدید و مشخصات شهود را در پرونده ثبت کنید.',
      '**۲) مهلت‌ها:** شکایت کیفری معمولاً مقید به مهلت‌های خاص نیست اما جرایم قابل گذشت با گذشت شاکی موقوف می‌شوند؛ در جرم‌های قابل گذشت، احتیاط کنید که اعادهٔ شرف و حیثیت (مواد ۱۰۰ تا ۱۰۲ ق.م.ا) نیز مسیر کیفری دارد.',
      '**۳) مسیر رسمی:** شکواییه به دادسرا/دادگاه کیفری دو تقدیم و پس از ارجاع، پروندهٔ کیفری با شمارهٔ مستقل ثبت می‌شود؛ حضور با وکیل حق قانونی است (ماده ۴۸ ق.آ.د.ک).',
      '**۴) دفاعیات کلیدی:** بررسی ارکان سه‌گانهٔ جرم (قانونی، مادی، روانی)، دفاع‌های مشروع، اضطرار و اکراه، و کیفیات مخففهٔ موضوع مواد ۳۷ و ۳۸ ق.م.ا.',
      '**۵) جنبهٔ خصوصی و دیه:** خسارت و دیه در کنار بُعد عمومی مطالبه می‌شود؛ ارش و دیه بر پایهٔ گزارش پزشکی قانونی تعیین می‌گردد.',
      '**۶) اقدام فوری:** تنظیم و تقدیم شکواییه، درخواست قرار تأمین خواستهٔ کیفری و معرفی شهود.'
    ].join('\n\n'),
    contract: [
      '## چک‌لیست قرارداد (نسخهٔ آفلاین — بدون هوش مصنوعی)',
      '**۱) شرایط اساسی صحت معامله — ماده ۱۹۰ قانون مدنی:** قصد و رضا، اهلیت، موضوع معین و جهت مشروع.',
      '**۲) اصل آزادی قراردادی — ماده ۱۰ قانون مدنی:** جزئیات مورد توافق طرفین درصورت مخالفت با قانون، اثر دارد؛ پس بندها را دقیق و صریح بنویسید.',
      '**۳) الزام‌آور بودن — مواد ۲۱۹ و ۲۲۳:** بندهای دقیق مدت، مبلغ، نحوهٔ پرداخت، تسویه و تحویل.',
      '**۴) بندهای ضروری:** شرط جزایی/وجه التزام، فورس‌ماژور، فسخ و انفساخ، تعیین مرجع حل اختلاف (دادگاه یا داوری مطابق ماده ۴۵۴ ق.آ.د.م)، محرمانگی، تنظیم اسناد رسمی، فسخ قانونی مواد ۳۹۶ و ۴۴۰.',
      '**۵) ریسک‌سنجی:** تعدد وصف، شروط مجعوله، ضمانت‌های اجرایی و تمبر مالیاتی و ثبت الکترونیک اسناد رسمی.'
    ].join('\n\n'),
    rights: [
      '## راهنمای گام‌به‌گام (نسخهٔ آفلاین — بدون هوش مصنوعی)',
      '**۱) احراز ادعا:** سند عادی/رسمی، دلیل‌ها؛ مطابق مواد ۱۲۵۷ و ۱۲۵۸ قانون مدنی بار اثبات بر عهدهٔ مدعی و ادلهٔ اثبات محدود است.',
      '**۲) مرجع صالح:** ماده ۱۱ ق.آ.د.م (صلاحیت عمومی)، ماده ۱۳ (اعتبار امر مختومه)؛ در ملکی و اسناد، ماده ۲۲ قانون ثبت (ملکیت کسی که ملک به نام او ثبت شده) و قواعد مربوط به معارض.',
      '**۳) پیش‌نیازها:** ارسال اظهارنامه/اخطار، مطالبهٔ رسمی، تنظیم دادخواست با بهای خواسته و پرداخت هزینه‌ها.',
      '**۴) راهکارها:** صلح و سازش (سازش خانوادگی/شورای حل اختلاف)، آیین داوری، تأمین خواسته و توقیف اموال، استعلام کارشناسی و معاینهٔ محل.',
      '**۵) مهلت‌ها:** تجدیدنظرخواهی در دعاوی مدنی ۲۰ روز از تاریخ ابلاغ (ماده ۳۳۶ ق.آ.د.م)، اعتراض به رأی غیابی ۲۰ روز (ماده ۳۰۶ همان قانون).',
      '**۶) چک و سفته:** قانون صدور چک (با اصلاحات ۱۳۹۷) مسیرهای کیفری، اجرایی و حقوقی را مشخص کرده است.'
    ].join('\n\n'),
    general: ['## یادداشت آفلاین', 'برای دریافت تحلیل هوشمند، در «تنظیمات» کلید API یکی از سرویس‌ها را وارد و «تست اتصال» بگیرید.'].join('\n\n')
  };
  function offline(mode, text) {
    var d = (mode && mode !== 'auto') ? mode : classify(text);
    return OFFLINE[d] || OFFLINE.general;
  }

  /* map of agent id → user-facing model label */
  function modelLabel() {
    var id = defaultModelId();
    if (!id) return 'بدون API';
    var sp = splitModel(id);
    if (!keyOf(sp.provider)) return 'کلید API تنظیم نشده';
    var P = PROVIDERS[sp.provider];
    return (P ? P.name.split(' ')[0] : sp.provider) + ' · ' + sp.model;
  }

  window.AI = {
    PROVIDERS: PROVIDERS, availableModels: availableModels, defaultModelId: defaultModelId,
    callModel: callModel, testConnection: testConnection,
    analyze: analyze, chat: chat, draft: draft, quickEvidence: quickEvidence,
    classify: classify, routeAgents: routeAgents,
    offline: offline, isConfigured: isConfigured, modelLabel: modelLabel,
    cites: cites, getCitations: getCitations,
    splitModel: splitModel, joinModel: joinModel, keyOf: keyOf
  };
})();
