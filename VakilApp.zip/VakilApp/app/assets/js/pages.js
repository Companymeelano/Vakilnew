/* ============ Vakil AI — UI Pages & Interactions ============ */
(function () {
  'use strict';
  var S = window.Store, L = window.Legal, AI = window.AI;
  var q = function (id) { return document.getElementById(id); };
  function $(sel, root) { return (root || document).querySelector(sel); }
  function $$(sel, root) { return Array.prototype.slice.call((root || document).querySelectorAll(sel)); }
  function el(html) { var d = document.createElement('div'); d.innerHTML = html.trim(); return d.firstChild; }
  function ico(id, cls) { return '<svg class="ico ' + (cls || '') + '"><use href="#' + id + '"/></svg>'; }
  function esc(s) { return S.esc(s); }

  /* ================= toasts / modal / sheet ================= */
  function toast(msg, kind, ms) {
    var host = q('toastHost');
    var t = el('<div class="toast ' + (kind || '') + '">' + esc(msg) + '</div>');
    host.appendChild(t);
    setTimeout(function () {
      t.style.transition = 'opacity .3s, transform .3s';
      t.style.opacity = '0'; t.style.transform = 'translateY(8px)';
      setTimeout(function () { if (t.parentNode) t.parentNode.removeChild(t); }, 320);
    }, ms || 3200);
  }
  var modalStack = [];
  function modal(html, opts) {
    opts = opts || {};
    var host = q('modalHost');
    host.classList.add('on');
    var wrap = el('<div class="modal-bgwrap"><div class="modal-bg"></div><div class="modal">' + html + '</div></div>');
    host.appendChild(wrap);
    modalStack.push(wrap);
    var bg = $('.modal-bg', wrap);
    if (!opts.persistent) bg.addEventListener('click', function () { closeModal(); });
    return wrap;
  }
  function closeModal() {
    var m = modalStack.pop();
    var host = q('modalHost');
    if (m && m.parentNode) m.parentNode.removeChild(m);
    if (!modalStack.length) host.classList.remove('on');
  }
  var sheetEl = null;
  function sheet(html, opts) {
    opts = opts || {};
    var host = q('sheetHost');
    host.classList.add('on');
    host.innerHTML = '';
    sheetEl = el('<div><div class="sheet-bg"></div><div class="sheet">' + html + '</div></div>');
    host.appendChild(sheetEl);
    if (!opts.persistent) $('.sheet-bg', sheetEl).addEventListener('click', function () { closeSheet(); });
    return sheetEl;
  }
  function closeSheet() {
    q('sheetHost').classList.remove('on'); q('sheetHost').innerHTML = ''; sheetEl = null;
  }

  /* ================= navigation ================= */
  var VIEWS = ['home', 'cases', 'case', 'doc', 'draft', 'laws', 'settings'];
  var cur = 'home', stack = [];
  var TITLES = {
    home: ['وکیل هوشمند', 'دستیار حقوقی هوشمند ایران'],
    cases: ['پرونده‌های من', 'مدیریت و بایگانی پرونده‌ها'],
    case: ['جزئیات پرونده', ''],
    doc: ['تحلیل هوشمند پرونده', 'تحلیل چندعامله با هوش مصنوعی'],
    draft: ['نگارش حقوقی', 'لایحه، اظهارنامه، دادخواست و قرارداد'],
    laws: ['بانک قوانین ایران', 'جست‌وجو و استناد — کاملاً آفلاین'],
    settings: ['تنظیمات', 'اتصال هوش‌های مصنوعی و داده‌ها']
  };
  function go(view, opts) {
    opts = opts || {};
    if (view === cur && !opts.force) return;
    if (!opts.replace) stack.push({ v: cur, opts: curOpts });
    cur = view; curOpts = opts || {};
    VIEWS.forEach(function (v) {
      var node = q('view-' + v);
      if (node) node.classList.toggle('active', v === view);
    });
    $$('#dock .dock-btn').forEach(function (b) { b.classList.toggle('active', b.getAttribute('data-view') === view); });
    var isHome = view === 'home';
    q('topbar').classList.toggle('show', !isHome);
    q('btnBack').style.visibility = isHome ? 'hidden' : 'visible';
    updateTitle(view, opts);
    if (view === 'cases') renderCases();
    if (view === 'case') renderCase(opts.caseId || S.State.activeCaseId);
    if (view === 'doc') renderAnalyze();
    if (view === 'draft') renderDraft(opts.type || draftType);
    if (view === 'laws') { if (window.LawsUI) LawsUI.renderLaws(); }
    if (view === 'settings') renderSettings();
    if (view === 'home') renderHome();
    var vn = q('view-' + view);
    if (vn) vn.scrollTop = 0;
  }
  var curOpts = {};
  function updateTitle(view, opts) {
    var t = TITLES[view] || ['وکیل هوشمند', ''];
    q('tbTitle').textContent = t[0]; q('tbSub').textContent = t[1];
    if (view === 'case') {
      var c = S.getCase(opts.caseId || S.State.activeCaseId);
      if (c) { q('tbTitle').textContent = c.title; q('tbSub').textContent = (c.caseNo ? 'کلاسه ' + c.caseNo : 'بدون کلاسه') + ' · ' + c.type; }
    }
    var m = AI.modelLabel();
    q('tbModel').textContent = m;
    q('tbBadge').style.color = AI.isConfigured() ? '' : 'var(--warn)';
  }
  function back() {
    if (modalStack.length) { closeModal(); return true; }
    if (q('sheetHost').classList.contains('on')) { closeSheet(); return true; }
    var prev = stack.pop();
    if (!prev) return false;
    cur = prev.v; curOpts = prev.opts || {};
    VIEWS.forEach(function (v) { var n = q('view-' + v); if (n) n.classList.toggle('active', v === cur); });
    $$('#dock .dock-btn').forEach(function (b) { b.classList.toggle('active', b.getAttribute('data-view') === cur); });
    q('topbar').classList.toggle('show', cur !== 'home');
    q('btnBack').style.visibility = cur === 'home' ? 'hidden' : 'visible';
    updateTitle(cur, curOpts);
    if (cur === 'cases') renderCases();
    if (cur === 'case') renderCase(curOpts.caseId || S.State.activeCaseId);
    return true;
  }

  /* ================= HOME ================= */
  var curAgent = 'coordinator';
  function renderHome() {
    var c = S.activeCase();
    var pill = q('homeCasePill');
    pill.classList.toggle('live', !!c);
    $('span', pill).textContent = c ? (c.title + (c.caseNo ? ' · ' + c.caseNo : '')) : 'بدون پرونده فعال — از «پرونده‌ها» بسازید';
    /* agents row */
    var row = q('agentsRow');
    row.innerHTML = '';
    L.AGENTS.forEach(function (a) {
      var card = el('<button class="agent-card' + (a.id === curAgent ? ' sel' : '') + '" data-agent="' + a.id + '">' +
        '<span class="ag-ico">' + ico(a.icon) + '</span>' +
        '<span class="ag-n">' + esc(a.name) + '</span>' +
        '<span class="ag-m">' + esc(a.sub) + '</span>' +
        (a.id === 'coordinator' ? '<span class="ag-badge">پیش‌فرض</span>' : '') +
        '</button>');
      card.addEventListener('click', function () {
        curAgent = a.id;
        Character.nod();
        Character.say('من ' + a.name + ' هستم؛ ' + a.sub + '. در این حوزه کمکتان می‌کنم.', { mood: 'smile' });
        renderHome();
      });
      row.appendChild(card);
    });
    renderChat();
    updateQuickLabels();
  }
  function updateQuickLabels() {
    var ag = L.AGENTS.filter(function (a) { return a.id === curAgent; })[0];
    q('chatAgentName').textContent = ag.name;
    q('chatAgentSub').textContent = AI.isConfigured() ? (ag.sub + ' · ' + AI.modelLabel()) : 'برای تحلیل، کلید API را در تنظیمات وارد کنید';
  }

  /* ---- chat ---- */
  function chatContainer() { return q('chatBody'); }
  function msgNode(m) {
    var who = m.agent ? (L.AGENTS.filter(function (a) { return a.id === m.agent; })[0] || {}).name : '';
    if (m.role === 'user') {
      var imgs = (m.images || []).map(function (d) { return '<img src="' + d + '">'; }).join('');
      return el('<div class="msg user">' + (m.attached ? '<span class="who">' + ico('i-clip') + ' ' + esc(m.attached) + '</span>' : '') + MD.render(m.content || '') + imgs + '</div>');
    }
    if (m.role === 'sys') return el('<div class="msg sys">' + esc(m.content) + '</div>');
    return el('<div class="msg ai">' + (who ? '<span class="who">' + ico('i-scale') + ' ' + esc(who) + ' · ' + S.faTime(m.ts) + '</span>' : '') + MD.render(m.content || '') + '</div>');
  }
  function renderChat() {
    var box = chatContainer();
    if (!box) return;
    var caseId = S.State.activeCaseId;
    var s = S.getSession(caseId);
    box.innerHTML = '';
    s.messages.forEach(function (m) { box.appendChild(msgNode(m)); });
    box.scrollTop = box.scrollHeight;
  }
  function appendChat(m) {
    var box = chatContainer();
    if (box) { box.appendChild(msgNode(m)); box.scrollTop = box.scrollHeight; }
  }
  function sendChat(textOverride) {
    var ta = q('chatText');
    var text = (textOverride != null ? textOverride : (ta ? ta.value : '')).trim();
    if (!text) return;
    if (ta) { ta.value = ''; ta.style.height = 'auto'; }
    var caseId = S.State.activeCaseId;
    var atts = caseId ? S.filesOf(caseId) : S.filesOf(null);
    var images = S.visionImages(atts, 4);
    var userMsg = S.pushMsg(caseId, { role: 'user', content: text, ts: Date.now(), attached: atts.length ? atts.length + ' سند پیوست' : '' });
    appendChat(userMsg);
    Character.lookDown(); Character.think(true, 'یک لحظه... در حال بررسی');
    renderChat(); /* redraw to sync */

    if (!AI.isConfigured()) {
      Character.think(false);
      var offReply = window.OfflineAI.chatReply(text, docMode);
      var om = S.pushMsg(caseId, { role: 'assistant', content: offReply, ts: Date.now(), agent: curAgent });
      appendChat(om);
      Character.say('با استناد به بانک قوانین پاسخ دادم؛ برای پاسخ استدلالی مفصل، کلید API را در تنظیمات وارد کنید.', { mood: 'smile' });
      return;
    }
    var history = S.getSession(caseId).messages.slice(0, -1);
    AI.cites(text + ' ' + (atts.map(function (f) { return (f.text || '').slice(0, 200); }).join(' ')), docMode);
    var btn = q('chatSend'); if (btn) btn.classList.add('busy');
    AI.chat(curAgent, text, { history: history, caseObj: S.getCase(caseId), files: atts, images: images }).then(function (r) {
      Character.think(false);
      var m = S.pushMsg(caseId, { role: 'assistant', content: r.text, ts: Date.now(), agent: curAgent });
      appendChat(m);
      showCitations(q('chatBody'));
      Character.say(shorten(r.text), { mood: 'smile' });
      if (caseId) S.touchCase(caseId);
    }).catch(function (e) {
      Character.think(false);
      var m = S.pushMsg(caseId, { role: 'sys', content: 'خطا: ' + (e.message || e), ts: Date.now() });
      appendChat(m);
      Character.say('متأسفانه ارتباط با سرویس برقرار نشد. متن خطا را در گفتگو ببینید؛ ممکن است کلید یا مدل نیاز به بازبینی داشته باشد.', { mood: 'concerned' });
      toast((e.message || 'خطای ارتباط'), 'bad', 5200);
    }).then(function () { if (btn) btn.classList.remove('busy'); });
  }
  /* نمایش «استنادهای» بازیابی‌شده از بانک قوانین زیر هر پاسخ */
  function showCitations(host) {
    if (!host) return;
    var old = host.querySelector('.cite-strip');
    if (old) old.remove();
    var cs = AI.getCitations ? AI.getCitations() : [];
    if (!cs.length) return;
    var strip = el('<div class="cite-strip"><b>' + ico('i-quote') + ' استنادات از بانک قوانین</b>' +
      cs.map(function (c) {
        return '<button class="cite-chip" data-law="' + esc(c.law) + '">' +
          esc(c.law.length > 22 ? c.law.slice(0, 20) + '…' : c.law) + ' · ' + esc(c.curated ? c.art : 'مادهٔ ' + S.faDigits(c.art)) + '</button>';
      }).join('') + '</div>');
    strip.querySelectorAll('.cite-chip').forEach(function (btn) {
      btn.addEventListener('click', function () {
        var name = btn.getAttribute('data-law');
        var lawObj = window.Knowledge.laws.filter(function (l) { return l.name.indexOf(name.replace('…', '')) === 0; })[0];
        if (!lawObj) lawObj = window.Knowledge.laws.filter(function (l) { return l.name === name; })[0];
        go('laws');
        setTimeout(function () {
          var inp = q('lawQ');
          if (inp) { inp.value = name; inp.dispatchEvent(new Event('input')); }
        }, 250);
      });
    });
    host.appendChild(strip);
    host.scrollTop = host.scrollHeight;
  }

  function shorten(t) {
    var s = String(t).replace(/[#*`>|]/g, ' ').replace(/\s+/g, ' ').trim();
    return s.length > 260 ? s.slice(0, 256) + ' ...' : s;
  }

  /* ================= CASES ================= */
  function renderCases() {
    var list = q('casesList');
    if (!list) return;
    var term = (q('caseSearch').value || '').trim();
    list.innerHTML = '';
    var items = S.State.cases.filter(function (c) {
      if (!term) return true;
      return (c.title + ' ' + c.caseNo + ' ' + c.opponent + ' ' + c.subject + ' ' + c.type).indexOf(term) >= 0;
    });
    if (!items.length) {
      list.appendChild(el('<div class="empty">هنوز پرونده‌ای ثبت نشده است.<br>با دکمهٔ «پرونده جدید» اولین پرونده را بسازید تا اسناد، گفتگوها و تحلیل‌ها ذخیره شوند و هر بار نیازی به تعریف ماجرا نباشد.</div>'));
      return;
    }
    items.forEach(function (c) {
      var docs = S.filesOf(c.id).length;
      var prog = Math.min(100, 12 + (c.analysis || []).length * 26 + (c.drafts || []).length * 16 + docs * 7);
      var card = el('<div class="case-card">' +
        '<div class="case-top"><div><div class="case-title">' + esc(c.title) + '</div>' +
        '<div class="case-no">' + (c.caseNo ? esc(c.caseNo) : 'بدون کلاسه') + '</div></div>' +
        '<span class="case-type">' + esc(c.type) + '</span></div>' +
        '<div class="case-meta">' +
        '<span class="meta-chip">' + ico('i-user') + ' نقش من: ' + esc(c.myRole) + '</span>' +
        (c.opponent ? '<span class="meta-chip">' + ico('i-users') + ' ' + esc(c.opponent) + '</span>' : '') +
        '<span class="meta-chip">' + ico('i-files') + ' ' + S.faDigits(docs) + ' مدرک</span>' +
        '<span class="meta-chip">' + ico('i-clock') + ' ' + S.pdate(c.updatedAt) + '</span>' +
        (c.nextDate ? '<span class="meta-chip">' + ico('i-calendar') + ' ' + esc(c.nextDate) + '</span>' : '') +
        '</div>' +
        '<div class="case-foot"><div class="case-prog"><i style="width:' + prog + '%"></i></div>' +
        '<span class="case-state">' + esc(c.status) + '</span></div></div>');
      card.addEventListener('click', function () {
        S.State.activeCaseId = c.id; S.save();
        S.haptic(10);
        go('case', { caseId: c.id });
      });
      list.appendChild(card);
    });
  }

  function caseFormHtml(c) {
    c = c || {};
    var types = S.CASE_TYPES.map(function (t) { return '<option' + (c.type === t ? ' selected' : '') + '>' + t + '</option>'; }).join('');
    var roles = ['خواهان', 'خوانده', 'شاکی', 'متهم', 'وکیل', 'قرارداد'];
    var rolesHtml = roles.map(function (t) { return '<option' + (c.myRole === t ? ' selected' : '') + '>' + t + '</option>'; }).join('');
    return '<h3>' + ico('i-folder') + (c.id ? ' ویرایش پرونده' : ' پرونده جدید') + '</h3>' +
      '<div class="grid2">' +
      '<label class="field wide"><span>عنوان پرونده *</span><input id="fTitle" value="' + esc(c.title || '') + '" placeholder="مثال: مطالبه وجه چک — آقای رضایی"></label>' +
      '<label class="field"><span>شماره پرونده / کلاسه</span><input id="fNo" value="' + esc(c.caseNo || '') + '" placeholder="۹۸۰۹۸۷۶۵۴۳۲۱۰"></label>' +
      '<label class="field"><span>نوع پرونده</span><select id="fType">' + types + '</select></label>' +
      '<label class="field"><span>دادگاه / مرجع</span><input id="fCourt" value="' + esc(c.court || '') + '" placeholder="دادگاه عمومی حقوقی ..."></label>' +
      '<label class="field"><span>شعبه</span><input id="fBranch" value="' + esc(c.branch || '') + '" placeholder="شعبه ۱۲"></label>' +
      '<label class="field"><span>نقش من</span><select id="fRole">' + rolesHtml + '</select></label>' +
      '<label class="field"><span>طرف مقابل</span><input id="fOpp" value="' + esc(c.opponent || '') + '" placeholder="نام طرف مقابل"></label>' +
      '<label class="field"><span>وضعیت</span><input id="fStatus" value="' + esc(c.status || 'در جریان') + '" placeholder="در جریان / مختومه"></label>' +
      '<label class="field"><span>اقدام یا جلسهٔ بعدی</span><input id="fDate" value="' + esc(c.nextDate || '') + '" placeholder="۱۴۰۴/۰۵/۱۲ — جلسهٔ اول دادرسی"></label>' +
      '<label class="field wide"><span>موضوع و شرح کوتاه</span><textarea id="fSubject" rows="3" placeholder="خلاصهٔ موضوع پرونده...">' + esc(c.subject || '') + '</textarea></label>' +
      '<label class="field wide"><span>یادداشت‌های کلیدی</span><textarea id="fNotes" rows="3" placeholder="نکات مهم، شماره تماس‌ها، مهلت‌ها...">' + esc(c.notes || '') + '</textarea></label>' +
      '</div>' +
      '<div class="m-foot"><button class="gold-btn" id="fSave">' + ico('i-check') + ' ذخیره</button>' +
      (c.id ? '<button class="danger-btn" id="fDel">' + ico('i-trash') + ' حذف پرونده</button>' : '') +
      '<button class="ghost-btn" id="fCancel">انصراف</button></div>';
  }

  function openCaseForm(c) {
    var w = modal(caseFormHtml(c), { persistent: true });
    $('#fCancel', w).addEventListener('click', closeModal);
    $('#fSave', w).addEventListener('click', function () {
      var data = {
        title: $('#fTitle').value.trim() || 'پرونده بدون عنوان',
        caseNo: $('#fNo').value.trim(), type: $('#fType').value, court: $('#fCourt').value.trim(),
        branch: $('#fBranch').value.trim(), myRole: $('#fRole').value, opponent: $('#fOpp').value.trim(),
        status: $('#fStatus').value.trim() || 'در جریان', nextDate: $('#fDate').value.trim(),
        subject: $('#fSubject').value.trim(), notes: $('#fNotes').value.trim()
      };
      if (c && c.id) {
        Object.keys(data).forEach(function (k) { c[k] = data[k]; });
        c.timeline = c.timeline || []; c.timeline.push({ ts: Date.now(), text: 'اطلاعات پرونده ویرایش شد' });
        S.touchCase(c.id);
        toast('پرونده به‌روزرسانی شد', 'ok');
        Character.say('اطلاعات پرونده ثبت شد. از این پس با انتخاب همین پرونده، همهٔ سابق را می‌دانم و لازم نیست از اول تعریف کنید.', { mood: 'smile' });
      } else {
        var nc = S.createCase(data);
        S.State.activeCaseId = nc.id; S.save();
        nc.timeline.push({ ts: Date.now(), text: 'پرونده ایجاد شد' });
        toast('پرونده جدید ساخته شد', 'ok');
        Character.say('پرونده «' + nc.title + '» ساخته شد. حالا مدارک را پیوست کنید تا تحلیل کامل شروع شود.', { mood: 'happy' });
      }
      closeModal();
      renderCases(); renderHome(); updateTitle(cur, curOpts);
    });
    if (c && c.id) {
      $('#fDel', w).addEventListener('click', function () {
        modal('<h3>' + ico('i-alert') + ' حذف پرونده</h3><p class="card-p">با حذف پرونده، همهٔ مدارک، گفتگوها و تحلیل‌های آن حذف می‌شود. مطمئن هستید؟</p>' +
          '<div class="m-foot"><button class="danger-btn" id="yes">بله، حذف کن</button><button class="ghost-btn" id="no">انصراف</button></div>');
        var w2 = modalStack[modalStack.length - 1];
        var yes = w2.querySelector('#yes'), no = w2.querySelector('#no');
        no.addEventListener('click', closeModal);
        yes.addEventListener('click', function () {
          S.deleteCase(c.id); closeModal(); closeModal(); toast('پرونده حذف شد');
          renderCases(); renderHome(); go('cases', { replace: true });
        });
      });
    }
  }

  /* ================= CASE DETAIL ================= */
  var caseTab = 'overview';
  var selFileIds = [];
  function renderCase(caseId) {
    var c = S.getCase(caseId || S.State.activeCaseId);
    if (!c) { go('cases', { replace: true }); return; }
    S.State.activeCaseId = c.id; S.save();
    var docs = S.filesOf(c.id);
    var hero = q('caseHero');
    hero.innerHTML = '<h3>' + esc(c.title) + '</h3>' +
      '<div class="no">' + (c.caseNo ? 'کلاسه: ' + esc(c.caseNo) : 'کلاسه ثبت نشده') + (c.court ? ' · ' + esc(c.court) : '') + '</div>' +
      '<div class="case-meta">' +
      '<span class="meta-chip">' + ico('i-scale') + ' ' + esc(c.type) + '</span>' +
      '<span class="meta-chip">' + ico('i-user') + ' ' + esc(c.myRole) + '</span>' +
      (c.opponent ? '<span class="meta-chip">' + ico('i-users') + ' ' + esc(c.opponent) + '</span>' : '') +
      '<span class="meta-chip">' + ico('i-files') + ' ' + S.faDigits(docs.length) + ' مدرک</span>' +
      '<span class="meta-chip">' + ico('i-brain') + ' ' + S.faDigits((c.analysis || []).length) + ' تحلیل</span>' +
      '<span class="meta-chip">' + ico('i-pen') + ' ' + S.faDigits((c.drafts || []).length) + ' نگارش</span>' +
      '</div>';
    $$('#caseTabs .tab').forEach(function (t) { t.classList.toggle('active', t.getAttribute('data-ct') === caseTab); });
    var body = q('caseTabBody');
    body.innerHTML = '';

    if (caseTab === 'overview') {
      body.appendChild(el('<div class="card"><div class="card-h">' + ico('i-folder-open') + ' شناسنامه پرونده</div>' +
        '<dl class="kv">' +
        '<dt>موضوع</dt><dd>' + (esc(c.subject) || '—') + '</dd>' +
        '<dt>وضعیت</dt><dd>' + esc(c.status || '—') + '</dd>' +
        '<dt>اقدام بعدی</dt><dd>' + (esc(c.nextDate) || '—') + '</dd>' +
        '<dt>یادداشت‌ها</dt><dd>' + (esc(c.notes) || '—') + '</dd>' +
        '<dt>ایجاد</dt><dd>' + S.pdate(c.createdAt) + '</dd>' +
        '<dt>آخرین تغییر</dt><dd>' + S.pdate(c.updatedAt) + '</dd>' +
        '</dl>' +
        '<div class="row-actions">' +
        '<button class="gold-btn sm" id="cEdit">' + ico('i-pen') + ' ویرایش</button>' +
        '<button class="ghost-btn" id="cAnalyze">' + ico('i-brain') + ' تحلیل کامل پرونده</button>' +
        '<button class="ghost-btn" id="cAddDoc">' + ico('i-plus') + ' افزودن مدرک</button>' +
        '<button class="ghost-btn" id="cDraft">' + ico('i-pen') + ' نگارش سند</button>' +
        '</div></div>'));
      var tl = el('<div class="card"><div class="card-h">' + ico('i-clock') + ' روند پرونده</div>' +
        '<ul class="steps">' + ((c.timeline || []).slice(-14).reverse().map(function (t) {
          return '<li>' + ico('i-check') + '<span>' + esc(t.text) + '<br><span class="ro">' + S.pdate(t.ts) + ' · ' + S.faTime(t.ts) + '</span></span></li>';
        }).join('') || '<li><span class="ro">فعالیتی ثبت نشده است.</span></li>') + '</ul></div>');
      body.appendChild(tl);
      $('#cEdit', body).addEventListener('click', function () { openCaseForm(c); });
      $('#cAddDoc', body).addEventListener('click', function () { pickAndAttach(c.id); });
      $('#cAnalyze', body).addEventListener('click', function () {
        selFileIds = S.filesOf(c.id).map(function (f) { return f.id; });
        go('doc');
      });
      $('#cDraft', body).addEventListener('click', function () { go('draft'); });
    }

    if (caseTab === 'docs') {
      var grid = el('<div class="card"><div class="card-h">' + ico('i-files') + ' مدارک و اسناد پرونده</div>' +
        '<div class="dropzone" id="dz">' + ico('i-upload') + ' برای افزودن مدرک لمس کنید (تصویر، PDF، متن، Word)</div>' +
        '<div class="docs-grid" id="docsGrid"></div></div>');
      body.appendChild(grid);
      var g = $('#docsGrid', grid);
      docs.forEach(function (f) {
        var thumb = f.kind === 'image' ? '<img src="' + f.dataUrl + '">' :
          ico(f.kind === 'pdf' ? 'i-pdf' : f.kind === 'text' ? 'i-files' : 'i-files');
        var d = el('<div class="doc-card"><div class="doc-thumb">' + thumb + '</div>' +
          '<div class="doc-name">' + esc(f.name) + '</div>' +
          '<div class="doc-size">' + S.fmtSize(f.size) + ' · ' + S.pdate(f.createdAt) + '</div>' +
          '<button class="doc-del">' + ico('i-trash') + '</button></div>');
        $('.doc-del', d).addEventListener('click', function () {
          modal('<h3>' + ico('i-alert') + ' حذف مدرک</h3><p class="card-p">«' + esc(f.name) + '» حذف شود؟</p>' +
            '<div class="m-foot"><button class="danger-btn" id="yes">حذف کن</button><button class="ghost-btn" id="no">انصراف</button></div>');
          var w = modalStack[modalStack.length - 1];
          w.querySelector('#yes').addEventListener('click', function () {
            S.delFile(f.id); closeModal(); toast('مدرک حذف شد'); renderCase(c.id);
          });
          w.querySelector('#no').addEventListener('click', closeModal);
        });
        g.appendChild(d);
      });
      $('#dz', grid).addEventListener('click', function () { pickAndAttach(c.id); });
    }

    if (caseTab === 'chat') {
      body.appendChild(el('<div class="card"><div class="card-h">' + ico('i-chat') + ' گفتگوی همین پرونده</div>' +
        '<p class="card-p">همهٔ گفتگوها، مدارک و تحلیل‌های این پرونده در حافظه باقی می‌ماند؛ با انتخاب این پرونده، کارشناسان همه را می‌بینند.</p>' +
        '<div id="caseChatBody" class="chat-body"></div>' +
        '<div class="chat-input" style="border-radius:14px;margin-top:10px">' +
        '<button class="icon-btn mini" id="ccAttach">' + ico('i-clip') + '</button>' +
        '<textarea id="ccText" rows="1" placeholder="پرسش یا توضیح خود را بنویسید..."></textarea>' +
        '<button class="send-btn" id="ccSend">' + ico('i-send') + '</button></div></div>'));
      var cb = $('#caseChatBody', body);
      var sess = S.getSession(c.id);
      sess.messages.forEach(function (m) { cb.appendChild(msgNode(m)); });
      cb.scrollTop = cb.scrollHeight;
      $('#ccAttach', body).addEventListener('click', function () { pickAndAttach(c.id); });
      var send = function () {
        var ta = $('#ccText', body);
        var text = ta.value.trim(); if (!text) return;
        /* مسیر گفتگو را به همان گفتگوی اصلی منتقل می‌کنیم */
        q('chatText') || null;
        var mainTa = q('chatText');
        mainTa.value = text;
        sendChat(text);
        ta.value = '';
        var box = q('chatBody');
        cb.innerHTML = '';
        S.getSession(c.id).messages.forEach(function (m) { cb.appendChild(msgNode(m)); });
        cb.scrollTop = cb.scrollHeight;
        /* sync main chat view */
        q('view-home') && renderChat();
      };
      $('#ccSend', body).addEventListener('click', send);
      $('#ccText', body).addEventListener('keydown', function (e) { if (e.key === 'Enter' && !e.shiftKey) { e.preventDefault(); send(); } });
    }

    if (caseTab === 'analysis') {
      var outs = (c.analysis || []);
      body.appendChild(el('<div class="card"><div class="card-h">' + ico('i-target') + ' تحلیل‌های انجام‌شده</div>' +
        '<div class="row-actions"><button class="gold-btn sm" id="aNew">' + ico('i-bolt') + ' تحلیل جدید این پرونده</button></div>' +
        '<p class="card-p">' + ((outs.length) ? 'آخرین تحلیل‌ها:' : 'هنوز تحلیلی ثبت نشده است.') + '</p><div id="aList"></div></div>'));
      var al = $('#aList', body);
      outs.slice().reverse().forEach(function (a) {
        var rep = el('<div class="report" style="margin-bottom:12px"><div class="report-h">' + ico('i-brain') + ' ' + esc(a.title || 'تحلیل') +
          '<span class="ro">' + S.pdate(a.ts) + '</span></div><div class="report-b">' + MD.render(a.text) + '</div>' +
          '<div class="report-f"><button class="ghost-btn sm" data-copy>' + ico('i-files') + ' کپی</button></div></div>');
        $('[data-copy]', rep).addEventListener('click', function () { copyText(a.text); });
        al.appendChild(rep);
      });
      $('#aNew', body).addEventListener('click', function () {
        selFileIds = S.filesOf(c.id).map(function (f) { return f.id; });
        go('doc');
      });
    }

    if (caseTab === 'drafts') {
      var ds = (c.drafts || []);
      body.appendChild(el('<div class="card"><div class="card-h">' + ico('i-pen') + ' نگارش‌های ذخیره‌شده</div>' +
        '<div class="row-actions"><button class="gold-btn sm" id="dNew">' + ico('i-plus') + ' نگارش جدید</button></div><div id="dList"></div></div>'));
      var dl = $('#dList', body);
      if (!ds.length) dl.appendChild(el('<p class="card-p">هنوز سندی نوشته نشده است. لایحه، اظهارنامه، دادخواست یا قرارداد را با چند کلیک بنویسید.</p>'));
      ds.slice().reverse().forEach(function (d) {
        var cardD = el('<div class="report" style="margin-bottom:12px"><div class="report-h">' + ico('i-pen') + ' ' + esc(d.typeName || d.type) +
          '<span class="ro">' + S.pdate(d.ts) + '</span></div><div class="paper">' + MD.render(d.text) + '</div>' +
          '<div class="report-f"><button class="ghost-btn sm" data-copy>' + ico('i-files') + ' کپی متن</button>' +
          '<button class="ghost-btn sm" data-del>' + ico('i-trash') + ' حذف</button></div></div>');
        $('[data-copy]', cardD).addEventListener('click', function () { copyText(d.text); });
        $('[data-del]', cardD).addEventListener('click', function () {
          c.drafts = c.drafts.filter(function (x) { return x !== d; }); S.touchCase(c.id); renderCase(c.id); toast('حذف شد');
        });
        dl.appendChild(cardD);
      });
      $('#dNew', body).addEventListener('click', function () { go('draft'); });
    }
  }

  function pickAndAttach(caseId) {
    S.pickFiles().then(function (files) {
      if (!files.length) return;
      var n = 0;
      Character.think(true, 'در حال مطالعهٔ مدارک...');
      var chain = Promise.resolve();
      files.forEach(function (f) {
        chain = chain.then(function () {
          var origAdd = S.addFile;
          /* سند را با شناسه پرونده جاری ثبت می‌کنیم */
          return S.extractFile(f).then(function (info) {
            /* آخرین فایل اضافه‌شده را به پرونده متصل کن */
            var last = S.State.files[S.State.files.length - 1];
            if (last && !last.caseId) {
              last.caseId = caseId || null;
              var c = S.getCase(caseId);
              if (c) c.timeline.push({ ts: Date.now(), text: 'مدرک «' + last.name + '» به پرونده پیوست شد' });
            }
            n++;
            S.save();
            var msg = info.kind === 'image' ? 'تصویر' : info.kind === 'pdf' ? 'PDF' : info.kind === 'doc' ? 'سند متنی' : 'فایل';
            toast(msg + ' «' + f.name + '» پیوست شد', 'ok');
          });
        });
      });
      chain.then(function () {
        Character.think(false);
        if (n) {
          Character.say('مدارک را دریافت کردم و کنار هم گذاشتم؛ می‌توانم حالا تحلیل جامع و اصولی ارائه بدهم.', { mood: 'happy' });
          if (cur === 'case') renderCase(caseId || S.State.activeCaseId);
          if (cur === 'doc') renderAnalyze();
          if (cur === 'home') renderHome();
        }
      });
    });
  }

  /* ================= ANALYZE ================= */
  var docMode = 'auto';
  function renderAnalyze() {
    var c = S.activeCase();
    var caseFiles = c ? S.filesOf(c.id) : S.filesOf(null);
    if (!selFileIds.length) selFileIds = caseFiles.map(function (f) { return f.id; });
    var strip = q('docAttach');
    strip.innerHTML = '';
    selFileIds.forEach(function (id) {
      var f = S.State.files.filter(function (x) { return x.id === id; })[0];
      if (!f) return;
      var chip = el('<span class="att-chip">' + ico(f.kind === 'image' ? 'i-image' : f.kind === 'pdf' ? 'i-pdf' : 'i-files') +
        esc(f.name.length > 22 ? f.name.slice(0, 20) + '…' : f.name) + '<button title="حذف">×</button></span>');
      $('button', chip).addEventListener('click', function (e) {
        e.stopPropagation();
        selFileIds = selFileIds.filter(function (x) { return x !== id; });
        renderAnalyze();
      });
      strip.appendChild(chip);
    });
    if (!selFileIds.length && caseFiles.length) strip.appendChild(el('<span class="att-chip">' + ico('i-clip') + ' مدرکی انتخاب نشده</span>'));
    $$('#modeSeg .seg-btn').forEach(function (b) { b.classList.toggle('active', b.getAttribute('data-mode') === docMode); });
    q('docHint').textContent = L.MODES[docMode] ? L.MODES[docMode].hint : '';
  }

  function runAnalysis() {
    var text = q('docText').value.trim();
    var c = S.activeCase();
    var files = selFileIds.map(function (id) {
      return S.State.files.filter(function (x) { return x.id === id; })[0];
    }).filter(Boolean);
    if (!text && !files.length) {
      toast('شرح موضوع یا حداقل یک مدرک لازم است', 'bad');
      Character.say('برای تحلیل دقیق، یا شرح موضوع را بنویسید یا مدرک پیوست کنید.', { mood: 'concerned' });
      return;
    }
    var out = q('docOut');
    out.innerHTML = '';
    var rep = el('<div class="report"><div class="report-h">' + ico('i-brain') + ' در حال تحلیل پرونده' +
      '<span class="ro" id="repState">آماده‌سازی...</span></div><div class="report-b" id="repBody"></div></div>');
    out.appendChild(rep);
    var repBody = $('#repBody', rep), repState = $('#repState', rep);

    if (!AI.isConfigured()) {
      var offText = window.OfflineAI.analyze(text, docMode, c, files);
      repBody.innerHTML = MD.render(offText);
      repState.textContent = 'تحلیل آفلاین بانک قوانین';
      var offF = el('<div class="report-f">' +
        '<button class="gold-btn sm" id="offSave">' + ico('i-bookmark') + ' ذخیره در پرونده</button>' +
        '<button class="ghost-btn sm" id="offCopy">' + ico('i-files') + ' کپی متن</button>' +
        '<button class="ghost-btn sm" id="offApi">' + ico('i-key') + ' فعال‌سازی تحلیل API</button></div>');
      rep.appendChild(offF);
      $('#offCopy', offF).addEventListener('click', function () { copyText(offText); });
      $('#offApi', offF).addEventListener('click', function () { go('settings'); });
      $('#offSave', offF).addEventListener('click', function () {
        if (!c) { toast('ابتدا یک پرونده بسازید یا انتخاب کنید', 'bad'); openCaseForm(null); return; }
        c.analysis = c.analysis || [];
        c.analysis.push({ ts: Date.now(), title: 'تحلیل آفلاین — ' + S.pdate(), text: offText });
        c.timeline.push({ ts: Date.now(), text: 'تحلیل آفلاین (بانک قوانین) ثبت شد' });
        S.touchCase(c.id);
        toast('تحلیل در پرونده ذخیره شد', 'ok');
      });
      Character.say('کلید API تنظیم نشده، اما تحلیل آفلاین را بر پایهٔ بانک قوانین انجام دادم: ' +
        S.faDigits(window.Knowledge ? window.Knowledge.size : 0) + ' مدخل قانونی در حافظهٔ برنامه است و موادی که به موضوع شما مربوط بودند، با ذکر شماره استناد شدند.', { mood: 'smile' });
      return;
    }

    var images = S.visionImages(files, 4);
    var stages = [];
    Character.think(true, 'تیم حقوقی در حال بررسی پرونده است...');
    var t0 = Date.now();

    AI.analyze({
      mode: docMode, text: text, caseObj: c, files: files, images: images,
      onStage: function (st) {
        if (st.phase === 'agent') {
          stages.push(st.agent);
          repState.textContent = st.agent.name + ' (' + S.faDigits(st.index) + ' از ' + S.faDigits(st.total) + ')';
          repBody.innerHTML = '<div class="think-line"><span class="spin"></span> ' + esc(st.agent.name) + ' در حال بررسی و استخراج مواد قانونی...</div>' +
            stages.map(function (a) { return '<div class="agent-vo"><span class="ag-ico">' + ico(a.icon) + '</span><div><b>' + esc(a.name) + '</b><div class="th">' + esc(a.sub) + '</div></div></div>'; }).join('');
          Character.say(st.agent.name + ' در حال بررسی است؛ کمی صبر کنید...', { mood: 'think', speed: 24 });
        } else if (st.phase === 'synthesis') {
          repState.textContent = 'جمع‌بندی نهایی';
          repBody.innerHTML = '<div class="think-line"><span class="spin"></span> سرپرست پرونده در حال جمع‌بندی نظرات کارشناسان و تنظیم راهکار اصولی...</div>';
          Character.say('نظرها را جمع‌بندی می‌کنم تا یک راهکار واحد و دقیق بگیرید.', { mood: 'think', speed: 24 });
        }
      }
    }).then(function (r) {
      var secs = Math.round((Date.now() - t0) / 1000);
      repState.textContent = 'پایان · ' + S.faDigits(secs) + ' ثانیه';
      var cits = AI.getCitations ? AI.getCitations() : [];
      var body = r.combined;
      if (r.parts && r.parts.length > 1) {
        body += '\n\n---\n\n## ضمیمه: دیدگاه‌های تخصصی هر کارشناس\n' +
          r.parts.map(function (p) { return '### ' + p.agent.name + '\n' + p.text; }).join('\n\n');
      }
      repBody.innerHTML = MD.render(body);
      /* footer actions */
      var f = el('<div class="report-f">' +
        '<button class="gold-btn sm" id="rSave">' + ico('i-bookmark') + ' ذخیره در پرونده</button>' +
        '<button class="ghost-btn sm" id="rCopy">' + ico('i-files') + ' کپی متن</button>' +
        '<button class="ghost-btn sm" id="rDoc">' + ico('i-pdf') + ' ذخیره به‌عنوان سند</button>' +
        (q('view-doc').querySelector('#docDraftBtn') ? '' : '') + '</div>');
      rep.appendChild(f);
      showCitations(rep);
      $('#rCopy', f).addEventListener('click', function () { copyText(body); });
      $('#rDoc', f).addEventListener('click', function () {
        S.addFile({ caseId: c ? c.id : null, name: 'تحلیل هوش مصنوعی — ' + S.pdate(), kind: 'text', text: body, size: body.length });
        toast('تحلیل به‌عنوان سند ذخیره شد', 'ok');
        Character.nod();
      });
      $('#rSave', f).addEventListener('click', function () {
        if (!c) {
          toast('ابتدا یک پرونده بسازید یا انتخاب کنید', 'bad');
          openCaseForm(null);
          return;
        }
        c.analysis = c.analysis || [];
        c.analysis.push({ ts: Date.now(), title: 'تحلیل ' + (L.MODES[docMode] ? L.MODES[docMode].label : docMode) + ' — ' + S.pdate(), text: body });
        c.timeline.push({ ts: Date.now(), text: 'تحلیل هوشمند ثبت شد (' + (L.MODES[docMode] ? L.MODES[docMode].label : docMode) + ')' });
        S.touchCase(c.id);
        toast('تحلیل در پرونده ذخیره شد', 'ok');
        Character.gesture(1.2);
      });
      Character.think(false);
      Character.say(summarizeChar(body), { mood: 'smile' });
      S.haptic(25);
    }).catch(function (e) {
      Character.think(false);
      repState.textContent = 'خطا';
      repBody.innerHTML = '<div class="agent-vo">' + ico('i-alert') + '<div><b>تحلیل انجام نشد</b><div class="th">' + esc(e.message || String(e)) + '</div></div></div>' +
        MD.render('\n\n**راهنمای رفع خطا:**\n- صحت کلید API و انتخاب مدل را در تنظیمات بررسی و «تست اتصال» بگیرید.\n- اگر مدل انتخاب‌شده تصویری نیست، تصویر را حذف و فقط متن بفرستید.\n- در صورت محدودیت نرخ، چند دقیقه بعد تلاش کنید.');
      Character.say('متأسفانه تحلیل کامل نشد. متن خطا را ببینید؛ با تست اتصال در تنظیمات معمولاً مشکل مشخص می‌شود.', { mood: 'concerned' });
    });
  }
  function summarizeChar(mdText) {
    var t = String(mdText).replace(/```[\s\S]*?```/g, ' ').replace(/[#>*`|]/g, ' ')
      .replace(/\[(.*?)\]\(.*?\)/g, '$1').replace(/\s+/g, ' ').trim();
    var first = t.split(/(?<=[.؟!])\s/).slice(0, 2).join(' ');
    return 'تحلیل انجام شد. ' + (first.length > 220 ? first.slice(0, 216) + '…' : first) + ' جزئیات کامل را در گزارش ببینید.';
  }

  /* ================= DRAFT ================= */
  var draftType = 'lawyer';
  var draftValues = {};
  function renderDraft(type) {
    draftType = type || draftType;
    var host = q('draftTypes');
    host.innerHTML = '';
    L.DRAFT_TYPES.forEach(function (t) {
      var b = el('<button class="tile' + (t.id === draftType ? ' sel' : '') + '" style="' + (t.id === draftType ? 'border-color:rgba(231,196,119,.65)' : '') + '">' +
        '<span class="tile-ico c1">' + ico(t.icon) + '</span><span class="tile-t">' + t.name + '</span><span class="tile-s">' + t.desc + '</span></button>');
      b.addEventListener('click', function () { draftValues = {}; renderDraft(t.id); Character.nod(); });
      host.appendChild(b);
    });
    var spec = L.DRAFT_SPEC[draftType] || { fields: [] };
    var form = q('draftForm');
    form.innerHTML = '<div class="card"><div class="card-h">' + ico('i-pen') + ' اطلاعات سند: ' + (L.DRAFT_TYPES.filter(function (x) { return x.id === draftType; })[0] || {}).name + '</div>' +
      '<div class="grid2" id="dfGrid"></div><p class="card-p">مشخصات شما از «تنظیمات ← مشخصات من» به‌صورت خودکار در سند درج می‌شود.</p></div>';
    var grid = $('#dfGrid', form);
    spec.fields.forEach(function (f) {
      var val = draftValues[f.k] || (f.k === 'me' ? (S.State.settings.me.name || '') : '');
      var label = el('<label class="field' + (f.k === 'core' || f.k === 'args' ? ' wide' : '') + '"><span>' + f.label + '</span>' +
        (f.k === 'core' || f.k === 'args'
          ? '<textarea rows="3" data-k="' + f.k + '" placeholder="' + esc(f.ph || '') + '">' + esc(val) + '</textarea>'
          : '<input data-k="' + f.k + '" value="' + esc(val) + '" placeholder="' + esc(f.ph || '') + '">') + '</label>');
      grid.appendChild(label);
    });
    var c = S.activeCase();
    var dc = el('<div class="card"><div class="card-h">' + ico('i-folder') + ' پیوست مدارک</div>' +
      '<div class="attach-strip" id="draftAttach"></div>' +
      '<div class="row-actions"><button class="ghost-btn" id="dAttachBtn">' + ico('i-clip') + ' پیوست سند</button>' +
      (c ? '<span class="meta-chip">' + ico('i-folder-open') + ' ' + esc(c.title) + '</span>' : '<span class="meta-chip">' + ico('i-alert') + ' پرونده‌ای فعال نیست</span>') +
      '</div></div>');
    form.appendChild(dc);
    var strip = $('#draftAttach', dc);
    var files = c ? S.filesOf(c.id) : [];
    (files.length ? files : []).forEach(function (f) {
      strip.appendChild(el('<span class="att-chip">' + ico('i-files') + esc(f.name.slice(0, 22)) + '</span>'));
    });
    if (!files.length) strip.appendChild(el('<span class="ro">مدرکی پیوست نیست — می‌توانید سند را بدون مدرک هم بسازید.</span>'));
    $('#dAttachBtn', dc).addEventListener('click', function () { pickAndAttach(c ? c.id : null); });
    q('draftSaveCase').hidden = !c;
  }

  function runDraft() {
    var values = {};
    $$('#draftForm [data-k]').forEach(function (i) { values[i.getAttribute('data-k')] = i.value.trim(); });
    draftValues = values;
    if (!Object.keys(values).some(function (k) { return values[k]; })) {
      toast('حداقل «موضوع/خواسته» را وارد کنید', 'bad');
      Character.say('برای نوشتن سند، موضوع و اطلاعات اصلی را وارد کنید؛ بقیه را من تنظیم می‌کنم.', { mood: 'concerned' });
      return;
    }
    var c = S.activeCase();
    var files = c ? S.filesOf(c.id) : [];
    var out = q('draftOut');
    out.innerHTML = '<div class="think-line"><span class="spin"></span> در حال نگارش سند حقوقی...</div>';
    out.classList.add('skeleton');
    Character.think(true, 'متن سند را با دقت تنظیم می‌کنم...');

    if (!AI.isConfigured()) {
      out.classList.remove('skeleton');
      var T = L.DRAFT_TYPES.filter(function (t) { return t.id === draftType; })[0];
      out.innerHTML = 'بسمه تعالی\n\n' + (T ? T.name : 'سند') + '\n\n' +
        (values.court ? 'مرجع: ' + values.court + '\n' : '') +
        (values.caseNo ? 'کلاسه: ' + values.caseNo + '\n' : '') +
        (values.me ? 'مشخصات: ' + values.me + '\n' : '') +
        (values.who ? 'طرف مقابل: ' + values.who + '\n' : '') +
        '\n۱- ' + (values.core || 'موضوع سند') + '\n' +
        (values.args ? '۲- دلایل: ' + values.args + '\n' : '') +
        '\nبا عنایت به مراتب فوق و مستندات پرونده، رسیدگی و اتخاذ تصمیم مقتضی مورد استدعاست.\n\n' +
        'امضا و اثر انگشت:\n\n' + S.pdate() + '\n\n' +
        '—— برای نگارش کامل، مستند و مستدل (با ذکر مواد قانونی)، کلید API را در تنظیمات وارد کنید. ——';
      Character.think(false);
      Character.say('قالب خام سند آماده شد؛ برای نسخهٔ کامل حقوقی با ذکر مواد قانونی، کلید API را در تنظیمات وارد کنید.', { mood: 'concerned' });
      return;
    }

    AI.draft(draftType, values, c, files).then(function (r) {
      out.classList.remove('skeleton');
      out.innerHTML = MD.render(r.text);
      Character.think(false);
      Character.say('سند «' + (r.typeName || '') + '» آماده شد. متن را مرور کنید و در صورت نیاز در پرونده ذخیره کنید.', { mood: 'happy' });
      var fb = q('draftSaveCase');
      fb.hidden = !c;
      fb.onclick = function () {
        if (!c) return;
        c.drafts = c.drafts || [];
        c.drafts.push({ ts: Date.now(), type: draftType, typeName: r.typeName, text: r.text, values: values });
        c.timeline.push({ ts: Date.now(), text: 'سند «' + r.typeName + '» تنظیم و ذخیره شد' });
        S.touchCase(c.id);
        toast('سند در پرونده ذخیره شد', 'ok');
        Character.gesture(1.2);
      };
    }).catch(function (e) {
      out.classList.remove('skeleton');
      out.innerHTML = 'خطا در نگارش سند: ' + esc(e.message || String(e));
      Character.think(false);
      Character.say('نگارش سند کامل نشد؛ متن خطا را ببینید.', { mood: 'concerned' });
    });
  }

  function copyText(t) {
    try {
      var ta = document.createElement('textarea');
      ta.value = t; ta.style.position = 'fixed'; ta.style.opacity = '0';
      document.body.appendChild(ta); ta.select();
      document.execCommand('copy');
      document.body.removeChild(ta);
      toast('متن کپی شد', 'ok');
      return true;
    } catch (e) { toast('کپی ناموفق بود', 'bad'); return false; }
  }

  /* ================= SETTINGS ================= */
  function renderSettings() {
    /* API rows */
    var host = q('apiList');
    host.innerHTML = '';
    Object.keys(AI.PROVIDERS).forEach(function (pid) {
      var P = AI.PROVIDERS[pid];
      var st = S.State.settings.providers[pid] || (S.State.settings.providers[pid] = { key: '' });
      var row = el('<div class="api-row">' +
        '<span class="api-logo" style="background:' + P.color + '">' + ico(P.icon) + '</span>' +
        '<div class="api-body"><b>' + esc(P.name) + '</b>' +
        '<input type="password" id="k_' + pid + '" value="' + esc(st.key || '') + '" placeholder="' + esc(P.keyHint || 'کلید API') + '" autocomplete="off">' +
        (pid === 'custom'
          ? '<input id="b_custom" value="' + esc((st.base || '')) + '" placeholder="Base URL — مثال: https://api.example.com/v1/chat/completions" style="margin-top:6px">' +
            '<input id="m_custom" value="' + esc((st.model || '')) + '" placeholder="نام مدل — مثال: my-model-name" style="margin-top:6px">'
          : '') +
        '</div>' +
        '<div class="api-acts"><span class="api-state" id="s_' + pid + '">تست نشده</span>' +
        '<button class="ghost-btn" data-test="' + pid + '">' + ico('i-bolt') + ' تست اتصال</button></div></div>');
      host.appendChild(row);
      $('#k_' + pid, row).addEventListener('change', function () {
        st.key = this.value.trim(); S.save(true);
      });
      if (pid === 'custom') {
        $('#b_custom', row).addEventListener('change', function () { st.base = this.value.trim(); S.save(true); refreshModelSelect(); });
        $('#m_custom', row).addEventListener('change', function () { st.model = this.value.trim(); S.save(true); refreshModelSelect(); });
      }
      $('[data-test]', row).addEventListener('click', function () {
        var state = $('#s_' + pid, row);
        var btn = this;
        var models = pid === 'custom' ? [st.model || ''] : P.models;
        if (pid === 'custom' && !st.model) {
          toast('نام مدل سرویس سفارشی را وارد کنید', 'bad'); return;
        }
        var mIdx = 0;
        state.className = 'api-state testing'; state.textContent = 'در حال تست...';
        btn.disabled = true;
        function tryNext() {
          if (mIdx >= models.length) {
            state.className = 'api-state bad'; state.textContent = 'اتصال ناموفق';
            toast('هیچ مدلی از ' + P.name + ' پاسخ نداد — کلید/دسترسی را بررسی کنید', 'bad', 5000);
            btn.disabled = false; return;
          }
          var mdl = models[mIdx++];
          AI.testConnection(pid, mdl).then(function (r) {
            if (r.ok) {
              state.className = 'api-state ok';
              state.textContent = 'سالم · ' + mdl;
              toast(P.name + ': ' + r.msg, 'ok');
              btn.disabled = false;
              refreshModelSelect();
              updateTitle(cur, curOpts);
              if (!S.State.settings.defaultModel) { S.State.settings.defaultModel = AI.joinModel(pid, mdl); S.save(true); refreshModelSelect(); }
            } else {
              state.className = 'api-state bad';
              state.textContent = 'ناموفق';
              if (models.length > 1 && mIdx < models.length) { tryNext(); }
              else { toast(P.name + ': ' + r.msg, 'bad', 5200); btn.disabled = false; }
            }
          });
        }
        tryNext();
      });
    });

    /* default model select */
    refreshModelSelect();
    /* temperature */
    var temp = q('setTemp');
    temp.value = S.State.settings.temp;
    temp.oninput = function () {
      S.State.settings.temp = +this.value;
      q('setTempVal').textContent = tempLabel(+this.value);
      S.save();
    };
    q('setTempVal').textContent = tempLabel(S.State.settings.temp);
    /* switches */
    bindSwitch('setCite', 'cite'); bindSwitch('setMulti', 'multi');
    bindSwitch('setChar', 'char', function (v) { Character.setEnabled(v); });
    bindSwitch('setHaptic', 'haptic');
    /* profile */
    var me = S.State.settings.me;
    q('setMeName').value = me.name || ''; q('setMeRole').value = me.role || 'خوانده';
    q('setMeNat').value = me.nat || ''; q('setMePhone').value = me.phone || '';
    q('setMeAddr').value = me.addr || '';
    ['setMeName', 'setMeNat', 'setMePhone', 'setMeAddr'].forEach(function (id) {
      q(id).onchange = function () { me[id.replace('setMe', '').toLowerCase()] = this.value.trim(); S.save(true); };
    });
    q('setMeRole').onchange = function () { me.role = this.value; S.save(true); };
    /* storage info */
    var size = 0;
    try { size = JSON.stringify(S.State).length; } catch (e) {}
    if (window.LawsUI) { try { LawsUI.augmentSettings(); } catch (e) { console.warn(e); } }
    q('storeInfo').innerHTML = 'تعداد پرونده‌ها: ' + S.faDigits(S.State.cases.length) +
      ' · مدارک: ' + S.faDigits(S.State.files.length) +
      ' · حجم دادهٔ ذخیره‌شده: ' + S.fmtSize(size) +
      '<br>محل ذخیره: حافظهٔ خصوصی همین برنامه (بدون ارسال به سرور).';
  }
  function tempLabel(v) {
    if (v <= 2) return 'دقیق (' + S.faDigits((v / 10).toFixed(1)) + ')';
    if (v <= 5) return 'متعادل (' + S.faDigits((v / 10).toFixed(1)) + ')';
    return 'خلاق (' + S.faDigits((v / 10).toFixed(1)) + ')';
  }
  function bindSwitch(id, key, cb) {
    var inp = q(id);
    inp.checked = S.State.settings[key] !== false;
    inp.onchange = function () {
      S.State.settings[key] = this.checked; S.save();
      if (cb) cb(this.checked);
      toast(this.checked ? 'فعال شد' : 'غیرفعال شد');
    };
  }
  function refreshModelSelect() {
    var sel = q('setDefaultModel');
    if (!sel) return;
    var models = AI.availableModels();
    var curId = S.State.settings.defaultModel;
    sel.innerHTML = '<option value="">— انتخاب خودکار —</option>' +
      models.map(function (m) {
        return '<option value="' + esc(m.id) + '"' + (m.id === curId ? ' selected' : '') + '>' + esc(m.label) + (m.hasKey ? '' : ' (بدون کلید)') + '</option>';
      }).join('');
    if (!sel.__bound) {
      sel.__bound = true;
      sel.addEventListener('change', function () {
        S.State.settings.defaultModel = this.value; S.save(true);
        updateTitle(cur, curOpts); renderHome();
        toast('مدل پیش‌فرض به‌روزرسانی شد');
      });
    }
  }

  /* ================= data export / import ================= */
  function exportData() {
    var json = JSON.stringify(S.State);
    modal('<h3>' + ico('i-download') + ' پشتیبان‌گیری داده‌ها</h3>' +
      '<p class="card-p">نسخهٔ کامل پرونده‌ها، مدارک، تحلیل‌ها و گفتگوها. متن زیر را کپی و در جای امن نگه‌دارید (حجم: ' + S.fmtSize(json.length) + ').</p>' +
      '<label class="field"><textarea id="expArea" rows="8" style="direction:ltr;text-align:left;font-size:11px">' + esc(json) + '</textarea></label>' +
      '<div class="m-foot"><button class="gold-btn" id="expCopy">' + ico('i-files') + ' کپی همه</button>' +
      '<button class="ghost-btn" id="expClose">بستن</button></div>', { persistent: true });
    var w = modalStack[modalStack.length - 1];
    w.querySelector('#expCopy').addEventListener('click', function () { copyText(json); });
    w.querySelector('#expClose').addEventListener('click', closeModal);
  }
  function importData() {
    modal('<h3>' + ico('i-upload') + ' بازگردانی پشتیبان</h3>' +
      '<p class="card-p">متن پشتیبان (JSON) را در کادر زیر جای‌گذاری کنید. داده‌های فعلی با پشتیبان جایگزین می‌شوند.</p>' +
      '<label class="field"><textarea id="impArea" rows="8" style="direction:ltr;text-align:left;font-size:11px" placeholder="{...}"></textarea></label>' +
      '<div class="m-foot"><button class="gold-btn" id="impGo">' + ico('i-check') + ' بازگردانی</button>' +
      '<button class="ghost-btn" id="impClose">انصراف</button></div>', { persistent: true });
    var w = modalStack[modalStack.length - 1];
    w.querySelector('#impClose').addEventListener('click', closeModal);
    w.querySelector('#impGo').addEventListener('click', function () {
      var t = w.querySelector('#impArea').value.trim();
      try {
        var obj = JSON.parse(t);
        if (!obj || typeof obj !== 'object') throw new Error('bad');
        Object.keys(S.State).forEach(function (k) { delete S.State[k]; });
        Object.keys(S.DEFAULT_STATE).forEach(function (k) { S.State[k] = JSON.parse(JSON.stringify(S.DEFAULT_STATE[k])); });
        Object.keys(obj).forEach(function (k) { S.State[k] = obj[k]; });
        S.save(true); closeModal();
        toast('داده‌ها بازگردانی شد', 'ok');
        renderSettings(); renderHome(); updateTitle(cur, curOpts);
        Character.say('پشتیبان بارگذاری شد؛ پرونده‌ها و مدارک بازیابی شدند.', { mood: 'happy' });
      } catch (e) { toast('متن پشتیبان معتبر نیست', 'bad'); }
    });
  }
  function wipe() {
    modal('<h3>' + ico('i-alert') + ' پاک‌سازی همه داده‌ها</h3><p class="card-p">تمام پرونده‌ها، مدارک، گفتگوها و کلیدهای API حذف می‌شوند. این کار بازگشت‌پذیر نیست.</p>' +
      '<div class="m-foot"><button class="danger-btn" id="wYes">بله، همه را پاک کن</button><button class="ghost-btn" id="wNo">انصراف</button></div>', { persistent: true });
    var w = modalStack[modalStack.length - 1];
    w.querySelector('#wNo').addEventListener('click', closeModal);
    w.querySelector('#wYes').addEventListener('click', function () {
      try { localStorage.removeItem('vakil_state_v1'); } catch (e) {}
      if (window.VakilNative && window.VakilNative.nativeStore && window.VakilNative.nativeStore()) window.VakilNative.save('{}');
      S.load(); S.State.activeCaseId = null; S.State.cases = []; S.State.files = []; S.State.sessions = {};
      S.save(true); closeModal(); toast('همه داده‌ها پاک شد', 'ok');
      renderSettings(); renderHome(); go('home', { replace: true });
    });
  }

  /* ================= init bindings ================= */
  function bind() {
    /* dock */
    $$('#dock .dock-btn').forEach(function (b) {
      b.addEventListener('click', function () {
        var v = b.getAttribute('data-view');
        if (v === 'cases') stack = [];
        go(v);
      });
    });
    q('btnBack').addEventListener('click', back);
    q('caseSearch').addEventListener('input', renderCases);
    q('btnNewCase').addEventListener('click', function () { openCaseForm(null); });
    q('caseTabs').addEventListener('click', function (e) {
      var t = e.target.closest('.tab'); if (!t) return;
      caseTab = t.getAttribute('data-ct'); renderCase(S.State.activeCaseId);
    });
    /* home hero actions */
    $$('.hero-actions .chip-btn').forEach(function (b) {
      b.addEventListener('click', function () {
        var a = b.getAttribute('data-act');
        var c = S.activeCase();
        if (a === 'ask') { q('chatText').focus(); Character.say('بفرمایید، پرسش حقوقی‌تان چیست؟ دقیق بپرسید تا دقیق پاسخ بدهم.', { mood: 'listen' }); }
        if (a === 'analyze') {
          selFileIds = c ? S.filesOf(c.id).map(function (f) { return f.id; }) : [];
          go('doc'); Character.say('شرح موضوع را بنویسید یا مدارک را پیوست کنید تا تحلیل کامل بدهم.', { mood: 'think' });
        }
        if (a === 'attach') { pickAndAttach(c ? c.id : null); }
        if (a === 'draft') { go('draft'); Character.say('چه سندی بنویسم؟ لایحه، اظهارنامه، دادخواست یا قرارداد؟', { mood: 'smile' }); }
      });
    });
    /* home tiles */
    $$('#homeTiles .tile').forEach(function (t) {
      t.addEventListener('click', function () {
        var mode = t.getAttribute('data-mode');
        var dst = t.getAttribute('data-go');
        if (dst === 'laws') {
          go('laws');
          Character.say('بانک قوانین باز شد؛ می‌توانید در متن رسمی مواد جست‌وجو کنید و هر ماده را به تحلیل اضافه کنید.', { mood: 'smile' });
          return;
        }
        if (dst === 'draft') { go('draft', { type: t.getAttribute('data-type') || 'lawyer' }); return; }
        docMode = (mode && L.MODES[mode]) ? mode : 'auto';
        var c = S.activeCase();
        selFileIds = c ? S.filesOf(c.id).map(function (f) { return f.id; }) : [];
        go('doc');
        Character.say('حوزهٔ ' + (L.MODES[docMode] ? L.MODES[docMode].label : 'حقوقی') + ' انتخاب شد؛ موضوع را بنویسید.', { mood: 'smile' });
      });
    });
    /* chat */
    q('chatSend').addEventListener('click', function () { sendChat(); });
    q('chatAttach').addEventListener('click', function () { pickAndAttach(S.State.activeCaseId); });
    q('chatText').addEventListener('keydown', function (e) {
      if (e.key === 'Enter' && !e.shiftKey) { e.preventDefault(); sendChat(); }
    });
    q('chatText').addEventListener('input', function () {
      this.style.height = 'auto';
      this.style.height = Math.min(132, this.scrollHeight) + 'px';
      Character.lookDown();
    });
    q('chatMic').addEventListener('click', voiceInput);
    /* analyze */
    q('modeSeg').addEventListener('click', function (e) {
      var b = e.target.closest('.seg-btn'); if (!b) return;
      docMode = b.getAttribute('data-mode'); renderAnalyze();
      Character.say(L.MODES[docMode].label + ': ' + L.MODES[docMode].hint, { mood: 'smile' });
    });
    q('docRun').addEventListener('click', runAnalysis);
    q('docAttachBtn').addEventListener('click', function () {
      var before = S.State.files.length;
      var p = pickAndAttach(S.State.activeCaseId);
      var iv = setInterval(function () {
        if (S.State.files.length > before) {
          S.State.files.slice(before).forEach(function (f) { if (selFileIds.indexOf(f.id) < 0) selFileIds.push(f.id); });
          renderAnalyze(); clearInterval(iv);
        }
      }, 600);
      setTimeout(function () { clearInterval(iv); }, 60000);
      return p;
    });
    q('docVoice').addEventListener('click', voiceInput);
    /* draft */
    q('draftRun').addEventListener('click', runDraft);
    /* settings */
    if (window.LawsUI) { try { LawsUI.watchVisibility(); } catch (e) {} }
    q('btnExport').addEventListener('click', exportData);
    q('btnImportBtn').addEventListener('click', importData);
    q('btnWipe').addEventListener('click', wipe);
  }

  function voiceInput() {
    var SR = window.SpeechRecognition || window.webkitSpeechRecognition;
    if (!SR) {
      toast('ورودی صوتی در این دستگاه پشتیبانی نمی‌شود', 'bad', 4000);
      Character.say('ورودی صوتی روی این دستگاه فعال نیست؛ لطفاً متن را تایپ کنید.', { mood: 'concerned' });
      return;
    }
    try {
      var r = new SR();
      r.lang = 'fa-IR'; r.continuous = false; r.interimResults = false;
      toast('در حال شنیدن... صحبت کنید', 'ok');
      Character.say('می‌شنوم؛ بفرمایید.', { mood: 'listen' });
      r.onresult = function (ev) {
        var txt = ev.results[0][0].transcript;
        var ta = (cur === 'doc') ? q('docText') : q('chatText');
        ta.value = (ta.value ? ta.value + ' ' : '') + txt;
        toast('متن تبدیل شد', 'ok');
        if (cur === 'home') sendChat();
      };
      r.onerror = function () { toast('شنیدن ناموفق بود', 'bad'); };
      r.start();
    } catch (e) { toast('ورودی صوتی در دسترس نیست', 'bad'); }
  }

  window.Pages = {
    bind: bind, go: go, back: back, toast: toast, modal: modal, closeModal: closeModal,
    copyText: copyText, __lastModal: function () { return modalStack[modalStack.length - 1]; },
    sheet: sheet, closeSheet: closeSheet, renderHome: renderHome, renderCases: renderCases,
    renderCase: renderCase, renderAnalyze: renderAnalyze, renderDraft: renderDraft, renderSettings: renderSettings,
    updateTitle: updateTitle, sendChat: sendChat, pickAndAttach: pickAndAttach, openCaseForm: openCaseForm
  };
})();
