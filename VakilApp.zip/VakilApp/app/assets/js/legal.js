/* ============ Vakil AI — Legal knowledge, agents & prompts (قوانین ایران) ============ */
(function () {
  'use strict';

  var SHARED_RULES = [
    'شما «وکیل هوشمند» هستید؛ یک تیم حقوقی بسیار حرفه‌ای، مسلط بر قوانین جمهوری اسلامی ایران.',
    'مراجع اصلی: قانون مدنی، قانون آیین دادرسی مدنی، قانون مجازات اسلامی (۱۳۹۲)، قانون آیین دادرسی کیفری (۱۳۹۲)،',
    'قانون حمایت خانواده (۱۳۹۱) و آیین‌نامه آن، قانون کار، قانون روابط موجر و مستأجر، قانون تجارت و قانون صدور چک،',
    'قانون ثبت اسناد و املاک، قانون اجرای احکام مدنی، قانون تشکیلات و آیین دادرسی دیوان عدالت اداری، قانون حمایت از حقوق مصرف‌کنندگان.',
    '',
    'اصول پاسخ‌دهی:',
    '۱) دقیق، اصولی و کاربردی بنویس؛ از کلی‌گویی پرهیز کن.',
    '۲) در هر ادعای حقوقی، ماده قانونی و نام قانون را ذکر کن (مثال: «ماده ۱۰ قانون مدنی»). اگر شمارهٔ ماده را مطمئن نیستی،',
    '   صریح بنویس «نیازمند بررسی متن دقیق ماده» و از جعل شماره ماده یا رأی وحدت رویه خودداری کن.',
    '۳) ساختار استاندارد: خلاصهٔ پرونده ← ارزیابی ادله ← تحلیل حقوقی ← دفاعیات طرف مقابل ← راهکار و اقدامات کاربردی ← ریسک‌ها و مهلت‌ها.',
    '۴) در انتها یک بخش با عنوان «پرسش‌های تکمیلی» بگذار که اطلاعات ناقص را بپرسد تا تحلیل دقیق‌تر شود.',
    '۵) لحن: حرفه‌ای، محترمانه، قاطع و آرام. مخاطب را «شما» خطاب کن. از طعنه، ترساندن، وعده نتیجه قطعی و زبان غیرحقوقی پرهیز کن.',
    '۶) هیچ‌گاه نگو که وکیل پایه‌یک دادگستری هستی و هیچ پرونده‌ای را در دادگاه قبول نکن؛ تو مشاور و کمک‌کار حقوقی هستی.',
    '۷) اگر موضوع خارج از چارچوب حقوقی است، مؤدبانه به مسیر حقوقی مرتبط هدایت کن.',
    '۸) زبان پاسخ فارسی روان و حقوقی-محاوره‌ای متعادل باشد؛ اصطلاحات تخصصی را داخل پرانتز ساده کن.',
    '۹) تاریخ‌ها شمسی نوشته شوند. مهلت‌ها و مواعد قانونی (مثل مهلت تجدیدنظر ۲۰ روزه، مهلت اعتراض به رأی غیابی، مواعد قانون کار) را',
    '   با ذکر مبنای قانونی و هشدار اهمیت بیان کن.',
    '۱۰) فرمت خروجی: مارک‌داون با تیترهای «##»، بولت و جدول در صورت لزوم. حداکثر حدود ۹۰۰ کلمه مگر آن‌که خواسته شود.'
  ].join('\n');

  var AGENTS = [
    {
      id: 'coordinator', name: 'سرپرست پرونده', sub: 'راهبری و تحلیل جامع', icon: 'i-scale', color: 'linear-gradient(150deg,#e8c97c,#a2741f)',
      domains: ['general', 'rights', 'criminal', 'family', 'contract'],
      system: SHARED_RULES + '\n\nنقش اختصاصی: مدیر پروژهٔ حقوقی پرونده. ابتدا موضوع را دسته‌بندی می‌کنی (حقوقی/کیفری/خانواده/قرارداد/اداری/کار)،',
      style: 'جامع، اولویت‌بندی‌شده، اقدام‌محور'
    },
    {
      id: 'civil', name: 'متخصص حقوقی-مدنی', sub: 'دعاوی مدنی، ملکی، تعهدات', icon: 'i-books', color: 'linear-gradient(150deg,#ffcf8a,#8a4a12)',
      domains: ['rights'],
      system: SHARED_RULES + '\n\nنقش اختصاصی: متخصص دعاوی حقوقی و مدنی؛ روابط مالک و مستأجر، الزام به تنظیم سند، خلع ید، تصرف عدوانی، مطالبه وجه، خسارت،',
      style: 'دقیق در مواد قانون مدنی و آیین دادرسی مدنی'
    },
    {
      id: 'criminal', name: 'متخصص کیفری', sub: 'دفاعیه، تعقیب، دیه', icon: 'i-cuffs', color: 'linear-gradient(150deg,#ff8f9c,#8e2135)',
      domains: ['criminal'],
      system: SHARED_RULES + '\n\nنقش اختصاصی: متخصص امور کیفری؛ تحلیل عناصر سه‌گانهٔ جرم، شروع به جرم، شرکت و معاونت، کیفیات مخففه و مشدده،',
      style: 'دفاعی-تحلیلی با ذکر مواد قانون مجازات اسلامی'
    },
    {
      id: 'family', name: 'متخصص خانواده', sub: 'طلاق، مهریه، نفقه، حضانت', icon: 'i-family', color: 'linear-gradient(150deg,#8fd8ff,#1d5f9e)',
      domains: ['family'],
      system: SHARED_RULES + '\n\nنقش اختصاصی: متخصص دعاوی خانواده؛ طلاق توافقی و یک‌طرفه، مهریه (تعدیل/اعسار)، نفقه، حضانت و ملاقات فرزند، اجرت‌المثل،',
      style: 'همدل، دقیق، با ملاحظه مصالح فرزند'
    },
    {
      id: 'contractor', name: 'متخصص قراردادها', sub: 'تنظیم، بازبینی، ریسک‌سنجی', icon: 'i-contract', color: 'linear-gradient(150deg,#8cf0c8,#0f6b52)',
      domains: ['contract'],
      system: SHARED_RULES + '\n\nنقش اختصاصی: متخصص قراردادها؛ بررسی شروط صحت، شرایط اساسی معامله، شروط ضمن عقد، شرط جزایی، فورس‌ماژور،',
      style: 'ریسک‌محور با پیشنهاد بندهای اصلاحی'
    },
    {
      id: 'evidence', name: 'کارشناس اسناد', sub: 'ارزیابی ادله و مدارک', icon: 'i-files', color: 'linear-gradient(150deg,#c3a6ff,#4a2b96)',
      domains: ['general', 'rights', 'criminal', 'family', 'contract'],
      system: SHARED_RULES + '\n\nنقش اختصاصی: کارشناس ارزیابی اسناد و ادله؛ سند رسمی/عادی، شهادت، اقرار، سوگند، اماره، نظر کارشناس،',
      style: 'ارزیابی قوت اثباتی هر مدرک با امتیاز تحلیلی'
    }
  ];

  var MODES = {
    auto:     { label: 'تشخیص خودکار', emoji: '🎯', hint: 'موضوع به‌صورت خودکار دسته‌بندی و به متخصص‌های مرتبط ارجاع می‌شود.' },
    rights:   { label: 'حقوقی', emoji: '⚖️', hint: 'دعاوی مدنی، ملکی، تعهدات، مطالبه وجه و الزام به تنظیم سند.' },
    criminal: { label: 'کیفری', emoji: '🛡️', hint: 'تحلیل جرم، دفاعیه، شکایت، گذشت و آثار آن.' },
    family:   { label: 'خانواده', emoji: '🏡', hint: 'طلاق، مهریه، نفقه، حضانت و اموال مشترک.' },
    contract: { label: 'قرارداد', emoji: '📜', hint: 'تنظیم و بازبینی قرارداد و ریسک‌سنجی.' },
    general:  { label: 'عمومی', emoji: '📚', hint: 'پرسش‌های عمومی حقوقی و استعلام قانون.' }
  };

  function caseBrief(c) {
    if (!c) return 'پروندهٔ فعالی انتخاب نشده است.';
    var L = [];
    L.push('عنوان پرونده: ' + (c.title || '—'));
    if (c.caseNo) L.push('شماره پرونده/کلاسه: ' + c.caseNo);
    if (c.court) L.push('دادگاه/مرجع: ' + c.court + (c.branch ? ' — شعبه ' + c.branch : ''));
    L.push('نوع پرونده: ' + (c.type || '—'));
    L.push('نقش موکل (کاربر): ' + (c.myRole || '—'));
    if (c.opponent) L.push('طرف مقابل: ' + c.opponent);
    if (c.subject) L.push('موضوع: ' + c.subject);
    if (c.status) L.push('وضعیت: ' + c.status);
    if (c.nextDate) L.push('اقدام/جلسهٔ بعدی: ' + c.nextDate);
    if (c.notes) L.push('یادداشت‌ها: ' + c.notes);
    return L.join('\n');
  }

  /* حافظهٔ پرونده: تحلیل‌ها، نگارش‌ها و گفتگوهای قبلی تا هوش مصنوعی همه را مرور کند */
  function caseMemory(c) {
    if (!c) return 'حافظهٔ پرونده: خالی.';
    var L = [];
    var an = (c.analysis || []);
    if (an.length) {
      var last = an[an.length - 1];
      L.push('—— آخرین تحلیل ثبت‌شده (' + (last.title || '') + ') ——');
      L.push(String(last.text).slice(0, 1600));
      if (an.length > 1) L.push('(تعداد کل تحلیل‌های ثبت‌شده: ' + an.length + ')');
    }
    var dr = (c.drafts || []);
    if (dr.length) {
      L.push('—— اسناد و نگارش‌های پرونده ——');
      dr.slice(-3).forEach(function (d) {
        L.push('• ' + (d.typeName || d.type) + ' — ' + (d.title || ''));
      });
      var lastD = dr[dr.length - 1];
      L.push('آخرین سند (بخش ابتدایی): ' + String(lastD.text).slice(0, 700));
    }
    var ch = (c.chat || []).slice(-6);
    if (ch.length) {
      L.push('—— بخشی از گفتگوهای قبلی ——');
      ch.forEach(function (m) {
        L.push((m.role === 'user' ? 'کاربر: ' : 'دستیار: ') + String(m.content).slice(0, 260));
      });
    }
    return L.length ? L.join('\n') : 'حافظهٔ پرونده: فقط اطلاعات شناسنامه در دسترس است.';
  }

  /* استناد از بانک قوانین محلی (RAG) — موادی که واقعاً در برنامه موجودند */
  function ragBlock(query, domain, caseObj) {
    try {
      if (!window.Knowledge) return '';
      var q = [query || '', caseObj ? ((caseObj.subject || '') + ' ' + (caseObj.type || '') + ' ' + (caseObj.notes || '')) : ''].join(' ');
      var dom = (domain && domain !== 'auto') ? domain : (window.AI && window.AI.classify ? window.AI.classify(q) : null);
      if (dom === 'general') dom = null;
      var blk = window.Knowledge.citeBlock(q, dom, 8);
      if (!blk) blk = window.Knowledge.citeBlock(q, null, 6);
      return blk || '';
    } catch (e) { return ''; }
  }

  function docsBlock(files) {
    if (!files || !files.length) return 'سند/مدرکی پیوست نشده است.';
    var txt = window.Store.docsDigest(files);
    return 'مدارک پیوست‌شده (به ترتیب):\n' + txt;
  }

  function meBlock() {
    var me = window.Store.State.settings.me || {};
    var L = [];
    if (me.name) L.push('نام کاربر: ' + me.name);
    if (me.role) L.push('نقش: ' + me.role);
    if (me.nat) L.push('کد ملی: ' + me.nat);
    if (me.phone) L.push('تلفن: ' + me.phone);
    if (me.addr) L.push('نشانی: ' + me.addr);
    return L.length ? L.join('\n') : 'مشخصات کاربر ثبت نشده است.';
  }

  /* --------- تحلیل کامل پرونده --------- */
  function analysisPrompt(mode, userText, caseObj, files) {
    var sys = [
      SHARED_RULES, '',
      'قالب خروجی تحلیل پرونده (الزامی، با همین تیترها):',
      '## ۱. خلاصهٔ پرونده و طرفین',
      '## ۲. ارزیابی ادله و مدارک',
      '## ۳. تحلیل حقوقی و مواد قانونی مرتبط',
      '## ۴. دفاعیات احتمالی طرف مقابل و پاسخ آنها',
      '## ۵. راهکارهای اصولی و گام‌به‌گام (اولویت‌دار)',
      '## ۶. ریسک‌ها، مهلت‌ها و هشدارهای مهم',
      '## ۷. پرسش‌های تکمیلی برای دقت بیشتر',
      '',
      'در بخش ادله، برای هر مدرک بنویس: نوع، اعتبار اثباتی، نقاط قوت و ضعف و چگونگی تقویت آن.',
      'در بخش راهکارها، بین «مسیر مذاکره/سازش»، «مسیر رسمی قضایی» و «مسیر احتیاطی» تفکیک کن.',
      'در پایان، اگر نیاز به سند یا اطلاعات بیشتری هست، دقیق بگو کدام سند و چرا.'
    ].join('\n');

    var usr = [
      'موضوع/شرح ارائه‌شده توسط کاربر:',
      userText || '(شرح متنی ارائه نشده؛ صرفاً بر اساس پرونده و مدارک تحلیل کن.)',
      '',
      'اطلاعات پرونده:', caseBrief(caseObj), '',
      'حافظهٔ پرونده (پیشینهٔ ثبت‌شده — همه بخش‌ها را در تحلیل لحاظ کن):', caseMemory(caseObj), '',
      'مشخصات کاربر:', meBlock(), '',
      docsBlock(files), '',
      ragBlock(userText, mode, caseObj), '',
      'حوزهٔ تحلیل: ' + (MODES[mode] ? MODES[mode].label : mode),
      'لطفاً تحلیل کامل، اصولی و کاربردی ارائه بده و در انتها فهرست اقدامات فوری (۲۴ تا ۷۲ ساعت آینده) را جدا کن.'
    ].join('\n');

    return { system: sys, user: usr };
  }

  /* --------- سندسازی فوری روی مدارک --------- */
  function evidencePrompt(files, caseObj, question) {
    var sys = [
      SHARED_RULES, '',
      'نقش فوری: کارشناس بررسی اسناد. اسناد پیوست‌شده را بخوان، محتوای هر سند را در یک بند خلاصه کن،',
      'سپس ارتباط هر سند با موضوع، نقاط قوت/ضعف اثباتی و نکات قابل بهره‌برداری را فهرست کن.',
      'اگر بین اسناد تناقض یا کمبود هست، صریح بگو.'
    ].join('\n');
    var usr = ['پرسش کاربر: ' + (question || 'این اسناد را بررسی و ارزیابی کن.'), '',
      'پرونده:', caseBrief(caseObj), '', docsBlock(files)].join('\n');
    return { system: sys, user: usr };
  }

  /* --------- انواع نگارش حقوقی --------- */
  var DRAFT_TYPES = [
    { id: 'lawyer',      name: 'لایحه دفاعیه',   icon: 'i-pen',      desc: 'لایحه تقدیمی به دادگاه' },
    { id: 'ezharname',   name: 'اظهارنامه',      icon: 'i-seal',     desc: 'اظهارنامه رسمی مطالبه/اخطار' },
    { id: 'petition',    name: 'دادخواست',       icon: 'i-files',    desc: 'دادخواست حقوقی/خانواده' },
    { id: 'complaint',   name: 'شکواییه',        icon: 'i-flag',     desc: 'شکواییه کیفری و کلانتری' },
    { id: 'statement',   name: 'صورت‌جلسهٔ اظهارات', icon: 'i-quote', desc: 'اظهارات و دفاعیه شفاهی' },
    { id: 'contract',    name: 'قرارداد',        icon: 'i-contract', desc: 'تنظیم قرارداد با بندهای دقیق' },
    { id: 'notice',      name: 'اخطار قانونی',   icon: 'i-alert',    desc: 'اخطار و مهلت‌دهی پیش از اقدام' },
    { id: 'appeal',      name: 'تجدیدنظرخواهی',  icon: 'i-layer',    desc: 'لایحه اعتراض به رأی' },
    { id: 'power',       name: 'وکالت‌نامه',      icon: 'i-handshake', desc: 'متن وکالت‌نامه' },
    { id: 'custom',      name: 'سند سفارشی',     icon: 'i-bolt',     desc: 'هر متن حقوقی دیگر' }
  ];

  var DRAFT_SPEC = {
    lawyer: {
      fields: [
        { k: 'court', label: 'مرجع رسیدگی (دادگاه/شعبه)', ph: 'دادگاه عمومی حقوقی تهران — شعبه ۱۲' },
        { k: 'caseNo', label: 'کلاسه پرونده', ph: '۰۰۱۲۳۴۵۶۷۸۹۰۰' },
        { k: 'me', label: 'مشخصات متنوع‌عنه (شما/موکل)', ph: 'نام و نام خانوادگی، فرزند، کد ملی' },
        { k: 'who', label: 'مشخصات خواهان/شاکی', ph: 'نام طرف مقابل' },
        { k: 'core', label: 'موضوع/خواسته یا محور دفاع', ph: 'خلاصه دعوا و آنچه دفاع می‌کنید' },
        { k: 'args', label: 'دلایل و مستندات', ph: 'شماره سند، شهادت شهود، نظر کارشناس...' }
      ]
    },
    ezharname: {
      fields: [
        { k: 'me', label: 'مشخصات اظهارکننده', ph: 'نام، نام پدر، کد ملی، نشانی' },
        { k: 'who', label: 'مشخصات مخاطب', ph: 'نام و نشانی مخاطب' },
        { k: 'core', label: 'موضوع اظهارنامه', ph: 'مثال: مطالبه وجه چک به شماره ...' },
        { k: 'amount', label: 'مبلغ/خواسته (در صورت وجود)', ph: 'مثال: ۲۵۰٫۰۰۰٫۰۰۰ ریال' }
      ]
    },
    petition: {
      fields: [
        { k: 'court', label: 'مرجع صالح', ph: 'دادگاه عمومی حقوقی/خانواده ...' },
        { k: 'me', label: 'خواهان', ph: 'نام، کد ملی، نشانی' },
        { k: 'who', label: 'خوانده', ph: 'نام، نشانی' },
        { k: 'core', label: 'خواسته و بهای آن', ph: 'مثال: الزام به تنظیم سند رسمی + خسارات' },
        { k: 'args', label: 'دلایل', ph: 'سند عادی، شهادت...' }
      ]
    },
    complaint: {
      fields: [
        { k: 'me', label: 'شاکی', ph: 'نام، کد ملی، نشانی' },
        { k: 'who', label: 'مشتکی‌عنه', ph: 'نام/نشانی یا ناشناس' },
        { k: 'core', label: 'موضوع شکایت و شرح ماوقع', ph: 'چه اتفاقی افتاد، چه زمانی، چه کسی' },
        { k: 'args', label: 'دلایل و شهود', ph: 'فیلم، پیام، شهادت...' }
      ]
    },
    statement: {
      fields: [
        { k: 'court', label: 'دادگاه/مرجع', ph: '...' },
        { k: 'caseNo', label: 'کلاسه پرونده', ph: '...' },
        { k: 'me', label: 'گفتارگو', ph: 'نام شما' },
        { k: 'core', label: 'محور اظهارات', ph: 'چه می‌خواهید بیان کنید' }
      ]
    },
    contract: {
      fields: [
        { k: 'parties', label: 'طرفین قرارداد', ph: 'آقای/خانم ... و ...' },
        { k: 'core', label: 'موضوع و تعهدات', ph: 'موضوع معامله/خدمت، مبلغ، زمان‌بندی' },
        { k: 'amount', label: 'مبلغ و شرایط پرداخت', ph: '...' },
        { k: 'duration', label: 'مدت قرارداد', ph: 'مثال: از تاریخ ... به مدت یک سال' },
        { k: 'extra', label: 'شروط مورد نظر', ph: 'شرط جزایی، فسخ، محرمانگی...' }
      ]
    },
    notice: {
      fields: [
        { k: 'me', label: 'فرستنده', ph: 'نام شما' },
        { k: 'who', label: 'مخاطب', ph: 'نام طرف مقابل' },
        { k: 'core', label: 'موضوع اخطار', ph: 'مثال: تخلیه ملک تا پایان ماه' },
        { k: 'duration', label: 'مهلت تعیین‌شده', ph: 'مثال: ۱۰ روز از تاریخ ابلاغ' }
      ]
    },
    appeal: {
      fields: [
        { k: 'court', label: 'دادگاه صادرکننده رأی و شعبه', ph: '...' },
        { k: 'caseNo', label: 'کلاسه پرونده بدوی', ph: '...' },
        { k: 'me', label: 'تجدیدنظرخواه', ph: 'نام شما' },
        { k: 'who', label: 'تجدیدنظرخوانده', ph: 'نام طرف مقابل' },
        { k: 'core', label: 'جهات اعتراض', ph: 'نقص رسیدگی، عدم رعایت مواد قانونی...' }
      ]
    },
    power: {
      fields: [
        { k: 'me', label: 'موکل', ph: 'نام، کد ملی، نشانی' },
        { k: 'who', label: 'وکیل', ph: 'نام وکیل و شماره پروانه' },
        { k: 'core', label: 'موضوع وکالت', ph: 'رسیدگی به پرونده کلاسه ...' },
        { k: 'duration', label: 'مدت وکالت', ph: 'مثال: تا خاتمه دادرسی' }
      ]
    },
    custom: {
      fields: [
        { k: 'core', label: 'شرح درخواست', ph: 'چه سندی می‌خواهید؟ (مثال: اظهارنامه تخلیه) ' },
        { k: 'extra', label: 'جزئیات و اطلاعات لازم', ph: 'هر اطلاعاتی که باید در سند بیاید' }
      ]
    }
  };

  function draftPrompt(typeId, values, caseObj, files) {
    var T = DRAFT_TYPES.filter(function (t) { return t.id === typeId; })[0] || DRAFT_TYPES[0];
    var sys = [
      SHARED_RULES, '',
      'نقش: تنظیم‌کنندهٔ اسناد حقوقی با سبک قضایی رسمی و صحیح آیین‌ دادرسی ایران.',
      'خروجی باید دقیقاً یک متن آمادهٔ ارائه به مرجع باشد؛ بدون توضیح اضافه، بدون مقدمه چت‌مانند.',
      'ساختار لازم:',
      '• «بسمه تعالی» در ابتدا',
      '• عنوان سند (مثلاً: لایحه دفاعیه / اظهارنامه / دادخواست)',
      '• مشخصات مرجع و کلاسه',
      '• مشخصات متنوع‌عنه/خواهان/خوانده بر اساس نوع سند',
      '• متن اصلی با شماره‌گذاری بندها (۱-، ۲- ...) و ذکر مواد قانونی',
      '• «با عنایت به مراتب فوق، رسیدگی و صدور حکم بر ... مورد استدعاست.»',
      '• محل امضا و تاریخ شمسی (جای خالی: «امضا و اثر انگشت»)',
      'در انتها یک بخش جداگانه با تیتر «## نکات تکمیلی و هشدارها» بده (نکات مربوط به تقدیم، مهلت‌ها، تمبر، هزینه).',
      'اطلاعات نامعلوم را با «...» یا «[تکمیل شود]» بگذار و از جعل اطلاعات خودداری کن.'
    ].join('\n');

    var vs = Object.keys(values || {}).filter(function (k) { return String(values[k] || '').trim(); })
      .map(function (k) { var f = (DRAFT_SPEC[typeId] && DRAFT_SPEC[typeId].fields || []).filter(function (x) { return x.k === k; })[0];
        return (f ? f.label : k) + ': ' + values[k]; }).join('\n');

    var usr = [
      'نوع سند: ' + T.name + ' (' + T.desc + ')',
      '', 'اطلاعات داده‌شده:', vs || '(اطلاعات تکمیلی وارد نشده)', '',
      'پروندهٔ مرتبط:', caseBrief(caseObj), '',
      'مشخصات کاربر:', meBlock(), '',
      files && files.length ? docsBlock(files) : 'مدرکی پیوست نشده است.', '',
      ragBlock(vs + ' ' + (caseObj ? (caseObj.subject || '') : ''), caseObj && caseObj.type === 'خانواده' ? 'family' : null, caseObj)
    ].join('\n');

    return { system: sys, user: usr, typeName: T.name };
  }

  /* --------- گفتگوی آزاد با متخصص --------- */
  function chatPrompt(agentId, history, caseObj, files, extraNote, query, domain) {
    var ag = AGENTS.filter(function (a) { return a.id === agentId; })[0] || AGENTS[0];
    var sys = [ag.system, '', '—— زمینهٔ پرونده ——', caseBrief(caseObj), '',
      '—— پیشینهٔ پرونده (از قبل ثبت شده) ——', caseMemory(caseObj), '',
      'مشخصات کاربر:', meBlock(), ''];
    if (files && files.length) sys.push(docsBlock(files), '');
    var rag = ragBlock(query || (history && history.length ? history[history.length - 1].content : ''), domain, caseObj);
    if (rag) sys.push(rag, '');
    sys.push('پاسخ‌ها را محاوره‌ای اما حقوقی، کوتاه‌تر از تحلیل‌های کامل (حدود ۲۵۰ کلمه) و همیشه با ذکر ماده قانونی بنویس.');
    if (extraNote) sys.push('', extraNote);

    var msgs = (history || []).slice(-14).map(function (m) {
      return { role: m.role === 'user' ? 'user' : 'assistant', content: m.content };
    });
    return { system: sys.join('\n'), messages: msgs, agent: ag };
  }

  window.Legal = {
    SHARED_RULES: SHARED_RULES,
    AGENTS: AGENTS, MODES: MODES,
    DRAFT_TYPES: DRAFT_TYPES, DRAFT_SPEC: DRAFT_SPEC,
    caseBrief: caseBrief, caseMemory: caseMemory, docsBlock: docsBlock, meBlock: meBlock,
    analysisPrompt: analysisPrompt, evidencePrompt: evidencePrompt,
    draftPrompt: draftPrompt, chatPrompt: chatPrompt
  };
})();
