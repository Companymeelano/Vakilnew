/* ================= Vakil AI — Store & Persistence =================
   ذخیره‌سازی دائمی: در نسخه اندروید از پل بومی (فایل خصوصی اپ) و در
   مرورگر از localStorage استفاده می‌شود. داده‌ها بین اجراها حفظ می‌شوند. */
(function () {
  'use strict';

  var NATIVE = (typeof window.VakilNative !== 'undefined') ? window.VakilNative : null;
  var LS_KEY = 'vakil_state_v1';

  var DEFAULT_STATE = {
    version: 1,
    cases: [],
    files: [],
    activeCaseId: null,
    sessions: {},
    settings: {
      providers: {
        openai:     { key: '' },
        anthropic:  { key: '' },
        gemini:     { key: '' },
        groq:       { key: '' },
        openrouter: { key: '' },
        deepseek:   { key: '' },
        custom:     { key: '', base: '', model: '' }
      },
      defaultModel: '',
      allowedModels: [],
      temp: 3,
      cite: true,
      multi: true,
      char: true,
      haptic: true,
      theme: 'midnight',
      fontScale: 100,
      fx: true,
      voice: false,
      voiceRate: 9,
      clipClear: false,
      lock: { enabled: false, hash: '' },
      me: { name: '', role: 'خوانده', nat: '', phone: '', addr: '' }
    },
    lawImports: [],
    chat: []
  };

  function deepMerge(base, extra) {
    if (!extra || typeof extra !== 'object') return base;
    Object.keys(extra).forEach(function (k) {
      if (extra[k] && typeof extra[k] === 'object' && !Array.isArray(extra[k]) && base[k] && typeof base[k] === 'object') {
        deepMerge(base[k], extra[k]);
      } else base[k] = extra[k];
    });
    return base;
  }

  var State = deepMerge(JSON.parse(JSON.stringify(DEFAULT_STATE)), {});

  /* ---------- load ---------- */
  function load() {
    try {
      var raw = null;
      if (NATIVE && NATIVE.nativeStore && NATIVE.nativeStore()) raw = NATIVE.load();
      if (!raw) raw = localStorage.getItem(LS_KEY);
      if (raw) {
        var parsed = JSON.parse(raw);
        /* مهم: به‌جای جایگزینی مرجع، آبجکت موجود را در جا پر می‌کنیم
           تا همهٔ ماژول‌ها (که به window.Store.State اشاره دارند) دادهٔ بازیابی‌شده را ببینند. */
        Object.keys(State).forEach(function (k) { delete State[k]; });
        var fresh = deepMerge(JSON.parse(JSON.stringify(DEFAULT_STATE)), {});
        Object.keys(fresh).forEach(function (k) { State[k] = fresh[k]; });
        deepMerge(State, parsed);
      }
    } catch (e) { console.warn('load failed', e); }
    return State;
  }

  var saveTimer = null, saving = false;
  function save(now) {
    if (saveTimer) clearTimeout(saveTimer);
    var doIt = function () {
      saving = true;
      try {
        var json = JSON.stringify(State);
        if (NATIVE && NATIVE.nativeStore && NATIVE.nativeStore()) NATIVE.save(json);
        try { localStorage.setItem(LS_KEY, json); } catch (e) {}
      } catch (e) { console.warn('save failed', e); }
      saving = false;
    };
    if (now) doIt(); else saveTimer = setTimeout(doIt, 320);
  }

  /* ---------- utils ---------- */
  var uidSeq = 0;
  function uid(p) { uidSeq++; return (p || 'id') + '_' + Date.now().toString(36) + '_' + uidSeq.toString(36); }
  function clone(o) { return JSON.parse(JSON.stringify(o)); }
  function faDigits(s) {
    return String(s == null ? '' : s).replace(/[0-9]/g, function (d) { return '۰۱۲۳۴۵۶۷۸۹'[+d]; });
  }
  function fmtSize(b) {
    if (!b && b !== 0) return '—';
    if (b < 1024) return faDigits(b) + ' بایت';
    if (b < 1048576) return faDigits((b / 1024).toFixed(1)) + ' کیلوبایت';
    return faDigits((b / 1048576).toFixed(2)) + ' مگابایت';
  }
  function pdate(d) { // میلادی → شمسی
    d = d ? new Date(d) : new Date();
    var gy = d.getFullYear(), gm = d.getMonth() + 1, gd = d.getDate();
    var g_d_m = [0, 31, 59, 90, 120, 151, 181, 212, 243, 273, 304, 334];
    var jy = (gy <= 1600) ? 0 : 979;
    gy -= (gy <= 1600) ? 621 : 1600;
    var gy2 = (gm > 2) ? (gy + 1) : gy;
    var days = (365 * gy) + Math.floor((gy2 + 3) / 4) - Math.floor((gy2 + 99) / 100) +
               Math.floor((gy2 + 399) / 400) - 80 + gd + g_d_m[gm - 1];
    jy += 33 * Math.floor(days / 12053); days %= 12053;
    jy += 4 * Math.floor(days / 1461); days %= 1461;
    if (days > 365) { jy += Math.floor((days - 1) / 365); days = (days - 1) % 365; }
    var jm = (days < 186) ? 1 + Math.floor(days / 31) : 7 + Math.floor((days - 186) / 30);
    var jd = 1 + ((days < 186) ? (days % 31) : ((days - 186) % 30));
    var months = ['فروردین', 'اردیبهشت', 'خرداد', 'تیر', 'مرداد', 'شهریور', 'مهر', 'آبان', 'آذر', 'دی', 'بهمن', 'اسفند'];
    return faDigits(jd) + ' ' + months[jm - 1] + ' ' + faDigits(jy);
  }
  function faTime(ts) {
    var d = new Date(ts || Date.now());
    return faDigits(d.getHours()) + ':' + faDigits(('0' + d.getMinutes()).slice(-2));
  }
  function esc(s) {
    return String(s == null ? '' : s).replace(/[&<>"']/g, function (c) {
      return { '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c];
    });
  }
  function haptic(ms) {
    if (!State.settings.haptic) return;
    try { if (navigator.vibrate) navigator.vibrate(ms || 12); } catch (e) {}
  }

  /* ---------- cases ---------- */
  var CASE_TYPES = ['حقوقی', 'کیفری', 'خانواده', 'قرارداد', 'اداری', 'کار', 'ملکی', 'چک و سفته', 'سایر'];
  function createCase(data) {
    var c = {
      id: uid('case'),
      title: (data && data.title) || 'پرونده بدون عنوان',
      caseNo: (data && data.caseNo) || '',
      court: (data && data.court) || '',
      branch: (data && data.branch) || '',
      type: (data && data.type) || 'حقوقی',
      myRole: (data && data.myRole) || 'خوانده',
      opponent: (data && data.opponent) || '',
      subject: (data && data.subject) || '',
      status: (data && data.status) || 'در جریان',
      nextDate: (data && data.nextDate) || '',
      notes: (data && data.notes) || '',
      createdAt: Date.now(),
      updatedAt: Date.now(),
      analysis: [],
      drafts: [],
      timeline: [],
      chat: []
    };
    State.cases.unshift(c);
    save(); return c;
  }
  function getCase(id) {
    for (var i = 0; i < State.cases.length; i++) if (State.cases[i].id === id) return State.cases[i];
    return null;
  }
  function touchCase(id) { var c = getCase(id); if (c) { c.updatedAt = Date.now(); save(); } }
  function deleteCase(id) {
    State.cases = State.cases.filter(function (c) { return c.id !== id; });
    State.files = State.files.filter(function (f) { return f.caseId !== id; });
    if (State.activeCaseId === id) State.activeCaseId = null;
    save();
  }
  function activeCase() { return State.activeCaseId ? getCase(State.activeCaseId) : null; }

  /* ---------- files / evidence ---------- */
  function addFile(rec) {
    var f = {
      id: uid('f'),
      caseId: rec.caseId || null,
      name: rec.name || 'سند',
      mime: rec.mime || '',
      size: rec.size || 0,
      kind: rec.kind || 'other',
      dataUrl: rec.dataUrl || '',
      thumb: rec.thumb || '',
      text: rec.text || '',
      createdAt: Date.now()
    };
    State.files.push(f);
    if (f.caseId) {
      var c = getCase(f.caseId);
      if (c) c.timeline.push({ ts: Date.now(), text: 'مدرک «' + f.name + '» به پرونده پیوست شد' });
    }
    save(); return f;
  }
  function filesOf(caseId) {
    return State.files.filter(function (f) { return f.caseId === caseId; });
  }
  function delFile(id) {
    State.files = State.files.filter(function (f) { return f.id !== id; });
    save();
  }

  /* ---------- chat sessions ---------- */
  function sessionKey(caseId) { return caseId || 'global'; }
  function getSession(caseId) {
    var k = sessionKey(caseId);
    if (!State.sessions[k]) State.sessions[k] = { messages: [], agent: 'coordinator' };
    return State.sessions[k];
  }
  function pushMsg(caseId, msg) {
    var s = getSession(caseId);
    s.messages.push(msg);
    if (s.messages.length > 160) s.messages.splice(0, s.messages.length - 160);
    if (caseId) {
      var c = getCase(caseId);
      if (c) { c.chat = c.chat || []; c.chat.push(msg); if (c.chat.length > 160) c.chat.splice(0, c.chat.length - 160); }
    }
    save();
    return msg;
  }

  /* ---------- file reading helpers ---------- */
  function pickFiles(accept) {
    return new Promise(function (resolve) {
      var input = document.getElementById('filePick');
      input.value = '';
      input.setAttribute('accept', accept || 'image/*,application/pdf,.doc,.docx,.txt,.rtf');
      var done = false;
      function onChange() {
        if (done) return; done = true;
        input.removeEventListener('change', onChange);
        resolve(Array.prototype.slice.call(input.files || []));
      }
      input.addEventListener('change', onChange);
      input.click();
      setTimeout(function () { if (!done) { done = true; input.removeEventListener('change', onChange); resolve([]); } }, 120000);
    });
  }

  function readDataUrl(file) {
    return new Promise(function (res, rej) {
      var r = new FileReader();
      r.onload = function () { res(r.result); };
      r.onerror = rej;
      r.readAsDataURL(file);
    });
  }

  function downscale(dataUrl, maxSide, quality) {
    return new Promise(function (resolve) {
      var img = new Image();
      img.onload = function () {
        var w = img.naturalWidth, h = img.naturalHeight;
        var s = Math.min(1, (maxSide || 1400) / Math.max(w, h));
        w = Math.round(w * s); h = Math.round(h * s);
        var cv = document.createElement('canvas');
        cv.width = w; cv.height = h;
        var cx = cv.getContext('2d');
        cx.drawImage(img, 0, 0, w, h);
        try { resolve(cv.toDataURL('image/jpeg', quality || 0.72)); } catch (e) { resolve(dataUrl); }
      };
      img.onerror = function () { resolve(dataUrl); };
      img.src = dataUrl;
    });
  }

  function cidToMime(mime) {
    if (!mime) return 'application/octet-stream';
    return mime;
  }

  /* OCR fallback for scanned/image PDFs: render page 1 to canvas → image */
  function pdfFirstPageImage(dataUrl) {
    return new Promise(function (resolve) {
      var lib = window.pdfjsLib;
      if (!lib) return resolve(null);
      try {
        var bytes = atob(dataUrl.split(',')[1]);
        var arr = new Uint8Array(bytes.length);
        for (var i = 0; i < bytes.length; i++) arr[i] = bytes.charCodeAt(i);
        lib.getDocument({ data: arr }).promise.then(function (pdf) {
          if (!pdf.numPages) return resolve(null);
          return pdf.getPage(1).then(function (page) {
            var vp = page.getViewport({ scale: 1.6 });
            var cv = document.createElement('canvas');
            cv.width = vp.width; cv.height = vp.height;
            var ctx = cv.getContext('2d');
            ctx.fillStyle = '#fff'; ctx.fillRect(0, 0, cv.width, cv.height);
            return page.render({ canvasContext: ctx, viewport: vp }).promise.then(function () {
              resolve(cv.toDataURL('image/jpeg', 0.7));
            });
          });
        }).catch(function () { resolve(null); });
      } catch (e) { resolve(null); }
    });
  }

  /* Extract text: txt 직접 / pdf با pdf.js / تصویر → '' (به مدل تصویری ارسال می‌شود) */
  function extractFile(f) {
    return new Promise(function (resolve) {
      var name = (f.name || '').toLowerCase();
      var isImg = /^image\//.test(f.type) || /\.(png|jpe?g|webp|bmp|gif)$/.test(name);
      var isPdf = f.type === 'application/pdf' || /\.pdf$/.test(name);
      var isTxt = /^text\//.test(f.type) || /\.(txt|md|csv|json)$/.test(name);
      var isDoc = /\.(docx?|rtf)$/.test(name);

      if (isTxt || isDoc) {
        var fr = new FileReader();
        fr.onload = function () {
          var t = String(fr.result || '');
          /* استخراج متن خام از docx/rtf به‌صورت ابتدایی */
          if (isDoc) {
            t = t.replace(/<[^>]+>/g, ' ').replace(/\\[a-z]+-?\d* ?/g, ' ').replace(/[{}]/g, ' ')
                 .replace(/[^\S\n]+/g, ' ');
          }
          addFile({ name: f.name, mime: f.type, size: f.size, kind: isDoc ? 'doc' : 'text', text: t.slice(0, 200000) });
          resolve({ kind: isDoc ? 'doc' : 'text' });
        };
        fr.onerror = function () { resolve({ kind: 'other' }); };
        fr.readAsText(f, 'utf-8');
        return;
      }

      readDataUrl(f).then(function (du) {
        if (isImg) {
          downscale(du, 1500, 0.74).then(function (small) {
            addFile({ name: f.name, mime: 'image/jpeg', size: f.size, kind: 'image', dataUrl: small });
            resolve({ kind: 'image' });
          });
          return;
        }
        if (isPdf) {
          var text = '', pages = 0, thumb = null;
          var finalize = function () {
            var hasText = text.trim().length > 40;
            addFile({ name: f.name, mime: 'application/pdf', size: f.size, kind: 'pdf', dataUrl: du,
                      text: text.slice(0, 400000), thumb: hasText ? '' : (thumb || '') });
            resolve({ kind: 'pdf', pages: pages, hasText: hasText, thumb: thumb });
          };
          if (!window.pdfjsLib) { finalize(); return; }
          try {
            var b64 = du.split(',')[1];
            var bin = atob(b64);
            var u8 = new Uint8Array(bin.length);
            for (var i = 0; i < bin.length; i++) u8[i] = bin.charCodeAt(i);
            window.pdfjsLib.getDocument({ data: u8 }).promise.then(function (pdf) {
              pages = pdf.numPages;
              var limit = Math.min(pdf.numPages, 40);
              var chain = Promise.resolve();
              for (var p = 1; p <= limit; p++) {
                (function (pn) {
                  chain = chain.then(function () {
                    return pdf.getPage(pn).then(function (pg) {
                      return pg.getTextContent().then(function (tc) {
                        var line = '';
                        tc.items.forEach(function (it) { line += it.str + ' '; });
                        text += '\n[صفحه ' + pn + ']\n' + line;
                        if (pn === 1) {
                          var vp = pg.getViewport({ scale: 1.4 });
                          var cv = document.createElement('canvas');
                          cv.width = vp.width; cv.height = vp.height;
                          var cx = cv.getContext('2d');
                          cx.fillStyle = '#fff'; cx.fillRect(0, 0, cv.width, cv.height);
                          return pg.render({ canvasContext: cx, viewport: vp }).promise.then(function () {
                            try { thumb = cv.toDataURL('image/jpeg', 0.6); } catch (e) {}
                          });
                        }
                      });
                    });
                  });
                })(p);
              }
              chain.then(finalize).catch(finalize);
            }).catch(finalize);
          } catch (e) { finalize(); }
          return;
        }
        addFile({ name: f.name, mime: f.type, size: f.size, kind: 'other', text: '' });
        resolve({ kind: 'other' });
      }).catch(function () { resolve({ kind: 'other' }); });
    });
  }

  /* متنی که از یک یا چند سند برای تحلیل ساخته می‌شود */
  function docsDigest(files, maxChars) {
    maxChars = maxChars || 24000;
    var out = [], used = 0;
    files.forEach(function (f) {
      var head = '—— سند: ' + f.name + ' (' + (f.kind === 'image' ? 'تصویر' : f.kind === 'pdf' ? 'PDF' : 'متن') + ') ——';
      var body = (f.text || '').trim();
      if (f.kind === 'pdf' && body) {
        body = body.replace(/\(cid:\d+\)/g, '').replace(/\s{2,}/g, ' ');
      }
      if (body) {
        var chunk = body.slice(0, Math.max(1200, maxChars - used));
        out.push(head + '\n' + chunk);
        used += chunk.length;
      } else {
        out.push(head + '\n(متن قابل استخراج نبود؛ محتوای تصویری سند برای کارشناس ارسال می‌شود.)');
      }
    });
    return out.join('\n\n').slice(0, maxChars);
  }

  /* تصاویری که باید به مدل بینایی ارسال شوند: عکس‌ها و PDF های اسکن‌شده (بدون متن) */
  function visionImages(files, max) {
    var out = [];
    (files || []).forEach(function (f) {
      if (out.length >= (max || 4)) return;
      if (f.kind === 'image' && f.dataUrl) out.push(f.dataUrl);
      else if (f.kind === 'pdf' && (!f.text || f.text.trim().length < 40) && f.thumb) out.push(f.thumb);
    });
    return out;
  }

  window.Store = {
    State: State, load: load, save: save, uid: uid, clone: clone, esc: esc,
    faDigits: faDigits, fmtSize: fmtSize, pdate: pdate, faTime: faTime, haptic: haptic,
    CASE_TYPES: CASE_TYPES,
    createCase: createCase, getCase: getCase, deleteCase: deleteCase, touchCase: touchCase, activeCase: activeCase,
    addFile: addFile, filesOf: filesOf, delFile: delFile,
    getSession: getSession, pushMsg: pushMsg,
    pickFiles: pickFiles, readDataUrl: readDataUrl, downscale: downscale,
    extractFile: extractFile, docsDigest: docsDigest, pdfFirstPageImage: pdfFirstPageImage,
    visionImages: visionImages,
    DEFAULT_STATE: DEFAULT_STATE
  };
})();
