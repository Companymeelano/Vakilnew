/* ============ Vakil AI — Mini Markdown → HTML (فارسی/RTL) ============ */
(function () {
  'use strict';
  function esc(s) {
    return String(s == null ? '' : s).replace(/[&<>"]/g, function (c) {
      return { '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;' }[c];
    });
  }
  function inline(t) {
    t = esc(t);
    t = t.replace(/`([^`]+)`/g, '<code>$1</code>');
    t = t.replace(/\*\*([^*]+)\*\*/g, '<strong>$1</strong>');
    t = t.replace(/(^|[\s(«])\*([^*\n]+)\*/g, '$1<em>$2</em>');
    t = t.replace(/__([^_]+)__/g, '<strong>$1</strong>');
    t = t.replace(/\[([^\]]+)\]\((https?:\/\/[^\s)]+)\)/g, '<a href="$2" target="_blank" rel="noopener">$1</a>');
    t = t.replace(/(^|\s)(https?:\/\/[^\s<]+)/g, '$1<a href="$2" target="_blank" rel="noopener">$2</a>');
    return t;
  }
  function md(src) {
    if (!src) return '';
    var lines = String(src).replace(/\r/g, '').split('\n');
    var out = [], i = 0, list = null, para = [];

    function flushPara() {
      if (para.length) { out.push('<p>' + inline(para.join(' ')) + '</p>'); para = []; }
    }
    function closeList() { if (list) { out.push('</' + list + '>'); list = null; } }

    while (i < lines.length) {
      var ln = lines[i], t = ln.trim();

      if (/^```/.test(t)) {                                  /* code fence */
        flushPara(); closeList();
        var buf = []; i++;
        while (i < lines.length && !/^```/.test(lines[i].trim())) { buf.push(lines[i]); i++; }
        out.push('<pre><code>' + esc(buf.join('\n')) + '</code></pre>'); i++; continue;
      }
      if (/^\s*$/.test(t)) { flushPara(); closeList(); i++; continue; }

      if (/^#{1,6}\s+/.test(t)) {                            /* heading */
        flushPara(); closeList();
        var lvl = t.match(/^#+/)[0].length; if (lvl > 3) lvl = 3;
        out.push('<h' + lvl + '>' + inline(t.replace(/^#+\s+/, '')) + '</h' + lvl + '>');
        i++; continue;
      }
      if (/^(-{3,}|\*{3,}|_{3,})$/.test(t)) { flushPara(); closeList(); out.push('<hr>'); i++; continue; }

      if (/^>\s?/.test(t)) {                                  /* blockquote */
        flushPara(); closeList();
        var q = [];
        while (i < lines.length && /^>\s?/.test(lines[i].trim())) { q.push(lines[i].trim().replace(/^>\s?/, '')); i++; }
        out.push('<blockquote>' + inline(q.join(' ')) + '</blockquote>'); continue;
      }
      if (/^\|.+\|\s*$/.test(t) && i + 1 < lines.length && /^\|[\s:\-|]+\|\s*$/.test(lines[i + 1].trim())) {
        flushPara(); closeList();                              /* table */
        var cells = t.replace(/^\||\|$/g, '').split('|').map(function (c) { return c.trim(); });
        out.push('<table><thead><tr>' + cells.map(function (c) { return '<th>' + inline(c) + '</th>'; }).join('') + '</tr></thead><tbody>');
        i += 2;
        while (i < lines.length && /^\|.+\|\s*$/.test(lines[i].trim())) {
          var cs = lines[i].trim().replace(/^\||\|$/g, '').split('|').map(function (c) { return c.trim(); });
          out.push('<tr>' + cs.map(function (c) { return '<td>' + inline(c) + '</td>'; }).join('') + '</tr>');
          i++;
        }
        out.push('</tbody></table>'); continue;
      }
      var ul = t.match(/^[-*•]\s+(.*)$/), ol = t.match(/^\d+[.)]\s+(.*)$/);
      if (ul || ol) {
        flushPara();
        var want = ul ? 'ul' : 'ol';
        if (list && list !== want) closeList();
        if (!list) { list = want; out.push('<' + want + '>'); }
        out.push('<li>' + inline((ul ? ul[1] : ol[1])) + '</li>');
        i++; continue;
      }
      closeList(); para.push(t); i++;
    }
    flushPara(); closeList();
    return out.join('\n');
  }
  window.MD = { render: md, esc: esc, inline: inline };
})();
