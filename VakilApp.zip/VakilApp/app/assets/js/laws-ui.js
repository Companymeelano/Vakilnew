/* ============ Vakil AI — بانک قوانین، ظاهر، امنیت و صدای کاراکتر ============ */
(function () {
  'use strict';
  var S = window.Store, K = window.Knowledge;
  var q = function (id) { return document.getElementById(id); };
  function $$(sel, r) { return Array.prototype.slice.call((r || document).querySelectorAll(sel)); }
  function el(html) { var d = document.createElement('div'); d.innerHTML = html.trim(); return d.firstChild; }
  function ico(id, cls) { return '<svg class="ico ' + (cls || '') + '"><use href="#' + id + '"/></svg>'; }
  function esc(s) { return S.esc(s); }
  function toast(m, k) { window.Pages.toast(m, k); }

  var state = { q: '', law: '', dom: '', results: [] };

  /* ================= THEMES & FONT ================= */
  var THEMES = [
    { id: 'midnight', name: 'نیمه‌شب طلایی', c1: '#e7c477', c2: '#8f6420' },
    { id: 'emerald', name: 'زمرد دادگستری', c1: '#7fe0b8', c2: '#1c7a5a' },
    { id: 'royal', name: 'ارغوانی سلطنتی', c1: '#c3a6ff', c2: '#5b34b8' },
    { id: 'ruby', name: 'یاقوت سرخ', c1: '#ffa9a9', c2: '#a02c3a' }
  ];
  function applyTheme(id) {
    document.body.setAttribute('data-theme', id || 'midnight');
  }
  function applyFont(scale) {
    var app = q('app');
    if (app) app.style.zoom = scale && scale !== 100 ? (scale / 100) : '';
  }
  function applyAll() {
    var st = S.State.settings;
    applyTheme(st.theme || 'midnight');
    applyFont(st.fontScale || 100);
  }

  /* ================= VOICE (native TTS) ================= */
  function hasTTS() { return !!(window.VakilNative && window.VakilNative.ttsAvailable && window.VakilNative.ttsAvailable()); }
  function speakText(t) {
    if (!S.State.settings.voice) return 0;
    if (!hasTTS()) return 0;
    try { window.VakilNative.ttsSpeak(String(t).slice(0, 700)); } catch (e) { return 0; }
    return Math.min(60000, Math.max(1800, String(t).length * 62));
  }
  function stopSpeaking() { try { if (hasTTS()) window.VakilNative.ttsStop(); } catch (e) {} }
  window.vakilTTSDone = function () { try { window.Character && Character.stopSpeech && Character.stopSpeech(); } catch (e) {} };

  /* ================= LAWS VIEW ================= */
  function renderLaws() {
    var host = q('view-laws');
    if (!host) return;
    if (!host.__built) {
      host.innerHTML =
        '<div class="view-head"><h2>' + ico('i-books') + ' بانک قوانین ایران</h2><span class="hint" id="lawStat"></span></div>' +
        '<div class="searchbar">' + ico('i-search') + '<input id="lawQ" placeholder="جست‌وجو در متن قوانین: مثال «تخلیه ملک»، «مهریه عندالاستطاعه»، «معاونت در جرم»، «چک بلامحل»"></div>' +
        '<div class="seg" id="lawDom">' +
        '<button class="seg-btn active" data-d="">همه حوزه‌ها</button>' +
        '<button class="seg-btn" data-d="rights">حقوقی</button>' +
        '<button class="seg-btn" data-d="criminal">کیفری</button>' +
        '<button class="seg-btn" data-d="family">خانواده</button>' +
        '<button class="seg-btn" data-d="contract">قرارداد</button>' +
        '<button class="seg-btn" data-d="labor">کار</button>' +
        '</div>' +
        '<div class="chip-strip" id="lawChips"></div>' +
        '<div id="lawResults"></div>' +
        '<div class="card" id="lawImportCard"></div>';
      host.__built = true;
      var t = null;
      q('lawQ').addEventListener('input', function () {
        clearTimeout(t);
        var v = this.value;
        t = setTimeout(function () { state.q = v; doSearch(); }, 220);
      });
      q('lawDom').addEventListener('click', function (e) {
        var b = e.target.closest('.seg-btn'); if (!b) return;
        state.dom = b.getAttribute('data-d');
        $$('#lawDom .seg-btn').forEach(function (x) { x.classList.toggle('active', x === b); });
        doSearch();
      });
    }
    var st = K.stats();
    var imports = (S.State.lawImports || []);
    q('lawStat').textContent = S.faDigits(st.total) + ' مدخل · ' + S.faDigits(st.laws) + ' قانون';
    /* chips: filter by law */
    var chips = q('lawChips');
    chips.innerHTML = '';
    var mkChip = function (label, val, count) {
      var c = el('<button class="law-chip' + (state.law === val ? ' on' : '') + '"><b>' + esc(label) + '</b><span>' + S.faDigits(count) + '</span></button>');
      c.addEventListener('click', function () {
        state.law = (state.law === val) ? '' : val;
        doSearch();
      });
      chips.appendChild(c);
    };
    var byLaw = [];
    K.laws.forEach(function (l) {
      var n = l.articles.length;
      if (n) byLaw.push({ name: l.name, n: n });
    });
    byLaw.forEach(function (l) { mkChip(l.name, l.name, l.n); });
    renderImportCard();
    doSearch();
  }

  function renderImportCard() {
    var card = q('lawImportCard');
    if (!card) return;
    var imports = S.State.lawImports || [];
    var st = K.stats();
    var list = '';
    if (imports.length) {
      list = '<div class="import-list">' + imports.map(function (im) {
        return '<div class="import-row" data-id="' + im.id + '"><span>' + ico('i-books') + ' ' + esc(im.name) + '</span>' +
          '<b>' + S.faDigits(im.articles.length) + ' ماده</b>' +
          '<button class="doc-del" style="position:static">' + ico('i-trash') + '</button></div>';
      }).join('') + '</div>';
    }
    card.innerHTML = '<div class="card-h">' + ico('i-upload') + ' افزودن متن کامل قانون (اختیاری)</div>' +
      '<p class="card-p">متن رسمی قوانین را از فایل <b>txt</b> یا PDF متنی وارد کنید؛ مواد به‌صورت خودکار تفکیک و به بانک (و موتور تحلیل آفلاین) اضافه می‌شوند. ' +
      'متون رسمی فعلی از ویکینبشتهٔ فارسی (مجوز CC BY-SA 4.0) بارگذاری شده‌اند.</p>' +
      (list || '') +
      '<div class="row-actions">' +
      '<button class="gold-btn sm" id="lawImpBtn">' + ico('i-plus') + ' وارد کردن قانون از فایل</button>' +
      '<button class="ghost-btn" id="lawPasteBtn">' + ico('i-pen') + ' جای‌گذاری متن قانون</button>' +
      '</div>';
    q('lawImpBtn').addEventListener('click', importFromFile);
    q('lawPasteBtn').addEventListener('click', importFromPaste);
    $$('.import-row', card).forEach(function (row) {
      row.querySelector('.doc-del').addEventListener('click', function () {
        K.removeImport(row.getAttribute('data-id'));
        toast('قانون واردشده حذف شد');
        renderLaws();
        if (q('view-doc')) { /* refresh stats elsewhere */ }
      });
    });
  }

  function askLawName(cb) {
    window.Pages.modal('<h3>' + ico('i-books') + ' مشخصات قانون</h3>' +
      '<label class="field"><span>نام قانون</span><input id="impName" placeholder="مثال: قانون مجازات اسلامی (تعزیرات و حدود)"></label>' +
      '<label class="field"><span>حوزه</span><select id="impDom"><option value="">همه</option><option value="rights">حقوقی</option>' +
      '<option value="criminal">کیفری</option><option value="family">خانواده</option><option value="contract">قرارداد</option>' +
      '<option value="labor">کار</option></select></label>' +
      '<div class="m-foot"><button class="gold-btn" id="impOk">ادامه</button><button class="ghost-btn" id="impNo">انصراف</button></div>',
      { persistent: true });
    var w = window.Pages.__lastModal();
    w.querySelector('#impNo').addEventListener('click', function () { window.Pages.closeModal(); });
    w.querySelector('#impOk').addEventListener('click', function () {
      var name = w.querySelector('#impName').value.trim() || 'قانون واردشده';
      var dom = w.querySelector('#impDom').value;
      window.Pages.closeModal();
      cb(name, dom);
    });
  }

  function importFromFile() {
    askLawName(function (name, dom) {
      S.pickFiles('.txt,.text,.md,application/pdf').then(function (files) {
        if (!files.length) return;
        var f = files[0];
        if (/\.pdf$/i.test(f.name) || f.type === 'application/pdf') {
          S.readDataUrl(f).then(function (du) {
            if (!window.pdfjsLib) { toast('خوانش PDF در دسترس نیست', 'bad'); return; }
            var bin = atob(du.split(',')[1]);
            var u8 = new Uint8Array(bin.length);
            for (var i = 0; i < bin.length; i++) u8[i] = bin.charCodeAt(i);
            toast('در حال خواندن PDF...');
            pdfjsLib.getDocument({ data: u8 }).promise.then(function (pdf) {
              var text = '', chain = Promise.resolve();
              for (var p = 1; p <= pdf.numPages; p++) {
                (function (pn) {
                  chain = chain.then(function () {
                    return pdf.getPage(pn).then(function (pg) {
                      return pg.getTextContent().then(function (tc) {
                        tc.items.forEach(function (it) { text += it.str + ' '; });
                        text += '\n';
                      });
                    });
                  });
                })(p);
              }
              chain.then(function () { finishImport(name, dom, text); });
            }).catch(function () { toast('خواندن PDF ناموفق بود', 'bad'); });
          });
        } else {
          var fr = new FileReader();
          fr.onload = function () { finishImport(name, dom, String(fr.result || '')); };
          fr.readAsText(f, 'utf-8');
        }
      });
    });
  }

  function importFromPaste() {
    askLawName(function (name, dom) {
      window.Pages.modal('<h3>' + ico('i-pen') + ' جای‌گذاری متن قانون</h3>' +
        '<p class="card-p">متن کامل قانون را با ذکر «ماده ۱»، «ماده ۲» ... جای‌گذاری کنید؛ تفکیک خودکار انجام می‌شود.</p>' +
        '<label class="field"><textarea id="impText" rows="9" style="font-size:12px"></textarea></label>' +
        '<div class="m-foot"><button class="gold-btn" id="impGo">' + ico('i-check') + ' افزودن</button>' +
        '<button class="ghost-btn" id="impCancel">انصراف</button></div>', { persistent: true });
      var w = window.Pages.__lastModal();
      w.querySelector('#impCancel').addEventListener('click', function () { window.Pages.closeModal(); });
      w.querySelector('#impGo').addEventListener('click', function () {
        var txt = w.querySelector('#impText').value;
        window.Pages.closeModal();
        finishImport(name, dom, txt);
      });
    });
  }

  function finishImport(name, dom, text) {
    var res = K.importLaw(name, text, dom ? [dom] : []);
    if (!res.ok) { toast(res.msg, 'bad', 5000); return; }
    toast('«' + res.name + '» با ' + S.faDigits(res.count) + ' ماده به بانک اضافه شد', 'ok', 4200);
    window.Character && Character.say('قانون «' + res.name + '» با ' + S.faDigits(res.count) +
      ' ماده به بانک قوانین اضافه شد؛ از این پس در تحلیل‌های آفلاین و استنادهای هوش مصنوعی استفاده می‌شود.', { mood: 'happy' });
    state.law = ''; renderLaws();
  }

  function doSearch() {
    var host = q('lawResults');
    if (!host) return;
    var qq = state.q.trim();
    var hits = [];
    if (qq) {
      hits = K.search(qq, { domain: state.dom || null, top: 60 });
      if (state.law) hits = hits.filter(function (h) { return h.law === state.law; });
    } else if (state.law) {
      var lawObj = K.laws.filter(function (l) { return l.name === state.law; })[0];
      hits = (lawObj ? lawObj.articles : []).slice(0, 80).map(function (a) {
        return { law: lawObj.name, art: a.art, text: a.text, curated: a.curated, verify: a.verify, source: lawObj.source };
      });
    } else {
      /* پیشنهادهای شاخص: اصول کاربردی + مواد کلیدی */
      hits = K.search('مهلت تجدیدنظر خواسته ادله اثبات قرارداد اجاره مهریه چک', { top: 12 });
    }
    host.innerHTML = '';
    if (!hits.length) {
      host.appendChild(el('<div class="empty">موردی یافت نشد. کلیدواژهٔ دیگری امتحان کنید یا متن قانون را خودتان وارد کنید (پایین همین صفحه).</div>'));
      return;
    }
    var bar = el('<div class="law-bar"><span>' + S.faDigits(hits.length) + ' نتیجه</span>' +
      (state.law ? '<button class="ghost-btn sm" id="clearLaw">حذف فیلتر قانون</button>' : '') + '</div>');
    host.appendChild(bar);
    if (q('clearLaw')) q('clearLaw').addEventListener('click', function () { state.law = ''; doSearch(); renderChips(); });
    hits.forEach(function (h) { host.appendChild(hitCard(h, qq)); });
  }

  function renderChips() {
    var chips = q('lawChips');
    if (!chips) return;
    $$('.law-chip', chips).forEach(function (c) {
      var label = c.querySelector('b').textContent;
      c.classList.toggle('on', state.law === label);
    });
  }

  function hitCard(h, query) {
    var card = el('<div class="law-card">' +
      '<div class="law-card-h"><span class="law-name">' + ico('i-books') + ' ' + esc(h.law) + '</span>' +
      '<span class="law-art">' + (h.curated ? esc(h.art) : 'مادهٔ ' + esc(S.faDigits(h.art))) + '</span>' +
      (h.curated ? '<span class="law-tag ' + (h.verify ? 'warn' : 'ok') + '">' + (h.verify ? 'نیازمند تأیید' : 'اصل کاربردی') + '</span>'
                 : '<span class="law-tag">' + (h.source === 'import' ? 'واردشده' : 'متن رسمی') + '</span>') +
      '</div>' +
      '<div class="law-text">' + esc(h.text) + '</div>' +
      '<div class="law-acts">' +
      '<button class="ghost-btn sm" data-a="copy">' + ico('i-files') + ' کپی</button>' +
      '<button class="ghost-btn sm" data-a="cite">' + ico('i-quote') + ' افزودن به تحلیل</button>' +
      '<button class="ghost-btn sm" data-a="chat">' + ico('i-chat') + ' پرسش دربارهٔ این ماده</button>' +
      '</div></div>');
    var cite = h.law + (h.curated ? ' — ' + h.art : ' — مادهٔ ' + h.art) + ':\n' + h.text;
    card.querySelector('[data-a="copy"]').addEventListener('click', function () {
      window.Pages.copyText ? window.Pages.copyText(cite) : toast('کپی شد');
    });
    card.querySelector('[data-a="cite"]').addEventListener('click', function () {
      var ta = q('docText');
      if (!ta) { window.Pages.go('doc'); ta = q('docText'); }
      ta.value = (ta.value ? ta.value + '\n\n' : '') + '—— استناد از بانک قوانین ——\n' + cite + '\n';
      toast('به متن تحلیل اضافه شد', 'ok');
      window.Character && Character.nod();
    });
    card.querySelector('[data-a="chat"]').addEventListener('click', function () {
      window.Pages.go('home');
      var t = q('chatText');
      t.value = 'دربارهٔ ' + h.law + (h.curated ? '' : ' مادهٔ ' + h.art) + ' توضیح بده و ارتباطش را با موضوع من تحلیل کن.';
      t.focus();
      window.Character && Character.say('پرسش خوبی است؛ دربارهٔ همین ماده توضیح می‌دهم.', { mood: 'smile' });
    });
    if (query) {
      var t = h.text, i = t.indexOf(query);
      if (i < 0) {
        var w = query.split(' ')[0];
        i = t.indexOf(w);
      }
      if (i >= 0) {
        var pre = esc(t.slice(0, i)), mid = esc(t.substr(i, query.length || 1)), post = esc(t.slice(i + (query.length || 1)));
        card.querySelector('.law-text').innerHTML = pre + '<mark>' + mid + '</mark>' + post;
      }
    }
    return card;
  }

  /* ================= SETTINGS AUGMENT ================= */
  function settingsHTML() {
    var st = S.State.settings;
    var stats = K.stats();
    var themes = THEMES.map(function (t) {
      return '<button class="theme-dot' + ((st.theme || 'midnight') === t.id ? ' on' : '') + '" data-theme-id="' + t.id + '" title="' + t.name + '">' +
        '<i style="background:linear-gradient(140deg,' + t.c1 + ',' + t.c2 + ')"></i><b>' + t.name + '</b></button>';
    }).join('');
    var doms = ['حقوقی', 'کیفری', 'خانواده', 'قرارداد', 'کار', 'عمومی'];
    var byLaw = Object.keys(stats.byLaw).sort(function (a, b) { return stats.byLaw[b] - stats.byLaw[a]; })
      .map(function (k) { return '<li>' + ico('i-books') + '<span>' + esc(k) + ' <span class="ro">' + S.faDigits(stats.byLaw[k]) + ' ماده</span></span></li>'; }).join('');
    return '' +
      '<div class="card"><div class="card-h">' + ico('i-books') + ' بانک قوانین آفلاین</div>' +
      '<p class="card-p">تحلیل‌ها — حتی بدون اینترنت و بدون کلید API — روی همین مواد بنا می‌شوند. ' +
      'مجموع: <b>' + S.faDigits(stats.total) + ' مدخل</b> از <b>' + S.faDigits(stats.laws) + ' قانون</b>.</p>' +
      '<ul class="steps law-list">' + byLaw + '</ul>' +
      '<p class="card-p">' + esc(window.LAW_CORPUS ? window.LAW_CORPUS.attribution : '') + '</p>' +
      '<div class="row-actions"><button class="gold-btn sm" id="goLaws">' + ico('i-search') + ' رفتن به بانک قوانین</button>' +
      '<button class="ghost-btn" id="goLawsImport">' + ico('i-upload') + ' افزودن متن کامل قانون</button></div></div>' +

      '<div class="card"><div class="card-h">' + ico('i-star') + ' ظاهر و خوانایی</div>' +
      '<div class="theme-row">' + themes + '</div>' +
      '<label class="field"><span>اندازهٔ متن برنامه</span>' +
      '<div class="seg small" id="fontSeg">' +
      [90, 100, 115, 130].map(function (f) {
        return '<button class="seg-btn' + ((st.fontScale || 100) === f ? ' active' : '') + '" data-fs="' + f + '">' + S.faDigits(f) + '٪</button>';
      }).join('') + '</div></label>' +
      '<label class="switch-row"><span>انیمیشن‌های سه‌بعدی و درخشش دکمه‌ها</span><input type="checkbox" id="setFx" ' + (st.fx === false ? '' : 'checked') + '><i></i></label>' +
      '</div>' +

      '<div class="card"><div class="card-h">' + ico('i-mic') + ' صدای خانم وکیل (گویش فارسی)</div>' +
      '<p class="card-p">' + (hasTTS() ? 'کاراکتر با صدای طبیعی فارسی صحبت می‌کند؛ حرکت لب‌ها با صدا هم‌زمان می‌شود.' : 'موتور گفتار این دستگاه در دسترس نیست؛ متن‌ها همچنان نمایش داده می‌شوند.') + '</p>' +
      '<label class="switch-row"><span>گفتار کاراکتر با صدای بلند</span><input type="checkbox" id="setVoice" ' + (st.voice ? 'checked' : '') + ' ' + (hasTTS() ? '' : 'disabled') + '><i></i></label>' +
      '<label class="field"><span>سرعت گفتار</span><input type="range" id="setVoiceRate" min="5" max="15" value="' + (st.voiceRate || 9) + '"><em id="voiceRateVal"></em></label>' +
      '<div class="row-actions"><button class="ghost-btn" id="testVoice">' + ico('i-bolt') + ' آزمایش صدا</button></div>' +
      '</div>' +

      '<div class="card"><div class="card-h">' + ico('i-lock') + ' امنیت و حریم خصوصی</div>' +
      '<p class="card-p">پرونده‌ها و مدارک شما حاوی اطلاعات حساس است. با قفل عددی، ورود به برنامه را محدود کنید.</p>' +
      '<label class="switch-row"><span>قفل ورود با رمز عددی</span><input type="checkbox" id="setLock" ' + (st.lock && st.lock.enabled ? 'checked' : '') + '><i></i></label>' +
      '<label class="switch-row"><span>پاک‌سازی خودکار کلیپ‌بورد پس از کپی متن حقوقی</span><input type="checkbox" id="setClipClear" ' + (st.clipClear ? 'checked' : '') + '><i></i></label>' +
      '<div class="row-actions"><button class="ghost-btn" id="setPinBtn">' + ico('i-key') + ' تغییر رمز عددی</button>' +
      '<button class="ghost-btn" id="lockNow">' + ico('i-lock') + ' قفل فوری برنامه</button></div>' +
      '</div>' +

      '<div class="card"><div class="card-h">' + ico('i-download') + ' خروجی فایل روی گوشی</div>' +
      '<p class="card-p">ذخیرهٔ پشتیبان و اسناد نگاشته‌شده به‌صورت فایل در پوشهٔ Downloads دستگاه.</p>' +
      '<div class="row-actions"><button class="ghost-btn" id="expBackupFile">' + ico('i-download') + ' پشتیبان JSON روی گوشی</button>' +
      '<button class="ghost-btn" id="expLastDraft">' + ico('i-pen') + ' آخرین سند نوشته‌شده (txt)</button></div></div>';
  }

  function augmentSettings() {
    var host = q('view-settings');
    if (!host || q('augTheme')) return;
    var anchor = host.querySelector('.about');
    var wrap = el('<div id="augTheme">' + settingsHTML() + '</div>');
    if (anchor) host.insertBefore(wrap, anchor); else host.appendChild(wrap);

    /* theme buttons */
    $$('.theme-dot', wrap).forEach(function (b) {
      b.addEventListener('click', function () {
        var id = b.getAttribute('data-theme-id');
        S.State.settings.theme = id; S.save();
        applyTheme(id);
        $$('.theme-dot', wrap).forEach(function (x) { x.classList.toggle('on', x === b); });
        toast('تم «' + b.querySelector('b').textContent + '» اعمال شد');
        window.Character && Character.setMood('happy', 2000);
      });
    });
    /* font size */
    q('fontSeg').addEventListener('click', function (e) {
      var b = e.target.closest('.seg-btn'); if (!b) return;
      var f = +b.getAttribute('data-fs');
      S.State.settings.fontScale = f; S.save();
      applyFont(f);
      $$('#fontSeg .seg-btn').forEach(function (x) { x.classList.toggle('active', x === b); });
    });
    /* fx */
    var fx = q('setFx');
    fx.addEventListener('change', function () {
      S.State.settings.fx = this.checked; S.save();
      document.body.classList.toggle('no-fx', !this.checked);
    });
    /* voice */
    var vv = q('setVoice');
    if (vv) vv.addEventListener('change', function () {
      S.State.settings.voice = this.checked; S.save();
      if (this.checked) speakText('سلام، من مهرآیین هستم؛ از این پس با صدا در خدمت شما هستم.');
      else stopSpeaking();
      toast(this.checked ? 'گفتار کاراکتر فعال شد' : 'گفتار کاراکتر خاموش شد');
    });
    var vr = q('setVoiceRate');
    var rateLabel = function (v) {
      var txt = v <= 7 ? 'آرام' : v <= 11 ? 'معمولی' : 'تند';
      return S.faDigits((v / 10).toFixed(1)) + '× · ' + txt;
    };
    vr.addEventListener('input', function () {
      S.State.settings.voiceRate = +this.value; S.save();
      q('voiceRateVal').textContent = rateLabel(+this.value);
      if (window.VakilNative && window.VakilNative.ttsRate) try { window.VakilNative.ttsRate(+this.value / 10); } catch (e) {}
    });
    q('voiceRateVal').textContent = rateLabel(+vr.value);
    q('testVoice').addEventListener('click', function () {
      if (!hasTTS()) { toast('موتور گفتار در این دستگاه نیست', 'bad'); return; }
      if (!S.State.settings.voice) { toast('ابتدا «گفتار کاراکتر» را روشن کنید', 'bad'); return; }
      speakText('به نام خدا؛ آماده‌ام پروندهٔ شما را بررسی کنم. موضوع را بفرمایید.');
      window.Character && Character.say('آماده‌ام پروندهٔ شما را بررسی کنم؛ موضوع را بفرمایید.', { mood: 'smile' });
    });
    /* lock */
    var lk = q('setLock');
    lk.addEventListener('change', function () {
      if (this.checked) {
        var self = this;
        self.checked = false;
        askPin('تعیین رمز عددی ورود (۴ تا ۸ رقم)', '', function (pin) {
          S.State.settings.lock = { enabled: true, hash: hashPin(pin) };
          S.save(true); self.checked = true;
          toast('قفل ورود فعال شد', 'ok');
        });
      } else {
        S.State.settings.lock = { enabled: false, hash: (S.State.settings.lock || {}).hash };
        S.save(true); toast('قفل ورود غیرفعال شد');
      }
    });
    q('setPinBtn').addEventListener('click', function () {
      askPin('ابتدا رمز فعلی را وارد کنید', 'current', function () {
        askPin('رمز جدید را وارد کنید', '', function (pin) {
          S.State.settings.lock = { enabled: true, hash: hashPin(pin) };
          S.save(true); toast('رمز تغییر کرد', 'ok');
        });
      });
    });
    q('lockNow').addEventListener('click', function () {
      if (!(S.State.settings.lock && S.State.settings.lock.enabled)) { toast('ابتدا قفل را فعال کنید', 'bad'); return; }
      lockNow(true);
    });
    var cc = q('setClipClear');
    cc.addEventListener('change', function () { S.State.settings.clipClear = this.checked; S.save(); });
    /* exports */
    q('expBackupFile').addEventListener('click', function () { exportFileBackup(); });
    q('expLastDraft').addEventListener('click', function () {
      var txt = findLastDraft();
      if (!txt) { toast('سند نگاشته‌شده‌ای یافت نشد', 'bad'); return; }
      saveFile('لایحه-' + Date.now() + '.txt', txt, 'آخرین سند نگاشته‌شده');
    });
    q('goLaws').addEventListener('click', function () { window.Pages.go('laws'); });
    q('goLawsImport').addEventListener('click', function () { window.Pages.go('laws'); setTimeout(importFromFile, 400); });
  }

  /* ---- export helpers (native file save) ---- */
  function saveFile(name, content, label) {
    try {
      if (window.VakilNative && window.VakilNative.saveToDownloads) {
        var res = window.VakilNative.saveToDownloads(name, content);
        if (res && res.indexOf('OK:') === 0) {
          toast((label || 'فایل') + ' در پوشهٔ Downloads ذخیره شد', 'ok', 4200);
          return true;
        }
        toast('ذخیره ناموفق: ' + res, 'bad', 5000);
        return false;
      }
      /* fallback: دانلود مرورگر */
      var a = document.createElement('a');
      a.href = 'data:text/plain;charset=utf-8,' + encodeURIComponent(content);
      a.download = name; document.body.appendChild(a); a.click(); a.remove();
      toast('فایل آمادهٔ ذخیره شد', 'ok');
      return true;
    } catch (e) { toast('ذخیره ناموفق بود', 'bad'); return false; }
  }
  function exportFileBackup() {
    var json = JSON.stringify(S.State);
    saveFile('vakil-backup-' + Date.now() + '.json', json, 'پشتیبان کامل');
  }
  function findLastDraft() {
    var best = null;
    S.State.cases.forEach(function (c) {
      (c.drafts || []).forEach(function (d) { if (!best || d.ts > best.ts) best = d; });
    });
    return best ? best.text : '';
  }

  /* ================= PIN LOCK ================= */
  function hashPin(pin) {
    /* هش سبک محلی (برای قفل دسترسی؛ دادهٔ حساس ذخیره نمی‌شود) */
    var s = 'vakil::' + pin + '::' + (navigator.userAgent || 'x');
    var h1 = 0x811c9dc5, h2 = 0x1000193;
    for (var i = 0; i < s.length; i++) {
      var c = s.charCodeAt(i);
      h1 = ((h1 ^ c) * 16777619) >>> 0;
      h2 = ((h2 + c) * 2654435761) >>> 0;
    }
    for (var k = 0; k < 6; k++) { h1 = ((h1 ^ (h1 >>> 13)) * 2246822519) >>> 0; h2 = ((h2 ^ (h2 >>> 7)) * 3266489917) >>> 0; }
    return ('00000000' + h1.toString(16)).slice(-8) + ('00000000' + h2.toString(16)).slice(-8);
  }
  function askPin(title, mode, cb) {
    var entered = '';
    window.Pages.modal('<h3>' + ico('i-lock') + ' ' + title + '</h3>' +
      '<div class="pin-display" id="pinDisp"></div>' +
      '<div class="pin-pad" id="pinPad">' +
      [1, 2, 3, 4, 5, 6, 7, 8, 9].map(function (n) { return '<button data-p="' + n + '">' + S.faDigits(n) + '</button>'; }).join('') +
      '<button data-p="del">⌫</button><button data-p="0">۰</button><button data-p="ok" class="ok">تأیید</button></div>' +
      '<div class="m-foot"><button class="ghost-btn" id="pinCancel">انصراف</button></div>', { persistent: true });
    var w = window.Pages.__lastModal();
    var disp = w.querySelector('#pinDisp');
    var draw = function () { disp.textContent = entered.replace(/./g, '●'); };
    q('pinPad') && null;
    w.querySelector('#pinPad').addEventListener('click', function (e) {
      var b = e.target.closest('button[data-p]'); if (!b) return;
      var p = b.getAttribute('data-p');
      if (p === 'del') entered = entered.slice(0, -1);
      else if (p === 'ok') {
        if (entered.length < 4) { toast('رمز باید حداقل ۴ رقم باشد', 'bad'); return; }
        if (mode === 'current') {
          var cur = (S.State.settings.lock || {}).hash;
          if (hashPin(entered) !== cur) { toast('رمز فعلی نادرست است', 'bad'); entered = ''; draw(); return; }
        }
        window.Pages.closeModal(); cb(entered); return;
      } else if (entered.length < 8) entered += p;
      draw();
      S.haptic(8);
    });
    w.querySelector('#pinCancel').addEventListener('click', function () { window.Pages.closeModal(); });
    draw();
  }

  function lockNow(manual) {
    var lock = S.State.settings.lock || {};
    if (!lock.enabled || !lock.hash) return;
    var host = q('lockScreen');
    if (!host) return;
    host.classList.add('on');
    var entered = '', tries = 0;
    var disp = q('lockPin');
    var label = q('lockLabel');
    label.textContent = 'برای ورود، رمز عددی را وارد کنید';
    var draw = function () { disp.textContent = entered.replace(/./g, '●'); };
    draw();
    q('lockPad').onclick = function (e) {
      var b = e.target.closest('button[data-p]'); if (!b) return;
      var p = b.getAttribute('data-p');
      if (p === 'del') { entered = entered.slice(0, -1); draw(); return; }
      if (p === 'ok') {
        if (hashPin(entered) === lock.hash) {
          host.classList.remove('on');
          window.Character && Character.say('خوش آمدید؛ پرونده‌ها در دسترس شماست.', { mood: 'smile', force: true });
          return;
        }
        tries++;
        entered = ''; draw();
        label.textContent = 'رمز نادرست است (تلاش ' + S.faDigits(tries) + ')';
        S.haptic(60);
        return;
      }
      if (entered.length < 8) entered += p;
      draw();
      S.haptic(8);
    };
  }

  /* auto-lock on resume */
  var hiddenAt = 0;
  function watchVisibility() {
    document.addEventListener('visibilitychange', function () {
      if (document.hidden) { hiddenAt = Date.now(); return; }
      var mins = (Date.now() - hiddenAt) / 60000;
      var lock = S.State.settings.lock || {};
      if (hiddenAt && lock.enabled && mins >= 2) lockNow(false);
      hiddenAt = 0;
    });
  }

  /* ================= PUBLIC ================= */
  window.LawsUI = {
    renderLaws: renderLaws, augmentSettings: augmentSettings, applyAll: applyAll,
    applyTheme: applyTheme, applyFont: applyFont, speakText: speakText, stopSpeaking: stopSpeaking,
    lockNow: lockNow, hasTTS: hasTTS, importFromFile: importFromFile, saveFile: saveFile,
    exportFileBackup: exportFileBackup, watchVisibility: watchVisibility, THEMES: THEMES
  };
})();
