/* ============ Vakil AI — Bootstrap ============ */
(function () {
  'use strict';
  var S = window.Store;
  window.vakilBack = function () { return window.Pages.back(); };

  function hapticGlobal() {
    document.addEventListener('click', function (e) {
      var b = e.target.closest('button, .tile, .case-card, .agent-card, .tab, .seg-btn, .chip-btn');
      if (b) S.haptic(11);
    }, true);
  }

  function guard() {
    document.addEventListener('contextmenu', function (e) { if (!e.target.closest('textarea, input, .paper, .report-b')) e.preventDefault(); });
    var lastTouch = 0;
    document.addEventListener('touchend', function (e) {
      var now = Date.now();
      if (now - lastTouch < 300) e.preventDefault();
      lastTouch = now;
    }, { passive: false });
  }

  function boot() {
    S.load();
    try {
      if (window.pdfjsLib && pdfjsLib.GlobalWorkerOptions) {
        pdfjsLib.GlobalWorkerOptions.workerSrc = 'js/lib/pdf.worker.min.js';
      }
    } catch (e) {}
    try { Character.init(); } catch (e) { console.warn(e); }
    try { window.Knowledge && Knowledge.load(); } catch (e) { console.warn('corpus', e); }
    try { window.LawsUI && LawsUI.applyAll(); } catch (e) {}
    window.Pages.bind();
    window.Pages.go('home', { replace: true });
    hapticGlobal(); guard();

    /* personal greeting after the boot animation */
    setTimeout(function () {
      var c = S.activeCase();
      var ok = window.AI.isConfigured();
      var lock = S.State.settings.lock || {};
      if (lock.enabled && lock.hash) { window.LawsUI && LawsUI.lockNow(false); return; }
      if (!ok && !S.State.cases.length) {
        Character.say('خوش آمدید! من مهرآیین هستم، وکیل و مشاور حقوقی شما. برای شروع دو کار: ۱) در «تنظیمات» کلید API یکی از سرویس‌ها را وارد و تست کنید تا تحلیل هوشمند فعال شود. ۲) پرونده‌تان را بسازید تا اسناد و گفتگوها ذخیره شود و هر بار از اول تعریف نکنید.', { mood: 'smile', speed: 24 });
      } else if (c) {
        Character.say('پروندهٔ فعال شما «' + c.title + '» است؛ ' + S.faDigits(S.filesOf(c.id).length) + ' مدرک پیوست شده. می‌خواهید همه را مرور کنم و تحلیل به‌روز بدهم؟', { mood: 'smile' });
      } else if (!ok) {
        Character.say('برای فعال‌سازی تحلیل هوشمند، در تنظیمات کلید API را وارد و «تست اتصال» بگیرید.', { mood: 'concerned' });
      } else {
        Character.say('آماده‌ام! شرح پرونده را بنویسید یا مدرک بفرستید؛ تیم کارشناسان من همه را بررسی می‌کنند.', { mood: 'happy' });
      }
    }, 1100);
  }

  if (document.readyState === 'loading') document.addEventListener('DOMContentLoaded', boot);
  else boot();
})();
