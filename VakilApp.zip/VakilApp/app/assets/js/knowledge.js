/* ============ Vakil AI — موتور بانک قوانین (جست‌وجو، رتبه‌بندی، استناد/RAG) ============
   کاملاً آفلاین: ایندکس معکوس روی متون رسمی + اصول کاربردی.
   خروجی: موادی که مستقیماً در تحلیل و پاسخ هوش مصنوعی «استناد» می‌شوند. */
(function () {
  'use strict';

  var STOP = {};
  ('و در به از که این آن را با برای بر است هست نیست می‌شود شود شود، یا اگر تا هر همهٔ همه نیز هم یک دو بود بودن باید'.split(' '))
    .forEach(function (w) { STOP[w] = 1; });

  var JUNK = /\[[^\]]{0,40}\]|\{[^}]{0,40}\}|={2,}|_{2,}|^[=\-–—\s]+$/gm;

  /* ---- هم‌معناها و بسط پرسش (کیفیت بازیابی حقوقی) ---- */
  var SYN = {
    'مهریه': ['مهر', 'مهریه', 'عندالمطالبه', 'عندالاستطاعه', 'نکاح', 'زوجه'],
    'مهر': ['مهریه', 'مهر', 'نکاح'],
    'نفقه': ['نفقه', 'انفاق', 'زوجه', 'اولاد', 'هزینه'],
    'حضانت': ['حضانت', 'اولاد', 'طفل', 'ملاقات', 'صغیر'],
    'طلاق': ['طلاق', 'گواهی عدم امکان سازش', 'عسر و حرج', 'سازش'],
    'چک': ['چک', 'بلامحل', 'گواهی عدم پرداخت', 'صادرکننده', 'ظهرنویسی'],
    'سرقت': ['سرقت', 'ربایش', 'دزدی', 'مال'],
    'کلاهبرداری': ['کلاهبرداری', 'فریب', 'توسل به وسایل متقلبانه'],
    'خیانت در امانت': ['خیانت در امانت', 'امانت', 'سپرده'],
    'تخلیه': ['تخلیه', 'اجاره', 'مستأجر', 'موجر', 'اجور', 'عین مستأجره'],
    'مستأجر': ['مستأجر', 'اجاره', 'موجر', 'تخلیه'],
    'ملک': ['ملک', 'عین', 'مال غیرمنقول', 'ملکیت', 'تصرف'],
    'سند': ['سند', 'رسمی', 'عادی', 'ثبت', 'تنظیم سند'],
    'قرارداد': ['قرارداد', 'شرط', 'عقد', 'تعهد', 'فسخ', 'وجه التزام'],
    'خسارت': ['خسارت', 'ضرر', 'مسئولیت', 'جبران'],
    'ارث': ['ارث', 'وراثت', 'ترکه', 'سهم', 'وارث'],
    'کار': ['کار', 'کارگر', 'کارفرما', 'مزد', 'سنوات', 'بیمه'],
    'کارگر': ['کارگر', 'کارفرما', 'مزد', 'حقوق', 'مرخصی', 'سنوات', 'بیمه'],
    'دیوان': ['دیوان عدالت', 'شکایت', 'ابطلال', 'اداری'],
    'معاونت': ['معاونت در جرم', 'شرکت در جرم', 'مجازات'],
    'شفعه': ['شفعه', 'اخذ به شفعه', 'بیع'],
    'رهن': ['رهن', 'وثیقه', 'قرض', 'طلا'],
    'ضمانت': ['ضمان', 'کفالت', 'وثیقه', 'تعهد'],
    'صلاحیت': ['صلاحیت', 'مرجع صالح', 'دادگاه'],
    'مرور زمان': ['مرور زمان', 'موعد', 'مهلت'],
    'اظهارنامه': ['اظهارنامه', 'اخطار', 'مطالبه'],
    'لایحه': ['لایحه', 'دفاعیه', 'دادگاه'],
    'دیه': ['دیه', 'ارش', 'جنایت', 'پزشکی قانونی'],
    'طلاق توافقی': ['طلاق توافقی', 'گواهی عدم امکان سازش', 'مشاوره'],
    'حجره': ['حجره', 'تخلیه', 'اجاره'],
    'سرقفلی': ['سرقفلی', 'حق کسب و پیشه', 'مستأجر'],
    'تمکن': ['تمکن', 'اعسار', 'استطاعت مالی'],
    'اعسار': ['اعسار', 'تقسیط', 'تمکن']
  };
  function expand(query) {
    var tg = tokens(query);
    var extra = [];
    tg.forEach(function (w) {
      Object.keys(SYN).forEach(function (k) {
        if (w === k || (k.length >= 4 && w.indexOf(k) >= 0) || (w.length >= 4 && k.indexOf(w) >= 0)) {
          SYN[k].forEach(function (e) { if (extra.indexOf(e) < 0) extra.push(e); });
        }
      });
    });
    return { base: tg, extra: extra };
  }

  /* ---------- normalization ---------- */
  function norm(t) {
    return String(t == null ? '' : t)
      .replace(/[يك]/g, function (c) { return c === 'ي' ? 'ی' : 'ک'; })
      .replace(/[أإآٱ]/g, 'ا').replace(/[ؤئ]/g, function (c) { return c === 'ؤ' ? 'و' : 'ی'; })
      .replace(/ة/g, 'ه').replace(/[ۀهٔ]/g, 'ه')
      .replace(/[\u064B-\u0652\u0670\u0653-\u0655]/g, '')   // اعراب
      .replace(/[\u200c\u200e\u200f\u202a-\u202e]/g, ' ')    // نیم‌فاصله و کنترل‌ها
      .replace(/[۰-۹]/g, function (d) { return String('۰۱۲۳۴۵۶۷۸۹'.indexOf(d)); })
      .replace(/[٠-٩]/g, function (d) { return String('٠١٢٣٤٥٦٧٨٩'.indexOf(d)); })
      .replace(/[«»"'`؛،:!؟?.,()\[\]{}\-_/\\|*+=<>%$#@~^&]/g, ' ')
      .replace(/ي/g, 'ی')
      .replace(/\s+/g, ' ')
      .trim();
  }
  function tokens(t) {
    var out = [];
    norm(t).split(' ').forEach(function (w) {
      if (!w || w.length < 2 || STOP[w]) return;
      out.push(w);
    });
    return out;
  }

  /* ---------- corpus load ---------- */
  var LAWS = [];          // [{name, year, domains, articles:[{art,text}], source}]
  var DOCS = [];          // [{law, art, text, norm, tf:{}, len, domains, curated, verify}]
  var DF = {};            // document frequency
  var AVG = 1;

  function load() {
    LAWS = []; DOCS = []; DF = {};
    try {
      var c = window.LAW_CORPUS || { laws: [] };
      c.laws.forEach(function (l) {
        var arts = [];
        for (var i = 0; i < l.a.length; i += 2) arts.push({ art: l.a[i], text: l.a[i + 1] });
        var domains = l.d || (window.LAW_DOMAIN && window.LAW_DOMAIN[l.n]) || [];
        LAWS.push({ name: l.n, year: l.y, domains: domains, articles: arts, source: 'wikisource' });
      });
    } catch (e) { console.warn('corpus load failed', e); }

    /* اصول و قواعد کاربردی */
    var PR = window.LAW_PRINCIPLES || [];
    LAWS.push({
      name: 'اصول و قواعد کاربردی', year: '—', domains: [], source: 'principles',
      articles: PR.map(function (p, i) { return { art: 'اصل ' + (i + 1) + (p.l && p.l !== '—' ? ' — ' + p.l : ''), text: p.t, curated: 1, verify: p.v, domains: p.d }; })
    });

    /* قوانین واردشدهٔ کاربر */
    var imports = (window.Store && window.Store.State.lawImports) || [];
    imports.forEach(function (imp) {
      LAWS.push({ name: imp.name + ' (وارد‌شده)', year: imp.year || '—', domains: imp.domains || [], source: 'import', id: imp.id, articles: imp.articles });
    });

    /* index */
    LAWS.forEach(function (law) {
      law.articles.forEach(function (a) {
        var n = norm((law.name || '') + ' ' + (a.art || '') + ' ' + (a.text || ''));
        var tg = tokens(n);
        if (!tg.length) return;
        var tf = {};
        tg.forEach(function (w) { tf[w] = (tf[w] || 0) + 1; });
        DOCS.push({
          law: law.name, lawId: law.id, art: a.art, text: a.text, curated: a.curated, verify: a.verify,
          domains: a.domains || law.domains || [], source: law.source,
          tf: tf, len: tg.length, norm: n
        });
        Object.keys(tf).forEach(function (w) { DF[w] = (DF[w] || 0) + 1; });
      });
    });
    AVG = DOCS.reduce(function (s, d) { return s + d.len; }, 0) / Math.max(1, DOCS.length);
    return { docs: DOCS.length, laws: LAWS.length };
  }

  /* ---------- BM25 ---------- */
  var K1 = 1.35, B = 0.62;
  function scoreDoc(d, qt, phrases, extra, hasDomainMatch, qinfo) {
    var s = 0, matched = 0;
    qt.forEach(function (w, idx) {
      var f = d.tf[w]; if (!f) return;
      matched++;
      var idf = Math.log(1 + (DOCS.length - (DF[w] || 0) + 0.5) / ((DF[w] || 0) + 0.5));
      var wgt = (idx < 2 ? 1.35 : 1);                 /* واژه‌های آغازین پرسش مهم‌ترند */
      s += wgt * idf * (f * (K1 + 1)) / (f + K1 * (1 - B + B * d.len / AVG));
    });
    /* ضریب پوشش: ماده‌ای که فقط یک واژه از پرسش طولانی را دارد پایین می‌آید */
    var cov = qt.length ? matched / qt.length : 0;
    s *= (0.5 + 1.05 * cov);
    /* هم‌معناها: وزن کمتر از واژه‌های اصلی */
    (extra || []).forEach(function (w) {
      var f = d.tf[w]; if (!f) return;
      var idf = Math.log(1 + (DOCS.length - (DF[w] || 0) + 0.5) / ((DF[w] || 0) + 0.5));
      s += 0.45 * idf * (f * (K1 + 1)) / (f + K1 * (1 - B + B * d.len / AVG));
    });
    /* تقویت تطابق عبارت‌های دو و سه‌کلمه‌ای */
    (phrases || []).forEach(function (p) {
      if (d.norm.indexOf(p) >= 0) s += 2.2;
    });
    /* عبارت کامل پرسش */
    if (qt.length >= 2 && d.norm.indexOf(qt.join(' ')) >= 0) s += 2.6;
    if (hasDomainMatch) s *= 1.25;                                 /* مادهٔ هم‌حوزه اولویت دارد */
    if (d.source === 'principles') s *= 1.12;                      /* اصول کاربردی کمی بالاتر */
    if (d.text && d.text.length < 40) s *= 0.9;
    return s;
  }

  function search(query, opts) {
    opts = opts || {};
    if (!DOCS.length) load();
    var qt = tokens(query);
    if (!qt.length) return [];
    var ex = expand(query);
    var phrases = [];
    for (var i = 0; i < qt.length - 1; i++) phrases.push(qt[i] + ' ' + qt[i + 1]);
    for (var j = 0; j < qt.length - 2; j++) phrases.push(qt[j] + ' ' + qt[j + 1] + ' ' + qt[j + 2]);
    var dom = opts.domain && opts.domain !== 'auto' ? opts.domain : null;

    var scored = [];
    for (var k = 0; k < DOCS.length; k++) {
      var d = DOCS[k];
      var isDom = !!(d.domains && d.domains.length && dom && d.domains.indexOf(dom) >= 0);
      if (dom && d.domains && d.domains.length && !isDom) continue;
      if (dom && (!d.domains || !d.domains.length)) continue;      /* بی‌حوزه‌ها در فیلتر حوزه نمی‌آیند */
      var s = scoreDoc(d, qt, phrases, ex.extra, isDom);
      if (s > 0) scored.push({ d: d, s: s, cov: 0 });
    }
    scored.sort(function (a, b) { return b.s - a.s; });
    /* تنوع: حداکثر ۳ ماده از هر قانون و تضمین ورود اصول کاربردی مرتبط */
    var perLaw = {}, diverse = [];
    scored.forEach(function (x) {
      var c = perLaw[x.d.law] || 0;
      if (c >= 3) return;
      perLaw[x.d.law] = c + 1;
      diverse.push(x);
    });
    scored = diverse.length ? diverse : scored;
    return scored.slice(0, opts.top || 8).map(function (x) {
      return { law: x.d.law, art: x.d.art, text: x.d.text, score: Math.round(x.s * 100) / 100,
               curated: x.d.curated, verify: x.d.verify, domains: x.d.domains, source: x.d.source, lawId: x.d.lawId };
    });
  }

  /* ---------- cite block for prompts ---------- */
  function citeBlock(query, domain, top) {
    var hits = search(query, { domain: domain, top: top || 8 });
    if (!hits.length) return '';
    var L = ['—— مواد قانونی بازیابی‌شده از بانک قوانین (متن رسمی/اصول) —'];
    hits.forEach(function (h, i) {
      var tag = h.curated ? '(اصل کاربردی' + (h.verify ? ' — نیازمند تأیید متن رسمی' : '') + ')' : (h.source === 'import' ? '(متن واردشدهٔ کاربر)' : '(متن رسمی بانک)');
      L.push('[' + (i + 1) + '] ' + h.law + ' — ' + (h.curated ? h.art : 'مادهٔ ' + h.art) + ' ' + tag);
      L.push(String(h.text).slice(0, 900));
      L.push('');
    });
    L.push('در پاسخ، استنادات خود را به همین مواد محدود کن و شمارهٔ ماده را دقیقاً همان‌طور که آمده بنویس. اگر ماده‌ای در این فهرست نبود، شمارهٔ ماده نساز و فقط بنویس «نیازمند بررسی متن قانون».');
    return L.join('\n');
  }

  /* ---------- stats & import ---------- */
  function stats() {
    if (!DOCS.length) load();
    var byLaw = {};
    DOCS.forEach(function (d) {
      var key = d.law;
      byLaw[key] = (byLaw[key] || 0) + 1;
    });
    return { total: DOCS.length, byLaw: byLaw, laws: LAWS.length };
  }

  var FA = function (s) { return String(s).replace(/[۰-۹]/g, function (d) { return String('۰۱۲۳۴۵۶۷۸۹'.indexOf(d)); }); };

  /* تجزیهٔ متن کامل قانون به مواد */
  function parseLawText(text, lawName) {
    var clean = String(text || '').replace(/\r/g, '');
    var rx = /(?:^|\n)\s*=*\s*ماده\s*[ٔ]?\s*([0-9۰-۹]{1,4})\s*(مکرر|تکراری)?\s*=*\s*[-–—:.]?\s*/g;
    var marks = [], m;
    while ((m = rx.exec(clean)) !== null) marks.push({ num: m[1] + (m[2] ? ' مکرر' : ''), start: m.index, end: rx.lastIndex });
    var out = [];
    for (var i = 0; i < marks.length; i++) {
      var s = marks[i].end, e = (i + 1 < marks.length) ? marks[i + 1].start : clean.length;
      var body = clean.slice(s, e).replace(JUNK, ' ').replace(/\s*\n\s*/g, ' ').replace(/\s{2,}/g, ' ').trim();
      if (body.length < 15) continue;
      out.push({ art: marks[i].num, text: body.slice(0, 4000), domains: [] });
    }
    return out;
  }

  function importLaw(name, rawText, domains) {
    var arts = parseLawText(rawText, name);
    if (!arts.length) return { ok: false, msg: 'هیچ ماده‌ای با الگوی «ماده ...» پیدا نشد. متن را با فایل متنی ساده (txt) یا PDF متنی وارد کنید.' };
    var S = window.Store;
    S.State.lawImports = S.State.lawImports || [];
    var rec = { id: S.uid('law'), name: name || ('قانون واردشده ' + (S.State.lawImports.length + 1)), domains: domains || [], articles: arts, ts: Date.now() };
    S.State.lawImports.push(rec);
    S.save(true);
    load();
    return { ok: true, count: arts.length, id: rec.id, name: rec.name };
  }
  function removeImport(id) {
    var S = window.Store;
    S.State.lawImports = (S.State.lawImports || []).filter(function (x) { return x.id !== id; });
    S.save(true); load();
  }

  window.Knowledge = {
    load: load, search: search, citeBlock: citeBlock, stats: stats,
    importLaw: importLaw, removeImport: removeImport, parseLawText: parseLawText,
    norm: norm, tokens: tokens,
    get laws() { return LAWS; },
    get size() { return DOCS.length; }
  };
})();
